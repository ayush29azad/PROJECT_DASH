/// @file SomeipServiceProvider.hpp
/// @brief Contains SomeipServiceProvider class declaration and definition
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef SOMEIP_SERVICE_PROVIDER_HEADER_H
#define SOMEIP_SERVICE_PROVIDER_HEADER_H

#include <functional>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include <vsomeip/vsomeip.hpp>

#include "MessageChannel.hpp"
#include "NotifyChannel.hpp"

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Class representing a vsomeip server (service provider), one
      /// object per vsomeip service should be created
      class SomeipServiceProvider
      {

      private:
        /// @brief Stores the service_id, instance_id and vsomeip application ptr
        std::shared_ptr<SomeipChannel> service_channel = nullptr;

        /// @brief Stores the vsomeip service availibility callback
        std::function<void(std::shared_ptr<SomeipChannel>, bool)> on_available = nullptr;

        /// @brief stores all the event ids required for destruction
        std::vector<vsomeip::event_t> event_ids;

        /// @brief stores all the eventgroup ids required for destruction
        std::set<vsomeip::eventgroup_t> grp_ids;

        /// @brief stores all the method ids required for destruction
        std::vector<vsomeip::method_t> method_ids;

        /// @brief stores lambdas to call for "destructions" of message channel singletons
        std::vector<void (*)(void)> message_channel_destructors;

        /// @brief stores lambdas to call for "destructions" of notify channel singletons
        std::vector<void (*)(void)> notify_channel_destructors;

      public:
        /// @brief Wrapper function over vsomeip::application->offer_service() function
        /// @satisfy{Requirement01321626, Requirement01321636}
        void offerService() const
        {
          if (service_channel == nullptr)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : service_channel pointer was null in provider object" << std::endl;
            return;
          }
          auto m_app = service_channel->get_app();
          DI_MODEL_LOG_MCTX_INFO << "[Info] : Offer service for ServiceId=" << service_channel->getServiceID()
                                 << ", InstanceId=" << service_channel->getInstanceID() << std::endl;
          m_app->offer_service(
              service_channel->getServiceID(), service_channel->getInstanceID(), service_channel->getMajorVersion());
        }

        /// @brief Only allowed constructor
        /// @param _channel pointer to the SomeipChannel object
        SomeipServiceProvider(std::shared_ptr<SomeipChannel> const _channel)
        {
          this->service_channel = _channel;
          offerService();
        }

        /// @brief Getter method for SomeipChannel object
        /// @return Returns the ptr to SomeipChannel object
        std::shared_ptr<SomeipChannel> const getSomeipChannel() const
        {
          return this->service_channel;
        }

        /// @brief Setter method for SomeipChannel object
        /// @param _service_channel Takes the ptr to the SomeipChannel object
        void setSomeipChannel(std::shared_ptr<SomeipChannel> const _service_channel)
        {
          this->service_channel = _service_channel;
          DI_MODEL_LOG_MCTX_INFO << "[Info] : service_channel = " << service_channel << std::endl;
        }

        /// @brief Setter method for vsomeip service availibility callback
        /// @param fun_ptr Takes the callable object to be registered as availibility callback
        void setOnAvailableCallback(std::function<void(std::shared_ptr<SomeipChannel>, bool)> const fun_ptr)
        {
          this->on_available = fun_ptr;
        }

        /// @brief Getter method for vsomeip service availibility callback
        /// @param fun_ptr Takes the callable object to be registered as availibility callback
        std::function<void(std::shared_ptr<SomeipChannel>, bool)> const getOnAvailableCallback() const
        {
          return this->on_available;
        }

        /// @brief Creates a channel through which vsomeip notify events could be sent
        /// @tparam NotifyType DataType of notification event data which we want to
        /// send using the server application
        /// @param event_id Event ID for the vsomeip notify event
        /// @param _grp_ids List of all the group IDs the event belongs to
        /// @satisfy{Requirement01340698}
        template <typename NotifyType>
        void addNotifyChannel(vsomeip::event_t const& event_id, std::set<vsomeip::eventgroup_t> const& _grp_ids)
        {
          provider::NotifyChannel<NotifyType>::get_instance().initNotifyChannel(service_channel, event_id, _grp_ids);
          provider::NotifyChannel<NotifyType>::get_instance().offerEvent();

          event_ids.push_back(event_id);
          for (auto el : _grp_ids)
          {
            grp_ids.insert(el);
          }

          notify_channel_destructors.push_back(
              []()
              {
                provider::NotifyChannel<NotifyType>::get_instance().stopOfferEvent();
                provider::NotifyChannel<NotifyType>::get_instance().deinitNotifyChannel();
              });
        }

        /// @brief Function to send the actual data as vsomeip notification event
        /// @tparam NotifyType DataType of notification event data which we want to
        /// send using the server application
        /// @param data The data of type NotifyType we want to send
        template <typename NotifyType>
        void sendNotifyEvent(NotifyType const& data)
        {
          provider::NotifyChannel<NotifyType>::get_instance().setData(data);
          provider::NotifyChannel<NotifyType>::get_instance().send();
        }

        /// @brief Creates a channel through which vsomeip request/response events could be sent
        /// Note that response can only be sent if the server receives the request and for this
        /// reason both events(and hence type) are getting used together
        /// @tparam RequestType Type of request event data which we want to receive using
        /// the server application
        /// @tparam ResponseType Type of response event data which we want to send using
        /// the server application
        /// @param _method_id Method ID for the vsomeip request/response event
        /// @param func function that calls the model method after converting to model struct
        /// @satisfy{Requirement01321467}
        template <typename RequestType, typename ResponseType>
        void addMessageChannel(vsomeip::method_t const& _method_id, std::function<void(RequestType const&)> const& func)
        {
          provider::MessageChannel<RequestType, ResponseType>::get_instance().initMessageChannel(
              service_channel, _method_id);
          provider::MessageChannel<RequestType, ResponseType>::get_instance().setRequestCallback(func);
          provider::MessageChannel<RequestType, ResponseType>::get_instance().registerMessageHandler();

          method_ids.push_back(_method_id);

          message_channel_destructors.push_back(
              []()
              {
                provider::MessageChannel<RequestType, ResponseType>::get_instance().deregisterMessageHandler();
                provider::MessageChannel<RequestType, ResponseType>::get_instance().setRequestCallback({});
                provider::MessageChannel<RequestType, ResponseType>::get_instance().deinitMessageChannel();
              });
        }

        /// @brief  Function to send the actual data as vsomeip response event when
        /// a request is received
        /// @tparam RequestType Type of request event data. Needed because the request
        /// and the response are binded together
        /// @tparam ResponseType Type of response event data which we want to send using
        /// the server application in response to the reception of request event
        /// @param _response The data of type ResponseType we want to send
        template <typename RequestType, typename ResponseType>
        void sendResponse(ResponseType const& _response)
        {
          provider::MessageChannel<RequestType, ResponseType>::get_instance().sendResponse(_response);
        }

        /// @brief Releases the service
        /// @satisfy{Requirement01403320,Requirement01403331,Requirement01403332}
        void releaseService() const
        {

          DI_MODEL_LOG_MCTX_INFO << "SomeipServiceProvider::releaseService()" << std::endl;

          auto const& m_app = service_channel->get_app();
          vsomeip::service_t const service_id = service_channel->getServiceID();
          vsomeip::instance_t const instance_id = service_channel->getInstanceID();
          vsomeip::major_version_t const major_version = service_channel->getMajorVersion();

          // "destroy" all notify channels
          for (void (*const destructor)(void) : notify_channel_destructors)
          {
            (*destructor)();
          }

          // "destroy" all message channels
          for (void (*const destructor)(void) : message_channel_destructors)
          {
            (*destructor)();
          }

          m_app->stop_offer_service(service_id, instance_id, major_version);
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
