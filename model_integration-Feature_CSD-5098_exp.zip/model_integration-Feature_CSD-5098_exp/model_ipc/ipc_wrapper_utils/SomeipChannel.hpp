/// @file SomeipChannel.hpp
/// @brief Contains SomeipChannel class declaration
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef SOMEIPCHANNEL_HEADER_H
#define SOMEIPCHANNEL_HEADER_H

#include "Channel.hpp"
#include <vsomeip/vsomeip.hpp>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Base class for the MessageChannel and NotifyChannel
      class SomeipChannel : Channel
      {
        /// @brief ServiceID for the service
        vsomeip::service_t service_id;

        /// @brief InstanceID for the service
        vsomeip::instance_t instance_id;

        /// @brief Major Version for the service
        vsomeip::major_version_t major_version = static_cast<vsomeip::major_version_t>(1);

        /// @brief Pointer to the vsomeip::application object
        std::shared_ptr<vsomeip::application> m_app = nullptr;

      public:
        /// @brief Single argument Constructor
        /// @param app Pointer to the vsomeip::application object
        /// obtained from model launcher
        SomeipChannel(std::shared_ptr<vsomeip::application> const app);

        /// @brief Three agrument Constructor
        /// @param app Pointer to the vsomeip::application object
        /// @param _service_id ServiceID to be set
        /// @param _instance_id InstanceID to be set
        /// @param _major_version MajorVersion to be set
        SomeipChannel(
            std::shared_ptr<vsomeip::application> const app, vsomeip::service_t const& _service_id,
            vsomeip::instance_t const& _instance_id = 1,
            vsomeip::major_version_t const _major_version = static_cast<vsomeip::major_version_t>(1));

        /// @brief Getter method for the member service_id
        /// @return Decimal int value service_id
        vsomeip::service_t getServiceID() const;

        /// @brief Setter method for the member service_id
        /// @param _service_id The decimal int value to be set
        void setServiceID(vsomeip::service_t const& _service_id);

        /// @brief Getter method for the member instance_id
        /// @return Decimal int value instance_id
        vsomeip::instance_t getInstanceID() const;

        /// @brief Setter method for the member instance_id
        /// @param _instance_id The decimal int value to be set
        void setInstanceID(vsomeip::instance_t const& _instance_id);

        /// @brief Getter method for the member major_version
        /// @return major_version
        vsomeip::major_version_t getMajorVersion() const;

        /// @brief Setter method for the member major_version
        /// @param _major_version the major_version value to be set
        void setMajorVersion(vsomeip::major_version_t const _major_version);

        /// @brief Getter method for the member m_app
        /// @return Returns Pointer to the vsomeip::application object
        std::shared_ptr<vsomeip::application> get_app() const;
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
