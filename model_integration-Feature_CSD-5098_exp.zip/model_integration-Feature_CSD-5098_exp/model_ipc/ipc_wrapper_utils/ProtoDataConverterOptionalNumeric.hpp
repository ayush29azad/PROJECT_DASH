#ifndef PROTO_DATA_CONVERTER_OPTIONAL_NUMERIC_HEADER
#define PROTO_DATA_CONVERTER_OPTIONAL_NUMERIC_HEADER

#include <utility>

#include "ProtoDataConverterScalarNumeric.hpp"

namespace jlr::cccm::di
{
  template <typename opt_type>
  void ProtoToModelDataConverterOptionalNumeric(
      bool has_field, decltype(std::declval<opt_type>().field) field, opt_type& opt_numeric)
  {
    opt_numeric.has_field = has_field;
    ProtoToModelDataConverterScalarNumeric(field, opt_numeric.field);
  }

  template <typename opt_type, typename Setter, typename Clearer>
  void ModelToProtoDataConverterOptionalNumeric(opt_type const& data, Setter& setter, Clearer& clearer)
  {
    if (data.has_field)
    {
      ModelToProtoDataConverterScalarNumeric(data.field, setter);
    }
    else
    {
      clearer();
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_OPTIONAL_NUMERIC_HEADER
