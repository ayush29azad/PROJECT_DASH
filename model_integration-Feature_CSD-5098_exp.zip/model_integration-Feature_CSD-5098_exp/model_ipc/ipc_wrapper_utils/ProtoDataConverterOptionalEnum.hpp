#ifndef PROTO_DATA_CONVERTER_OPTIONAL_ENUM_HEADER
#define PROTO_DATA_CONVERTER_OPTIONAL_ENUM_HEADER

#include <utility>
#include <boost/optional.hpp>

#include "ProtoDataConverterEnum.hpp"

namespace jlr::cccm::di
{

  /// @brief Converts proto optional enum to model optional enum
  /// @tparam opt_type Optional model type (e.g., opt_enum_type)
  /// @param has_field Indicates if the proto field is set
  /// @param field The proto enum value (typically int32)
  /// @param opt_enum Output model optional enum
  template <typename opt_type>
  void ProtoToModelDataConverterOptionalEnum(bool has_field, int field, opt_type& opt_enum)
  {
    opt_enum.has_field = has_field;

    using model_enum_type = decltype(opt_enum.field);
    ProtoToModelDataConverterEnum<model_enum_type>(field, opt_enum.field);
  }

  /// @brief Converts model optional enum to proto optional enum
  /// @tparam opt_type Optional model type
  /// @tparam Setter Lambda to set proto enum
  /// @tparam Clearer Lambda to clear proto field
  /// @param data Model optional enum
  /// @param setter Lambda to set proto field
  /// @param clearer Lambda to clear proto field
  template <typename opt_type, typename Setter, typename Clearer>
  void ModelToProtoDataConverterOptionalEnum(opt_type const& data, Setter& setter, Clearer& clearer)
  {
    if (data.has_field)
    {
      setter(static_cast<int>(data.field));
    }
    else
    {
      clearer();
    }
  }

}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_OPTIONAL_ENUM_HEADER
