/// @file ModelControllerInterface.hpp
/// @brief Defines ModelController Interface
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2025

#ifndef MODEL_CONROLLER_INTERFACE_HEADER_H
#define MODEL_CONROLLER_INTERFACE_HEADER_H

#include <DdsCommunicationHandler.hpp>
#include <SomeipCommunicationHandler.hpp>
#include <TimerHandler.hpp>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      /// @brief Interface to ModelController Class to be used by global functions
      class IModelController
      {
      public:
        /// @brief Interface to return DDSCommunication Handler
        /// @return shared_ptr to DDSCommunication Handler owned by concrete modelController
        virtual std::shared_ptr<DdsCommunicationHandler> get_dds_handler() const = 0;

        /// @brief Default virtual destructor
        virtual ~IModelController() = default;
      };

    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
