#ifndef PROTO_DATA_CONVERTER_SCALAR_STRING_HEADER
#define PROTO_DATA_CONVERTER_SCALAR_STRING_HEADER

#include <string>
#include <string.h>
#include <stdint.h>
#include <stdexcept>
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto string to model string
  /// @tparam model_string_type model string type
  /// @param proto_string const reference to proto data
  /// @param model_string out param for model data
  /// @satisfy{Requirement01184544}
  template <typename model_string_type>
  void ProtoToModelDataConverterScalarString(std::string const& proto_string, model_string_type& model_string)
  {

    // model_string_type model_string{};
    memset(model_string.payload, 0, sizeof(model_string.payload));
    if (proto_string.size() <= array_size(model_string.payload))
    {
      model_string.payload_length = proto_string.size();
      for (size_t i = 0; i < proto_string.size(); ++i)
      {
        model_string.payload[i] = proto_string[i];
      }
    }
    else
    {
      model_string.payload_length = array_size(model_string.payload);
      for (size_t i = 0; i < array_size(model_string.payload); ++i)
      {
        model_string.payload[i] = proto_string[i];
      }
    }

    // return model_string;
  }

  /// @brief converts model string to proto string
  /// @tparam model_string_type model string type
  /// @param model_string const reference to model data
  /// @param proto_string out param for proto data
  /// @satisfy{Requirement01184544}
  template <typename model_string_type>
  void ModelToProtoDataConverterScalarString(model_string_type const& model_string, std::string& proto_string)
  {

    if (model_string.payload_length > array_size(model_string.payload))
    {
      throw std::invalid_argument("Model string input has invalid payload_length");
    }

    proto_string.clear();
    for (size_t i = 0; i < model_string.payload_length; ++i)
    {
      proto_string.push_back(model_string.payload[i]);
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_SCALAR_STRING_HEADER
