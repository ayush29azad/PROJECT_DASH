#include "mem_lock.h"

namespace model_mem_lock
{
  void mem_lock(pthread_mutex_t* lock)
  {
    (void)lock;
  }

  void mem_unlock(pthread_mutex_t* lock)
  {
    (void)lock;
  }

  pthread_mutex_t* mem_lock_initialize()
  {
    return nullptr;
  }

  void mem_lock_destroy(pthread_mutex_t* lock)
  {
    (void)lock;
  }
}  // namespace model_mem_lock
