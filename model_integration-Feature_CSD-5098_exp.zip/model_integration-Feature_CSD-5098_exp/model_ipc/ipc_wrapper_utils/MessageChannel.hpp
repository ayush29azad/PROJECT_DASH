/// @file MessageChannel.hpp
/// @brief Defines MessageChannel class for both provider and consumer
/// applications
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef METHOD_CHANNEL_HEADER_H
#define METHOD_CHANNEL_HEADER_H

#include <thread>

#include "SomeipChannel.hpp"
#include <functional>
#include <memory>
#include <vector>
#include <vsomeip/enumeration_types.hpp>
#include <vsomeip/vsomeip.hpp>
#include "soa.h"
#include "ModelExports.hpp"

/// @brief Alias for the SomeipChannel
///
/// @details This type alias provides a simplified name for jlr::cccm::di::SomeipChannel
using SomeipChannel = jlr::cccm::di::SomeipChannel;

namespace provider
{
  /// @brief MessageChannel interface for vsomeip provider. provider is an
  /// entity that related to the vsomeip application offering a service
  ///
  /// @details Singleton class binding a vsomeip GetRequest and GetResponse
  /// event pair with the corresponding proto messages. Object of each such
  /// event pair will be created
  ///
  /// @tparam RequestType The corresponding proto message associated with the GetRequest
  /// @tparam ResponseType The corresponding proto message associated with the GetResponse
  ///
  template <class RequestType, class ResponseType>
  class SYMBOL_HIDDEN MessageChannel
  {

    /// @brief  Stores the service_id, instance_id and vsomeip application ptr
    std::shared_ptr<SomeipChannel> channel = nullptr;

    /// @brief Stores method_id for the event pair
    vsomeip::method_t method_id = 0;

    /// @brief To store last vsomeip GetRequest received. It will be needed
    /// to create the corresponding response
    std::shared_ptr<vsomeip::message> last_request = nullptr;

    /// @brief Temporary storage for the GetRequest event to be received. Can
    /// be used to fetch the last received message for the event
    RequestType request_data;

    /// @brief Temporary storage for the GetResponse event to be sent. Can
    /// be used to fetch the last sent message for the event
    ResponseType response_data;

    /// @brief Callback method stored as std::function object for the
    /// reception of vsomeip messages (GetRequests for provider entity).
    /// Specifies what operation to do after the received byte array
    /// has been converted into the  protobuf Message type. Default value
    /// is nullptr. In this case just the log will be printed
    std::function<void(RequestType const&)> request_callback{};

    /// @brief private constructor for singleton
    MessageChannel()
    {
    }

  public:
    MessageChannel(MessageChannel const&) = delete;
    MessageChannel& operator=(MessageChannel const&) = delete;

    /// @brief Getter method for the singleton class
    /// @return Returns the provider::MessageChannel static object initialized with some
    /// template parameter
    static MessageChannel& get_instance()
    {
      static MessageChannel message_channel;
      return message_channel;
    }

    /// @brief Method to set the values of service_id, instance_id and method_id
    /// @param _channel Associated channel object specifying the service_id and instance_id
    /// @param _method_id The method_id for the events
    void initMessageChannel(std::shared_ptr<SomeipChannel> _channel, vsomeip::method_t const& _method_id)
    {
      this->channel = _channel;
      this->method_id = _method_id;
    }

    /// @brief destroy the channel object
    void deinitMessageChannel()
    {
      channel.reset();
    }

    /// @brief Setter method for the member last_request
    /// @param lastRequest Pointer to the last vsomeip request message
    void setLastRequest(std::shared_ptr<vsomeip::message> lastRequest)
    {
      this->last_request = lastRequest;
    }

    /// @brief Getter method for the member method_id
    /// @return Returns method_id (int) for both the events
    vsomeip::method_t getMethodID() const
    {
      return this->method_id;
    }

    /// @brief Setter method for the member method_id
    /// @param _method_id The int value to be set
    void setMethodID(vsomeip::method_t const& _method_id)
    {
      this->method_id = _method_id;
    }

    /// @brief Callback method to be called when vsomeip request event
    /// is received. Converts the received vsomeip byte array to string
    /// then the string is deserialized into protubuf Message object. The
    /// type of the protobuf Message is specified by the class template
    /// parameter RequestType. If the request_callback event is nullptr,
    /// The logs will just be printed else the callable request_callback
    /// will be called. If the value of the member workExecutor
    /// is not nullptr, the callable request_callback will be executed on the
    /// worker thread. If the value is nullptr, which is the default value,
    /// request_callback will be executed on the vsomeip listener thread itself.
    /// @param request_message Pointer to the received vsomeip::message
    void onRequest(std::shared_ptr<vsomeip::message> const& request_message)
    {
      // check if message return code is ok
      {
        auto retcode = request_message->get_return_code();
        if (retcode != vsomeip::return_code_e::E_OK)
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : Request Message return code is " << static_cast<uint32_t>(retcode)
                                  << ", Dropping the message" << std::endl;
          return;
        }
      }

      this->last_request = request_message;
      if (nullptr == request_message)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : Request message is nullptr" << std::endl;
      }
      else
      {
        std::shared_ptr<vsomeip::payload> const payload = request_message->get_payload();
        RequestType request;

        if (soa_payload::is_malformed(payload) == true)
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : Requestpayload is malformed, Dropping the message" << std::endl;
          return;
        }

        request.ParseFromString(soa_payload::extract_protobuf(payload));
        DI_MODEL_LOG_MCTX_DEBUG << "[Info] : Recvd : " << typeid(RequestType).name()
                                << "on thread : " << std::this_thread::get_id() << std::endl;
        DI_MODEL_LOG_MCTX_DEBUG << request.DebugString() << std::endl;

        if (request_callback != nullptr)
        {
          request_callback(request);
          DI_MODEL_LOG_MCTX_DEBUG << "[Info] : Success!! Executed on thread : " << std::this_thread::get_id() << ":"
                                  << typeid(RequestType).name() << std::endl;
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : request callback not implemented" << std::endl;
        }
      }
    }

    /// @brief Registers the onRequest method with the vsomeip application. Wrapper
    /// for vsomeip::application->register_message_handler() for request-response
    void registerMessageHandler()
    {
      channel->get_app()->register_message_handler(
          channel->getServiceID(),
          channel->getInstanceID(),
          method_id,
          [this](std::shared_ptr<vsomeip::message> const& request_message)
          {
            this->onRequest(request_message);
          });
    }

    /// @brief deregister the message handler
    /// @satisfy{Requirement01403332}
    void deregisterMessageHandler()
    {
      channel->get_app()->unregister_message_handler(channel->getServiceID(), channel->getInstanceID(), method_id);
    }

    /// @brief Getter method for the member request_data
    /// @return Returns protobuf message type request_data.
    /// Actual type specified by the template parameter RequestType
    RequestType getLastRequestData() const
    {
      return this->request_data;
    }

    /// @brief Setter method for the member request_data
    /// @param request_message RequestType message to be set
    void setRequestData(RequestType const& request_message)
    {
      this->request_data = request_message;
    }

    /// @brief Getter method for the member response_data
    /// @return Returns protobuf message type response_data.
    /// Actual type specified by the template parameter ResponseType
    ResponseType getLastResponseData() const
    {
      return this->response_data;
    }

    /// @brief Setter method for the member response_data
    /// @param response_message ResponseType message to be set
    void setResponsedata(ResponseType const& response_message)
    {
      this->response_data = response_message;
    }

    /// @brief Setter method for the member request_callback
    /// @param fun_ptr Callable object to be set as callback
    void setRequestCallback(std::function<void(RequestType const&)> fun_ptr)
    {
      this->request_callback = fun_ptr;
    }

    /// @brief Upon receiving a vsomeip request, the provider entity/app
    /// is supposed to reply with a response. This method converts the
    /// the protobuf message type ResponseType object to string. The string
    /// is then converted to vsomeip byte array. Then a payload is created
    /// using the member last_request and set with the converted byte array.
    /// Note that a response is not supposed to be sent if the consumer hasn't
    /// requested for it. After setting the payload, the method finally calls
    /// vsomeip::application()->send() to send the response
    /// @param response_message The protobuf message of type ResponseType
    /// to be sent as reply
    void sendResponse(ResponseType const& response_message)
    {
      std::string msg;
      response_message.SerializeToString(&msg);

      if (nullptr == last_request)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : sendResponse : " << typeid(ResponseType).name()
                                << " attempt to send response without request" << std::endl;
      }
      else
      {
        std::shared_ptr<vsomeip::message> someip_response_msg =
            vsomeip::runtime::get()->create_response(this->last_request);

        if (someip_response_msg == nullptr)
        {
          return;
        }
        auto const payload = soa_payload::create_soa_payload(msg);
        someip_response_msg->set_payload(payload);
        channel->get_app()->send(someip_response_msg);

        DI_MODEL_LOG_MCTX_INFO << "[Info] Sent : " << typeid(ResponseType).name() << std::endl;
      }
    }
  };

}  // namespace provider

namespace consumer
{

  /// @brief MessageChannel interface for vsomeip consumer. consumer is an
  /// entity that related to the vsomeip application requesting a service
  ///
  /// @details Singleton class binding a vsomeip GetRequest and GetResponse
  /// event pair with the corresponding proto messages. Object of each such
  /// event pair will be created
  ///
  /// @tparam RequestType The corresponding proto message associated with the Request
  /// @tparam ResponseType The corresponding proto message associated with the Response
  ///
  template <class RequestType, class ResponseType>
  class SYMBOL_HIDDEN MessageChannel
  {

    /// @brief  Stores the service_id, instance_id and vsomeip application ptr
    std::shared_ptr<SomeipChannel> channel = nullptr;

    /// @brief Stores method_id for the event pair
    vsomeip::method_t method_id = 0;

    /// @brief Temporary storage for the Request event to be sent. Can
    /// be used to fetch the last sent message for the event
    RequestType request_data;

    /// @brief Temporary storage for the Response event to be received. Can
    /// be used to fetch the last received message for the event
    ResponseType response_data;

    /// @brief Callback method stored as std::function object for the
    /// reception of vsomeip response messages. Specifies what operation to do
    /// after the received byte array has been converted into the
    /// protobuf Message type. Default value is nullptr. In this case just
    /// the log will be printed
    std::function<void(ResponseType const&)> response_callback{};

    /// @brief private constructor for singleton
    MessageChannel()
    {
    }

  public:
    MessageChannel(MessageChannel const&) = delete;
    MessageChannel& operator=(MessageChannel const&) = delete;

    /// @brief Getter method for the singleton class
    /// @return Returns the consumer::MessageChannel static object initialized with some
    /// template parameter
    static MessageChannel& get_instance()
    {
      static MessageChannel message_channel;
      return message_channel;
    }

    /// @brief Method to set the values of service_id, instance_id and method_id
    /// @param _channel Associated channel object specifying the service_id and instance_id
    /// @param _method_id The method_id for the events
    void initMessageChannel(std::shared_ptr<SomeipChannel> _channel, vsomeip::method_t const& _method_id)
    {
      this->channel = _channel;
      this->method_id = _method_id;
    }

    /// @brief destory the message channel
    void deinitMessageChannel()
    {
      channel.reset();
      method_id = 0;
    }

    /// @brief Getter method for the member method_id
    /// @return Returns method_id (int) for both the events
    vsomeip::method_t getMethodID() const
    {
      return this->method_id;
    }

    /// @brief Setter method for the member method_id
    /// @param _method_id The int value to be set
    void setMethodID(vsomeip::method_t const& _method_id)
    {
      this->method_id = _method_id;
    }

    /// @brief Callback method to be called when vsomeip response event
    /// is received. Converts the received vsomeip byte array to string
    /// then the string is deserialized into protubuf Message object. The
    /// type of the protobuf Message is specified by the class template
    /// parameter ResponseType. If the response_callback event is nullptr,
    /// The logs will just be printed else the callable response_callback
    /// will be called. If the value of the member workExecutor
    /// is not nullptr, the callable response_callback will be executed on the
    /// worker thread. If the value is nullptr, which is the default value,
    /// response_callback will be executed on the vsomeip listener thread itself.
    /// @param response_message Pointer to the received vsomeip::message
    void onResponse(std::shared_ptr<vsomeip::message> const& response_message)
    {
      // check if message return code is ok
      {
        auto retcode = response_message->get_return_code();
        if (retcode != vsomeip::return_code_e::E_OK)
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : Response Message return code is " << static_cast<uint32_t>(retcode)
                                  << ", Dropping the message" << std::endl;
          return;
        }
      }

      if (nullptr == response_message)
      {
        DI_MODEL_LOG_MCTX_ERROR << "[Error] : Response message is nullptr" << std::endl;
      }
      else
      {
        std::shared_ptr<vsomeip::payload> const& payload = response_message->get_payload();
        if (soa_payload::is_malformed(payload) == true)
        {
          DI_MODEL_LOG_MCTX_ERROR << "[Error] : Response payload is malformed, Dropping the message" << std::endl;
          return;
        }

        ResponseType response;

        response.ParseFromString(soa_payload::extract_protobuf(payload));
        DI_MODEL_LOG_MCTX_DEBUG << "[onResponse] onResponse Recvd : " << typeid(ResponseType).name()
                                << "on thread : " << std::this_thread::get_id() << std::endl;
        DI_MODEL_LOG_MCTX_DEBUG << "[onResponse] : " << response.DebugString() << std::endl;

        if (response_callback != nullptr)
        {
          response_callback(response);
          DI_MODEL_LOG_MCTX_DEBUG << "[Info] : Success!! onResponse Executed on thread : " << std::this_thread::get_id()
                                  << ":" << typeid(ResponseType).name() << std::endl;
        }
        else
        {
          DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : Response Callback not implemented" << std::endl;
        }
      }
    }

    /// @brief Registers the onResponse method with the vsomeip application. Wrapper
    /// for vsomeip::application->register_message_handler() for request-response
    void registerMessageHandler()
    {
      channel->get_app()->register_message_handler(
          channel->getServiceID(),
          channel->getInstanceID(),
          method_id,
          [this](std::shared_ptr<vsomeip::message> const& response_message)
          {
            this->onResponse(response_message);
          });
    }

    /// @brief deregister the message handler
    /// @satisfy{Requirement01403332}
    void deregisterMessageHandler()
    {
      channel->get_app()->unregister_message_handler(channel->getServiceID(), channel->getInstanceID(), method_id);
    }

    /// @brief Getter method for the member request_data
    /// @return Returns protobuf message type request_data.
    /// Actual type specified by the template parameter RequestType
    RequestType getLastRequestData() const
    {
      return this->request_data;
    }

    /// @brief Setter method for the member request_data
    /// @param request_message RequestType message to be set
    void setRequestData(RequestType const& request_message)
    {
      this->request_data = request_message;
    }

    /// @brief Getter method for the member response_data
    /// @return Returns protobuf message type response_data.
    /// Actual type specified by the template parameter ResponseType
    ResponseType getLastResponseData() const
    {
      return this->response_data;
    }

    /// @brief Setter method for the member response_data
    /// @param response_message ResponseType message to be set
    void setResponsedata(ResponseType const& response_message)
    {
      this->response_data = response_message;
    }

    /// @brief Setter method for the member response_callback
    /// @param fun_ptr Callable object to be set as callback
    void setResponseCallback(std::function<void(ResponseType const&)> fun_ptr)
    {
      this->response_callback = fun_ptr;
    }

    /// @brief This method converts the the protobuf message type RequestType
    /// object to string. The string is then converted to vsomeip byte array.
    /// Then a payload is created and set with the converted byte array.
    /// After setting the payload, the method finally calls
    /// vsomeip::application()->send() to send the request
    ///
    /// @satisfy{Requirement01340692}
    ///
    /// @param request_message The protobuf message of type RequestType
    /// to be sent
    void sendRequest(RequestType const& request_message)
    {
      std::string msg;
      request_message.SerializeToString(&msg);

      std::shared_ptr<vsomeip::message> someip_request = vsomeip::runtime::get()->create_request();

      if (someip_request == nullptr)
      {
        return;
      }
      someip_request->set_service(this->channel->getServiceID());
      someip_request->set_instance(this->channel->getInstanceID());
      someip_request->set_interface_version(this->channel->getMajorVersion());
      someip_request->set_method(this->method_id);

      auto const payload = soa_payload::create_soa_payload(msg);
      someip_request->set_payload(payload);

      channel->get_app()->send(someip_request);
      DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : Sent : " << typeid(RequestType).name() << std::endl;
      DI_MODEL_LOG_MCTX_DEBUG << "[sendRequest] : " << request_message.DebugString() << std::endl;
    }
  };
}  // namespace consumer

#endif
