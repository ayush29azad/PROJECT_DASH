#ifndef PROTO_DATA_CONVERTER_ENUM_HEADER
#define PROTO_DATA_CONVERTER_ENUM_HEADER

namespace jlr::cccm::di
{
  /// @brief converts proto enum to model enum
  /// @tparam model_enum_type proto enum type
  /// @tparam proto_enum_type model enum type
  /// @param dataIn const reference to proto data
  /// @param dataOut out param for model data
  /// @satisfy{Requirement01184540}
  template <typename model_enum_type, typename proto_enum_type>
  void ProtoToModelDataConverterEnum(proto_enum_type const& dataIn, model_enum_type& dataOut)
  {
    dataOut = static_cast<model_enum_type>(dataIn);
  }

  /// @brief converts model enum to proto enum
  /// @tparam proto_enum_type proto enum type
  /// @tparam model_enum_type model enum type
  /// @tparam Setter Closure type for the setter
  /// @param dataIn const reference to model data
  /// @param setter closure that will set value in proto
  /// @satisfy{Requirement01184540}
  template <typename proto_enum_type, typename model_enum_type, typename Setter>
  void ModelToProtoDataConverterEnum(model_enum_type const& dataIn, Setter& setter)
  {
    setter(static_cast<proto_enum_type>(dataIn));
  }
}  // namespace jlr::cccm::di
#endif  // PROTO_DATA_CONVERTER_ENUM_HEADER
