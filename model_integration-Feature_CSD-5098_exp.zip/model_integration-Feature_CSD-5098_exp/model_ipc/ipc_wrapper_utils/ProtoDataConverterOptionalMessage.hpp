#ifndef PROTO_DATA_CONVERTER_OPTIONAL_MESSAGE_HEADER
#define PROTO_DATA_CONVERTER_OPTIONAL_MESSAGE_HEADER

#include <utility>
#include <boost/optional.hpp>

#include "ProtoDataConverterMessage.hpp"

namespace jlr::cccm::di
{
  template <typename opt_type, typename proto_msg_type>
  void ProtoToModelDataConverterOptionalMessage(bool has_field, proto_msg_type const& field, opt_type& opt_message)
  {
    // opt_type opt_message{};

    opt_message.has_field = has_field;

    using model_msg_type = decltype(opt_message.field);

    proto_to_model_dataconverter_message(field, opt_message.field);

    // return opt_message;
  }

  template <typename opt_type, typename Mutable_retriever, typename Clearer>
  void ModelToProtoDataConverterOptionalMessage(
      opt_type const& data, Mutable_retriever& mutable_retriever, Clearer& clearer)
  {
    auto proto_msg_ptr = mutable_retriever();
    if (data.has_field)
    {
      model_to_proto_dataconverter_message(data.field, *proto_msg_ptr);
    }
    else
    {
      clearer();
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_OPTIONAL_MESSAGE_HEADER
