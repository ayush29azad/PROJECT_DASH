#ifndef PROTO_DATA_CONVERTER_OPTIONAL_BYTES_HEADER
#define PROTO_DATA_CONVERTER_OPTIONAL_BYTES_HEADER

#include <utility>
#include <boost/optional.hpp>

#include "ProtoDataConverterScalarBytes.hpp"

namespace jlr::cccm::di
{

  template <typename opt_type>
  void ProtoToModelDataConverterOptionalBytes(bool has_field, std::string const& field, opt_type& opt_bytes)
  {
    opt_bytes.has_field = has_field;

    using model_bytes_type = decltype(opt_bytes.field);
    ProtoToModelDataConverterScalarBytes<model_bytes_type>(field, opt_bytes.field);
  }

  template <typename opt_type, typename Mutable_retriever, typename Clearer>
  void ModelToProtoDataConverterOptionalBytes(
      opt_type const& data, Mutable_retriever& mutable_retriever, Clearer& clearer)
  {
    if (data.has_field)
    {
      auto* proto_bytes_opt = mutable_retriever();
      ModelToProtoDataConverterScalarBytes(data.field, *proto_bytes_opt);
    }
    else
    {
      clearer();
    }
  }

}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_OPTIONAL_BYTES_HEADER
