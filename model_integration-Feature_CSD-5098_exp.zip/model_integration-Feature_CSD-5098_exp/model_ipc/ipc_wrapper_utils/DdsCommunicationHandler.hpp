/// @file DdsCommunicationHandler.hpp
/// @brief Contains DdsCommunicationHandler class declaration
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef DDS_COMMUNICATION_HANDLER_HEADER_H
#define DDS_COMMUNICATION_HANDLER_HEADER_H

#include <DDSManager.hpp>
#include <ModelDltDefines.hpp>
#include <iostream>
#include <map>
#include <string.h>
#include <WorkExecutor.h>
#include "dlt_logger.hpp"

using namespace jlr::cccm::di::work_executor;

/// @brief Using FastDDS DataReaderListener class
using DataReaderListener = eprosima::fastdds::dds::DataReaderListener;

/// @brief using fastdds TopicDescription
using TopicDescription = eprosima::fastdds::dds::TopicDescription;

/// @brief using jlrdds DDSEntityFactoryInterface
using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;

/// @brief using jlrdds DDSManagerInterface
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;

/// @brief using jlrdds DDSManager
using DDSManager = jlr::cccm::di::dds::DDSManager;

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Class binding the DDS IPC class with the ModelClass
      /// @tparam ModelClass The class to be wrapper with DDS IPC
      class DdsCommunicationHandler : public DataReaderListener
      {

      private:
        /// @brief Map to store the registered callbacks for onDataAvailable on a topic
        std::map<std::string, std::function<void()>> m_dataAvailableCallback;

        /// @brief Pointer to the workExecutor object
        std::shared_ptr<WorkExecutor> workExecutor;

        /// @brief Mutex to sync model memory block
        std::mutex* modelMutex;

        /// @brief Pointer to DDSEntityFactory object
        std::shared_ptr<DDSEntityFactoryInterface> ddsFactory;

        /// @brief Pointer to DDSManager object
        std::shared_ptr<DDSManagerInterface> ddsManager;

      public:
        /// @brief Initializes DDS communication, wrapper over init()
        /// @param _ddsFactory DDSEntityFactory instance
        /// @param _mutex mutex for synchronisation
        /// @param dltAppId DLT application name
        /// @satisfy{Requirement01165181}
        DdsCommunicationHandler(
            std::shared_ptr<DDSEntityFactoryInterface> const _ddsFactory, std::mutex* const _mutex,
            std::string const dltAppId)
            : workExecutor(nullptr)
            , modelMutex(_mutex)
            , ddsFactory(_ddsFactory)
            , ddsManager(nullptr)
        {
          this->ddsManager = std::shared_ptr<DDSManagerInterface>(ddsFactory->create_manager(this, dltAppId));
          bool const res = ddsManager->init();
          if (!res)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[DDSCommHandler] ddsManager->init() returned false" << std::endl;
          }
        }
        /// @brief Initializes DDS communication, wrapper over init()
        /// @param ddsFactory DDSEntityFactory instance
        /// @param mutex mutex for synchronisation
        /// @param dltAppId DLT application name
        /// @param dltAppDescription DLT application description
        /// @satisfy{Requirement01165181}
        DdsCommunicationHandler(
            std::shared_ptr<DDSEntityFactoryInterface> ddsFactory, std::mutex* mutex, std::string const dltAppId,
            std::string const dltAppDescription)
        {
          this->modelMutex = mutex;
          this->ddsFactory = ddsFactory;
          this->ddsManager =
              std::shared_ptr<DDSManagerInterface>(ddsFactory->create_manager(this, dltAppId, dltAppDescription));
          bool const res = ddsManager->init();
          if (!res)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[DDSCommHandler] ddsManager->init() returned false" << std::endl;
          }
        }

        /// @brief Creates a topic to publish data over, wrapper over initTopicPubSub()
        /// @param topic Topic name as string
        /// @param type_ptr TopicDataType object pointer
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool topic_out(std::string const topic, TopicDataType* const type_ptr)
        {
          return ddsManager->register_publisher(topic, type_ptr);
        }

        /// @brief Creates a topic to subscribe to data, wrapper over initTopicPubSub()
        /// @param topic Topic name as string
        /// @param type_ptr TopicDataType object pointer
        /// @param onAvailableCallback Pointer to the function that needs to be triggered when a data is available on
        /// the topic
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool topic_in(
            std::string const topic, TopicDataType* const type_ptr,
            std::function<void(void)> const& onAvailableCallback)
        {
          bool const result = ddsManager->register_subscriber(topic, type_ptr);
          if (result)
          {
            auto const fun_ptr = [this, onAvailableCallback]()
            {
              std::lock_guard<std::mutex> lck(*(this->modelMutex));
              onAvailableCallback();
            };
            this->m_dataAvailableCallback[topic] = fun_ptr;
          }
          return result;
        }

        /// @brief on_subscription_matched
        ///
        /// @param reader Pointer to the DataReader object matched
        /// @param info Details for matched subscriber
        ///
        /// @retval true - on_subscription_matched is positive
        /// @retval false - on_subscription_matched is negative
        void on_subscription_matched(DataReader* reader, SubscriptionMatchedStatus const& info) override
        {
          (void)reader;
          if (info.current_count_change == 1)
          {
            DI_MODEL_LOG_MCTX_INFO << "[DDSCommHandler] Subscriber matched." << std::endl;
          }
          else if (info.current_count_change == -1)
          {
            DI_MODEL_LOG_MCTX_INFO << "[DDSCommHandler] Subscriber unmatched." << std::endl;
          }
          else
          {
            DI_MODEL_LOG_MCTX_INFO << info.current_count_change
                                   << " is not a valid value for SubscriptionMatchedStatus current count change"
                                   << std::endl;
          }
        }

        /// @brief Callback that handles the behaviour when a data is available in the reader buffer
        /// @brief Calls the registered on_data_available methods for the corresponding topic
        /// @param reader Pointer to the data reader
        /// @satisfy{Requirement01415483}
        void on_data_available(DataReader* reader) override
        {
          std::string const topic_name = ddsManager->get_topic_name(reader);
          auto itr = this->m_dataAvailableCallback.find(topic_name);

          if (itr != m_dataAvailableCallback.end())
          {
            itr->second();
          }
          else
          {
            // BOOST_LOG_TRIVIAL(info) << "DdsCommunicationHandler::onDataAvailable: Signal not found in map" <<
            // std::endl;
          }
        }

        /// @brief Add work Executor object to the ddsHandler to handle the OnDataAvailable callbacks
        /// @param _workExecutor Shared pointer to the work Executor object
        void set_work_executor(std::shared_ptr<WorkExecutor> const _workExecutor)
        {
          this->workExecutor = _workExecutor;
        }

        /// @brief Getter method for DDSManager instance
        /// @return Ptr to DDSManager instance
        std::shared_ptr<DDSManagerInterface> get_manager() const
        {
          return ddsManager;
        }

        /// @brief Synchronously publishes data on a topic, wrapper over DDSManager::sendData()
        /// @param data Pointer to the TopicDataType object to be sent
        /// @param topic Topic name as string
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool send(void* const data, std::string const topic)
        {
          bool const res = ddsManager->send_data(data, topic);
          if (res)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "[DDSCommHandler] data sent to topic " << topic << std::endl;
          }
          else
          {
            DI_MODEL_LOG_MCTX_ERROR << "[DDSCommHandler] data send failed for topic " << topic << std::endl;
          }
          return res;
        }

        /// @brief Synchronously reads data on a topic, wrapper over DDSManager::recvData()
        /// @param data Pointer to the TopicDataType object to be received
        /// @param topic Topic name as string
        /// @return Returns true on success else false
        /// @satisfy{Requirement01165181}
        bool recv(void* const data, std::string const topic)
        {
          bool const res = ddsManager->recv_data(data, topic);
          if (res)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "[DDSCommHandler] data recvd on topic " << topic << std::endl;
          }
          else
          {
            DI_MODEL_LOG_MCTX_ERROR << "[DDSCommHandler] data recv failed for topic " << topic << std::endl;
          }
          return res;
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
