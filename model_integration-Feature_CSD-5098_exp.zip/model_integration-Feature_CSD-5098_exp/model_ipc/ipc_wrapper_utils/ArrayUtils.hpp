#ifndef ARRAY_UTILS_HPP
#define ARRAY_UTILS_HPP

#include <cstddef>
#include <type_traits>

namespace jlr::cccm::di
{
  template <typename T, std::size_t N>
  constexpr std::size_t array_size(T (&)[N]) noexcept
  {
    return N;
  }
}  // namespace jlr::cccm::di

#endif  // ARRAY_UTILS_HPP
