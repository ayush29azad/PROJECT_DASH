/*
 * Copyright (c) 2019 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * PROPRIETARY/CONFIDENTIAL
 *
 * This software is the confidential and proprietary information of
 * SAMSUNG ELECTRONICS ("Confidential Information").
 *
 * You shall not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement
 * you entered into with SAMSUNG ELECTRONICS.
 *
 * SAMSUNG make no representations or warranties about the suitability of
 * the software, either express or implied, including but not limited to
 * the implied warranties of merchantability, fitness for a particular
 * purpose, or non-infringement. SAMSUNG shall not be liable for any
 * damages suffered by license as a result of using, modifying or
 * distributing this software or its derivatives.
 */

#ifndef _EXYNOS_BOOT_MARKER_H
#define _EXYNOS_BOOT_MARKER_H
#include <stdint.h>
#include <sys/mman.h>
// #include <aarch64/config.h>

typedef unsigned long long uint64;
typedef unsigned int uint32;

#define write32 __raw_writell
static inline void __raw_writell(uint32 val, void volatile* addr)
{
  asm volatile("str %w0, [%1]" ::"rZ"(val), "r"(addr));
}

#define read32 __raw_readll
static inline uint32 __raw_readll(void const volatile* addr)
{
  uint32 val;
  asm volatile("ldr %w0, [%1]" : "=r"(val) : "r"(addr));
  return val;
}

#define MMAP_DEV_IO(size, phys) mmap_device_io(size, phys)

/* Boot time log buffer information */
#define BOOTTIME_LOG_BASE_FROM 0xE9A41000
#define BOOTTIME_LOG_BASE_TO 0xE9C00000
#define BOOTTIME_LOG_SIZE (BOOTTIME_LOG_BASE_TO - BOOTTIME_LOG_BASE_FROM)

#ifdef CONFIG_MACHINE_EXYNOSAUTOV920
#define EXYNOS_AUTO9_RTC_TIME_INFO_BASE 0x118c0000
#else
#define EXYNOS_AUTO9_RTC_TIME_INFO_BASE 0x10540000
#endif
#define EXYNOS_AUTO9_RTC_CURTICCNT_0 (EXYNOS_AUTO9_RTC_TIME_INFO_BASE + 0x90)
#define EXYNOS_AUTO9_RTC_TICCKSEL_0 (EXYNOS_AUTO9_RTC_TIME_INFO_BASE + 0x38)

// Time Stamp size per core
#define EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE 8 * 1024

/* QNX Category ID */
#define EXYNOSAUTO_TIMELINE_QNX_BASE 0xA0000000

/* QNX Internal IDs */
#define MAIN_START 0x01000
#define FDT_INIT 0x02000
#define INIT_RAMINFO 0x03000
#define INIT_SMP 0x04000
#define INIT_MMU 0x05000
#define INIT_INTR 0x06000
#define INIT_QTIME 0x07000
#define INIT_CPUINFO 0x08000
#define INIT_PADS 0x09000
#define INIT_PWM 0x0a000
#define RAM_RESV_DONE 0x0b000
#define SMP_HOOK_DONE 0x0c000
#define INIT_SYS_PRV 0x0d000
#define BRD_MMU_DISABLE 0x0e000
#define MAIN_END 0x0f000
#define SER_START 0x10000
#define SER_END 0x11000
#define UFS_START 0x12000
#define UFS_END 0x13000
#define I2C_START 0x14000
#define I2C_END 0x15000
#define SPI_START 0x16000
#define SPI_END 0x17000
#define MFC_START 0x18000
#define MFC_END 0x19000
#define RESMEM_START 0x1A000
#define RESMEM_END 0x1B000
#define WFD_INIT 0x20000
#define WFD_INIT_END_DSI0 0x21000
#define WFD_INIT_END_DSI1 0x22000
#define WFD_INIT_END_DP0 0x23000
#define WFD_INIT_END_DP1 0x24000
#define DSI0_BRIDGE_DETECT_START 0x25000
#define DSI1_BRIDGE_DETECT_START 0x26000
#define DP0_DETECT_START 0x27000
#define DP1_DETECT_START 0x28000
#define DSI0_BRIDGE_DETECT_END 0x29000
#define DSI1_BRIDGE_DETECT_END 0x2A000
#define DP0_DETECT_END 0x2B000
#define DP1_DETECT_END 0x2C000
#define DP0_LT_START 0x2D000
#define DP0_LT_END 0x2E000
#define DP1_LT_START 0x2F000
#define DP1_LT_END 0x30000
#define WFD_LOGO_START_DSI0 0x31000
#define WFD_LOGO_END_DSI0 0x32000
#define WFD_LOGO_START_DSI1 0x33000
#define WFD_LOGO_END_DSI1 0x34000
#define WFD_LOGO_START_DP0 0x35000
#define WFD_LOGO_END_DP0 0x36000
#define WFD_LOGO_START_DP1 0x37000
#define WFD_LOGO_END_DP1 0x38000
#define DRV_INIT_START 0x39000
#define AUD_LOAD_START 0x3A000
#define AUD_LOAD_END 0x3B000
#define ETHERNET_START 0x3C000
#define ETHERNET_END 0x3D000
#define GPU_SUSPEND_START 0x3E000
#define GPU_SUSPEND_END 0x3F000
#define GPU_RESUME_START 0x40000
#define GPU_RESUME_END 0x41000
#define DPU_SUSPEND_START 0x42000
#define DPU_SUSPEND_END 0x43000
#define DPU_RESUME_START 0x44000
#define DPU_RESUME_END 0x45000
#define HC_SUSPEND_START 0x46000
#define HC_SUSPEND_END 0x47000
#define HC_RESUME_START 0x48000
#define HC_RESUME_END 0x49000
#define DC_SUSPEND_START 0x4A000
#define DC_SUSPEND_END 0x4B000
#define DC_RESUME_START 0x4C000
#define DC_RESUME_END 0x4D000
#define SER_SUSPEND_START 0x4E000
#define SER_SUSPEND_END 0x4F000
#define SER_RESUME_START 0x50000
#define SER_RESUME_END 0x51000
#define SPI_SUSPEND_START 0x52000
#define SPI_SUSPEND_END 0x53000
#define SPI_RESUME_START 0x54000
#define SPI_RESUME_END 0x55000
#define TMU_SUSPEND_START 0x56000
#define TMU_SUSPEND_END 0x57000
#define TMU_RESUME_START 0x58000
#define TMU_RESUME_END 0x59000
#define I2C_SUSPEND_START 0x5A000
#define I2C_SUSPEND_END 0x5B000
#define I2C_RESUME_START 0x5C000
#define I2C_RESUME_END 0x5D000
#define AUD_SUSPEND_START 0x5E000
#define AUD_SUSPEND_END 0x5F000
#define AUD_RESUME_START 0x60000
#define AUD_RESUME_END 0x61000
#define WD_SUSPEND_START 0x62000
#define WD_SUSPEND_END 0x63000
#define WD_RESUME_START 0x64000
#define WD_RESUME_END 0x65000
#define PWM_SUSPEND_START 0x66000
#define PWM_SUSPEND_END 0x67000
#define PWM_RESUME_START 0x68000
#define PWM_RESUME_END 0x69000
#define UFS_SUSPEND_START 0x6A000
#define UFS_SUSPEND_END 0x6B000
#define UFS_RESUME_START 0x6C000
#define UFS_RESUME_END 0x6D000
#define PINCTL_SUSPEND_START 0x6E000
#define PINCTL_SUSPEND_END 0x6F000
#define PINCTL_RESUME_START 0x70000
#define PINCTL_RESUME_END 0x71000
#define BTS_SUSPEND_START 0x72000
#define BTS_SUSPEND_END 0x73000
#define BTS_RESUME_START 0x74000
#define BTS_RESUME_END 0x75000
#define IOPKT_SUSPEND_START 0x76000
#define IOPKT_SUSPEND_END 0x77000
#define IOPKT_RESUME_START 0x78000
#define IOPKT_RESUME_END 0x79000
#define ITMON_SUSPEND_START 0x7A000
#define ITMON_SUSPEND_END 0x7B000
#define ITMON_RESUME_START 0x7C000
#define ITMON_RESUME_END 0x7D000
#define CAM_SUSPEND_START 0x7E000
#define CAM_SUSPEND_END 0x7F000
#define CAM_RESUME_START 0x80000
#define CAM_RESUME_END 0x81000
#define SMFC_SUSPEND_START 0x82000
#define SMFC_SUSPEND_END 0x83000
#define SMFC_RESUME_START 0x84000
#define SMFC_RESUME_END 0x85000
#define SMFC_RM_INIT_START 0x86000
#define SMFC_RM_INIT_END 0x87000
#define CAM_RM_INIT_START 0x88000
#define CAM_RM_INIT_END 0x89000
#define MMAN_RM_INIT_START 0x8A000
#define MMAN_RM_INIT_END 0x8B000
#define WFD_FRAME_DONE_DSI0 0x8C000
#define WFD_FRAME_DONE_DSI1 0x8D000
#define WFD_FRAME_DONE_DP0 0x8E000
#define WFD_FRAME_DONE_DP1 0x8F000
#define GPU_INIT_START_G3D00 0x90000
#define GPU_INIT_END_G3D00 0x91000
#define GPU_INIT_START_G3D01 0x92000
#define GPU_INIT_END_G3D01 0x93000
#define SFI_START 0x94000
#define SFI_END 0x95000
#define QNX_SUSPEND_START 0x96000
#define EXYNOS_PM_SUSPEND_START 0x97000
#define QNX_EXYNOS_PM_SUSPEND_END 0x98000
#define QNX_EXYNOS_PM_RESUME_START 0x99000
#define EXYNOS_PM_RESUME_END 0x9A000
#define INIT_VMMGR_APP 0X9B000
#define INIT_GP_DIAG_APP 0X9C000
#define DIAG_SYSTEM_READY 0X9D000
#define DIMMGR_INIT 0X9E000
#define DIMMGR_SOMEIPSTART 0X9F000

// This is for DI HMI from 0xB0000 to 0xC0000
#define SPLASH_MAIN_START 0xB0000
#define SPLASH_READ_JPEG 0xB1000
#define SPLASH_FIRST_FRAME 0xB2000
#define SPLASH_MAIN_END 0xB3000
#define RVC_CAMERA_INTERFACE_READY 0xB4000
#define RVC_LINK_VIDEO_LOCK_STATUS 0xB5000
#define RVC_REVERSE_GEAR_RECEIVED 0xB6000
#define RVC_STREAM_ON 0xB7000
#define RVC_ON_FCD 0xB8000
#define HMI_TOUCH_REQUEST_VIEW 0xBB000
#define SOMEIP_REQUEST_SENT 0xBC000
#define SOMEIP_RESPONSE_FOR_REQUEST 0xBD000
#define HMI_SET_PROPERTY_VIEW_ON_DISPLAY 0xBE000
#define DSA_MAIN_START 0xBE001
#define DSA_FIRST_FRAME 0xBE002
#define QNX_FULL_RUN 0xBE003
#define QNX_RESUME_START 0xBE004
#define ANDROID_RESUME_START 0xBE005
#define QNX_SUSPEND_TRIGGER 0xBE006
#define ADSP_AUDIO_STOP 0xBE007
#define ANDROID_SUSPEND_START 0xBE008
#define ANDROID_READY_TO_SUSPEND 0xBE009
#define ANDROID_SUSPEND_COMPLETE 0xBE00A
#define SFI_SHUTDOWN_COMPLETE 0xBE00B
#define ADSP_SHUTDOWN_COMPLETE 0xBE00C

// This is for Visteon-SFI from 0xD0000 to 0xDFFFF
#define SAFEHMI_HMI_MAIN_START 0xDB000
#define SAFEHMI_HMI_FIRST_FRAME 0xDC000
#define SAFEHMI_HMI_GEAR_MSG_CHANGED_RCVD 0xDD000
#define SAFEHMI_HMI_GEAR_MSG_CHANGED_FORWD 0xDE000

// This is for JLR DI features from 0XE0000 to 0xE3043

#define PCOM_INIT_START 0XE0000
#define PCOM_INIT_END 0XE1000
#define DI_HMI_APP_INIT_START 0xE2000
#define DI_HMI_APP_CHARGE_SCREEN_RENDERED 0xE2001
#define DI_HMI_APP_FIRST_FRAME_DRIVING_FULL 0xE2002
#define DI_HMI_APP_FIRST_FRAME_RENDERED 0xE2100
#define DI_COMFORT_WRITER 0xE2503
#define VAL_AMBLIGHTSENSOR_INIT_START 0xE3000
#define VAL_AMBLIGHTSENSOR_INIT_END 0xE3001
#define VAL_APERTURES_INIT_START 0xE3002
#define VAL_APERTURES_INIT_END 0xE3003
#define VAL_AUDIO_INIT_START 0xE3004
#define VAL_AUDIO_INIT_END 0xE3005
#define VAL_BODY_INIT_START 0xE3006
#define VAL_BODY_INIT_END 0xE3007
#define VAL_CLIMATE_INIT_START 0xE3008
#define VAL_CLIMATE_INIT_END 0xE3009
#define VAL_ENERMGMT_INIT_START 0xE300A
#define VAL_ENERMGMT_INIT_END 0xE300B
#define VAL_EVRANGEONROUTE_INIT_START 0xE300C
#define VAL_EVRANGEONROUTE_INIT_END 0xE300D
#define VAL_EXTERIORLIGHTING_INIT_START 0xE300E
#define VAL_EXTERIORLIGHTING_INIT_END 0xE300F
#define VAL_INTERIORLIGHTING_INIT_START 0xE3010
#define VAL_INTERIORLIGHTING_INIT_END 0xE3011
#define VAL_MOTION_INIT_START 0xE3012
#define VAL_MOTION_INIT_END 0xE3013
#define VAL_NAVIGATION_INIT_START 0xE3014
#define VAL_NAVIGATION_INIT_END 0xE3015
#define VAL_OCCUPANTSAFETY_INIT_START 0xE3016
#define VAL_OCCUPANTSAFETY_INIT_END 0xE3017
#define VAL_ODOMETERCLIENT_INIT_START 0xE3018
#define VAL_ODOMETERCLIENT_INIT_END 0xE3019
#define VAL_ODOCNT_INIT_START 0xE301A
#define VAL_ODOCNT_INIT_END 0xE301B
#define VAL_PROPULSION_INIT_START 0xE301C
#define VAL_PROPULSION_INIT_END 0xE301D
#define VAL_SEATS_INIT_START 0xE301E
#define VAL_SEATS_INIT_END 0xE301F
#define VAL_SHORTEHORIZON_INIT_START 0xE3020
#define VAL_SHORTEHORIZON_INIT_END 0xE3021
#define VAL_STEERINGWHEELSW_INIT_START 0xE3022
#define VAL_STEERINGWHEELSW_INIT_END 0xE3023
#define VAL_SUSPENSION_INIT_START 0xE3024
#define VAL_SUSPENSION_INIT_END 0xE3025
#define VAL_TELEMATICS_INIT_START 0xE3026
#define VAL_TELEMATICS_INIT_END 0xE3027
#define VAL_TELLTALE_INIT_START 0xE3028
#define VAL_TELLTALE_INIT_END 0xE3029
#define VAL_TUNER_INIT_START 0xE302A
#define VAL_TUNER_INIT_END 0xE302B
#define VAL_VEHICLEMESSAGING_INIT_START 0xE302C
#define VAL_VEHICLEMESSAGING_INIT_END 0xE302D
#define VAL_VEHICLEPOSITION_INIT_START 0xE302E
#define VAL_VEHICLEPOSITION_INIT_END 0xE302F
#define VAL_VEHICLESPEED_INIT_START 0xE3030
#define VAL_VEHICLESPEED_INIT_END 0xE3031
#define VAL_VISIBILITY_INIT_START 0xE3032
#define VAL_VISIBILITY_INIT_END 0xE3033
#define VAL_VKMSABS_INIT_START 0xE3034
#define VAL_VKMSABS_INIT_END 0xE3035
#define VAL_VKMSINVA_INIT_START 0xE3036
#define VAL_VKMSINVA_INIT_END 0xE3037
#define VAL_VKMSINVB_INIT_START 0xE3038
#define VAL_VKMSINVB_INIT_END 0xE3039
#define VAL_VKMSINVD_INIT_START 0xE303A
#define VAL_VKMSINVD_INIT_END 0xE303B
#define VAL_VKMSPKCM_INIT_START 0xE303C
#define VAL_VKMSPKCM_INIT_END 0xE303D
#define VAL_VKMSPSCM1_INIT_START 0xE303E
#define VAL_VKMSPSCM1_INIT_END 0xE303F
#define VAL_VKMSPSCM2_INIT_START 0xE3040
#define VAL_VKMSPSCM2_INIT_END 0xE3041
#define VAL_VKMSRSCM_INIT_START 0xE3042
#define VAL_VKMSRSCM_INIT_END 0xE3043
#define VAL_TRIPCOMPUTER_INIT_START 0xE3044
#define VAL_TRIPCOMPUTER_INIT_END 0xE3045
#define VAL_PREDICTNRGOPTIM_INIT_START 0xE3046
#define VAL_PREDICTNRGOPTIM_INIT_END 0xE3047
#define VAL_VKMSTCUA_INIT_START 0xE3048
#define VAL_VKMSTCUA_INIT_END 0xE3049
#define VAL_ACTIVESAFETY_INIT_START 0xE3050
#define VAL_ACTIVESAFETY_INIT_END 0xE3051
#define VAL_VEHICLEMAINTEN_INIT_START 0xE3052
#define VAL_VEHICLEMAINTEN_INIT_END 0xE3053

// This is for VLAN APP Start(0XE3100) and End(0XE3101)
#define VLAN_APP_START 0XE3100
#define VLAN_APP_END 0XE3101

#define MTOUCH_START 0xE3200

#define QNX_TIME_STAMP(A, B, C) exynosauto_log_timestamp(A, B, C)

static inline void exynosauto_log_timestamp(int core, uint32 categoryIndex, uint32 partIndex)
{
  uint64 currentRTC = 0;
  uint64 nextlogOffset = 0, rtc_base;
  core = 0;
  uint64 timebase =
      MMAP_DEV_IO(BOOTTIME_LOG_SIZE, BOOTTIME_LOG_BASE_FROM + (core * EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE));

  nextlogOffset = read32((void*)timebase) + 0x10;
  if (nextlogOffset < EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE &&
      (core * EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE + nextlogOffset) < BOOTTIME_LOG_SIZE)
  {
    write32(nextlogOffset, (void*)timebase);

    write32(categoryIndex, (void*)(timebase + nextlogOffset));
    write32(partIndex, (void*)(timebase + nextlogOffset + 0x4));

    rtc_base = MMAP_DEV_IO(4, EXYNOS_AUTO9_RTC_CURTICCNT_0);

    currentRTC = read32((void*)rtc_base);
    write32(currentRTC, (void*)(timebase + nextlogOffset + 0x8));
    munmap_device_io(rtc_base, 4);
  }
  munmap_device_io(timebase, BOOTTIME_LOG_SIZE);
  return;
}

#define QNX_TIME_STAMP_PHYS(A, B, C) exynosauto_log_timestamp_phys(A, B, C)

static inline void exynosauto_log_timestamp_phys(int core, uint32 categoryIndex, uint32 partIndex)
{
  uint64 currentRTC = 0;
  uint64 nextlogOffset = 0, rtc_base;
  core = 0;
  uint64 timebase = BOOTTIME_LOG_BASE_FROM + (core * EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE);

  nextlogOffset = read32((void*)timebase) + 0x10;
  if (nextlogOffset < EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE &&
      (core * EXYNOSAUTO_TIMESTAMP_PER_CORE_SIZE + nextlogOffset) < BOOTTIME_LOG_SIZE)
  {
    write32(nextlogOffset, (void*)timebase);

    write32(categoryIndex, (void*)(timebase + nextlogOffset));
    write32(partIndex, (void*)(timebase + nextlogOffset + 0x4));

    rtc_base = EXYNOS_AUTO9_RTC_CURTICCNT_0;

    currentRTC = read32((void*)rtc_base);
    write32(currentRTC, (void*)(timebase + nextlogOffset + 0x8));
  }
  return;
}

#endif /* _EXYNOS_BOOT_MARKER_H */
