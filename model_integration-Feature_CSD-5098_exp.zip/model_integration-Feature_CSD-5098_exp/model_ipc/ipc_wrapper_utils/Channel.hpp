/// @file Channel.hpp
/// @brief Contains Channel class declaration
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef CHANNEL_HEADER_H
#define CHANNEL_HEADER_H

#include <iostream>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      /// @brief
      class Channel
      {
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
