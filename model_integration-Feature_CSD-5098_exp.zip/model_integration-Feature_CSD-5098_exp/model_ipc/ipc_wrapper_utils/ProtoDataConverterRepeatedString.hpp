#ifndef PROTO_DATA_CONVERTER_REPEATED_STRING
#define PROTO_DATA_CONVERTER_REPEATED_STRING

#include <google/protobuf/repeated_field.h>

#include <stdexcept>
#include <utility>
#include <type_traits>

#include "ProtoDataConverterScalarString.hpp"
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto repeated string to model repeated string
  /// @tparam model_rep_type model repeated type
  /// @param proto_rep_data const reference to proto data
  /// @param model_rep_data out param for model data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type>
  void ProtoToModelDataConverterRepeatedString(
      google::protobuf::RepeatedPtrField<std::string> const& proto_rep_data, model_rep_type& model_rep_data)
  {

    // model_rep_type model_rep_data{};

    using model_string_type = typename std::remove_all_extents<decltype(model_rep_data.payload)>::type;

    size_t max_size;

    if (static_cast<std::size_t>(proto_rep_data.size()) <= array_size(model_rep_data.payload))
    {
      max_size = static_cast<std::size_t>(proto_rep_data.size());
    }
    else
    {
      max_size = array_size(model_rep_data.payload);
    }

    model_rep_data.payload_length = max_size;

    for (size_t i = 0; i < max_size; ++i)
    {
      std::string const& proto_string_data = proto_rep_data.Get(static_cast<int32_t>(i));
      ProtoToModelDataConverterScalarString<model_string_type>(proto_string_data, model_rep_data.payload[i]);
    }

    // return model_rep_data;
  }

  /// @brief converts model repeated string to proto repeated string
  /// @tparam model_rep_type model repeated type
  /// @param model_rep_data const reference to model data
  /// @param proto_rep_data out param for proto data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type>
  void ModelToProtoDataConverterRepeatedString(
      model_rep_type const& model_rep_data, google::protobuf::RepeatedPtrField<std::string>& proto_rep_data)
  {

    if (model_rep_data.payload_length > array_size(model_rep_data.payload))
    {
      throw std::invalid_argument("Model repeated input has invalid payload_length");
    }

    proto_rep_data.Clear();

    for (size_t i = 0; i < model_rep_data.payload_length; ++i)
    {
      std::string temp_str;
      ModelToProtoDataConverterScalarString(model_rep_data.payload[i], temp_str);
      proto_rep_data.Add(std::move(temp_str));
    }
  }
}  // namespace jlr::cccm::di
#endif  // PROTO_DATA_CONVERTER_REPEATED_STRING
