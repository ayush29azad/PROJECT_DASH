#ifndef PROTO_DATA_CONVERTER_REPEATED_MESSAGE
#define PROTO_DATA_CONVERTER_REPEATED_MESSAGE

#include <google/protobuf/repeated_field.h>

#include <stdexcept>
#include <type_traits>

#include "ProtoDataConverterMessage.hpp"
#include "ArrayUtils.hpp"

namespace jlr::cccm::di
{
  /// @brief converts proto repeated message to model repeated message
  /// @tparam model_rep_type model repeated type
  /// @tparam proto_message_type proto message type
  /// @param proto_rep_data const reference to proto data
  /// @param model_rep_data out param for model data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type, typename proto_message_type>
  void ProtoToModelDataConverterRepeatedMessage(
      google::protobuf::RepeatedPtrField<proto_message_type> const& proto_rep_data, model_rep_type& model_rep_data)
  {

    // using model_message_type = typename std::remove_all_extents<decltype(model_rep_data.payload)>::type;

    size_t max_size;

    if (static_cast<std::size_t>(proto_rep_data.size()) <= array_size(model_rep_data.payload))
    {
      max_size = static_cast<std::size_t>(proto_rep_data.size());
    }
    else
    {
      max_size = array_size(model_rep_data.payload);
    }

    model_rep_data.payload_length = max_size;

    for (size_t i = 0; i < max_size; ++i)
    {
      proto_message_type const& proto_message_data = proto_rep_data.Get(static_cast<int32_t>(i));
      proto_to_model_dataconverter_message(proto_message_data, model_rep_data.payload[i]);
    }
  }

  /// @brief converts model repeated message to proto repeated message
  /// @tparam model_rep_type model repeated type
  /// @tparam proto_message_type proto message type
  /// @param model_rep_data const reference to mdel data
  /// @param proto_rep_data out param for proto data
  /// @satisfy{Requirement01184576}
  template <typename model_rep_type, typename proto_message_type>
  void ModelToProtoDataConverterRepeatedMessage(
      model_rep_type const& model_rep_data, google::protobuf::RepeatedPtrField<proto_message_type>& proto_rep_data)
  {

    if (model_rep_data.payload_length > array_size(model_rep_data.payload))
    {
      throw std::invalid_argument("Model repeated input has invalid payload_length");
    }

    proto_rep_data.Clear();

    for (size_t i = 0; i < model_rep_data.payload_length; ++i)
    {

      auto* const proto_msg = proto_rep_data.Add();  // Allocates and appends a new message
      model_to_proto_dataconverter_message(model_rep_data.payload[i], *proto_msg);
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_REPEATED_MESSAGE
