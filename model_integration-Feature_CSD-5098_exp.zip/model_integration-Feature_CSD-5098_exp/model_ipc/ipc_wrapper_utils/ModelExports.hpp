/// @file ModelExports.hpp
/// @brief Exported symbol marcos
///
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2025

#ifndef JLR_CCCM_DI_MODEL_SYMBOL_EXPORTS_H
#define JLR_CCCM_DI_MODEL_SYMBOL_EXPORTS_H

/// @brief macro to mark symbol visibility as hidden
#define SYMBOL_HIDDEN __attribute__((visibility("hidden")))

/// @brief macro to mark symbol visibility as default
#define SYMBOL_DEFAULT __attribute__((visibility("default")))

#endif  // JLR_CCCM_DI_MODEL_SYMBOL_EXPORTS_H
