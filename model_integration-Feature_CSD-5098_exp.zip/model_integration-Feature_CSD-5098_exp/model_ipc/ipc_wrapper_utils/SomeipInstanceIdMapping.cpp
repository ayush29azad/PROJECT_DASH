#include "SomeipInstanceIdMapping.hpp"
#include <fstream>

namespace ipc_wrapper
{

  namespace instance_id_mapping
  {

    ServiceInstanceIdMapping::ServiceInstanceIdMapping()
        : parsed(false)
    {
      service_instanceId_mapping = {
          {"charging_service", static_cast<vsomeip::instance_t>(1)},
          {"vehiclespeed_service", static_cast<vsomeip::instance_t>(1)},
          {"exterior_lighting_service", static_cast<vsomeip::instance_t>(1)},
          {"energymanagement_service", static_cast<vsomeip::instance_t>(1)},
          {"featureconfig_cccmuserapps_service", static_cast<vsomeip::instance_t>(1)},
          {"odometer_service", static_cast<vsomeip::instance_t>(1)},
          {"odometerrollingcount_service", static_cast<vsomeip::instance_t>(1)},
          {"vehiclemessaging_service", static_cast<vsomeip::instance_t>(1)},
          {"suspension_service", static_cast<vsomeip::instance_t>(1)},
          {"lifecycle_cccmuserapps_vlca_service", static_cast<vsomeip::instance_t>(1)},
          {"motion_service", static_cast<vsomeip::instance_t>(1)},
          {"motion_setting_service", static_cast<vsomeip::instance_t>(1)},
          {"propulsion_service", static_cast<vsomeip::instance_t>(1)},
          {"apertures_service", static_cast<vsomeip::instance_t>(1)},
          {"steering_service", static_cast<vsomeip::instance_t>(1)},
          {"telltale_service", static_cast<vsomeip::instance_t>(1)},
          {"speedometerunits_service", static_cast<vsomeip::instance_t>(1)},
          {"golden_client_service", static_cast<vsomeip::instance_t>(1)},
          {"golden_server_service", static_cast<vsomeip::instance_t>(1)},
          {"golden2_service", static_cast<vsomeip::instance_t>(1)},
          {"steering_wheel_switch_service", static_cast<vsomeip::instance_t>(1)},
          {"audio_service", static_cast<vsomeip::instance_t>(1)},
          {"occupant_safety_service", static_cast<vsomeip::instance_t>(1)},
          {"cockpit_persistency_service", static_cast<vsomeip::instance_t>(1)},
          {"pps_climate_service", static_cast<vsomeip::instance_t>(1)},
          {"navigation_service", static_cast<vsomeip::instance_t>(1)},
          {"cockpit_settings_service", static_cast<vsomeip::instance_t>(1)},
          {"ivi_messaging_service", static_cast<vsomeip::instance_t>(1)},
          {"di_display_context_service", static_cast<vsomeip::instance_t>(1)},
          {"pps_apertures_service", static_cast<vsomeip::instance_t>(1)},
          {"pps_access_service", static_cast<vsomeip::instance_t>(1)},
          {"vehicle_maintenance_service", static_cast<vsomeip::instance_t>(1)}};
    }

    bool ServiceInstanceIdMapping::parse_json(std::string const& filename)
    {
      std::ifstream input_file(filename, std::ifstream::binary);
      if (!input_file.is_open())
      {
        DI_MODEL_LOG_MCTX_ERROR << "Could not open the file: " << filename << std::endl;
        return false;
      }

      Json::Value root;

      try
      {
        Json::CharReaderBuilder const builder;
        std::string errs;
        if (!Json::parseFromStream(builder, input_file, &root, &errs))
        {
          DI_MODEL_LOG_MCTX_ERROR << "Failed to parse JSON: " << errs << std::endl;
          return false;
        }
      }
      catch (std::exception const& e)
      {
        DI_MODEL_LOG_MCTX_ERROR << "Exception while parsing JSON: " << e.what() << std::endl;
        return false;
      }
      catch (...)
      {
        DI_MODEL_LOG_MCTX_ERROR << "Unknow Exception while parsing JSON: " << std::endl;
        return false;
      }

      input_file.close();

      bool const has_service_instanceId_mapping = root.isMember("service_instanceId_mapping");

      if (has_service_instanceId_mapping)
      {
        Json::Value const& mapping = root["service_instanceId_mapping"];
        for (std::string const& key : mapping.getMemberNames())
        {
          service_instanceId_mapping[key] = mapping[key].asUInt();
        }
      }

      parsed = has_service_instanceId_mapping;
      return parsed;
    }

    void ServiceInstanceIdMapping::print() const
    {
      DI_MODEL_LOG_MCTX_INFO << "Service Instance ID Mapping:\n";
      for (auto it = service_instanceId_mapping.begin(); it != service_instanceId_mapping.end(); ++it)
      {
        DI_MODEL_LOG_MCTX_INFO << it->first << ": " << it->second << "\n";
      }
      DI_MODEL_LOG_MCTX_INFO << "Parsed Correctly: " << (parsed ? "true" : "false") << "\n";
    }

    vsomeip::instance_t ServiceInstanceIdMapping::get_service_instanceId(std::string const& key)
    {
      auto it = service_instanceId_mapping.find(key);
      if (it != service_instanceId_mapping.end())
      {
        return it->second;
      }
      else
      {
        DI_MODEL_LOG_MCTX_ERROR << "instance id not found for service: " << key << std::endl;

        service_instanceId_mapping[key] = DEFAULT_INSTANCE_ID_UNKNOWN_SERVICE;
        DI_MODEL_LOG_MCTX_INFO << "using default instance id " << DEFAULT_INSTANCE_ID_UNKNOWN_SERVICE
                               << " for service: " << key << std::endl;
        return static_cast<vsomeip::instance_t>(DEFAULT_INSTANCE_ID_UNKNOWN_SERVICE);
      }
    }

  }  // namespace instance_id_mapping

}  // namespace ipc_wrapper
