#ifndef PROTO_DATA_CONVERTER_OPTIONAL_STRING_HEADER
#define PROTO_DATA_CONVERTER_OPTIONAL_STRING_HEADER

#include <utility>
#include <boost/optional.hpp>

#include "ProtoDataConverterScalarString.hpp"

namespace jlr::cccm::di
{
  template <typename opt_type>
  void ProtoToModelDataConverterOptionalString(bool has_field, std::string const& field, opt_type& opt_string)
  {

    opt_string.has_field = has_field;

    using model_string_type = decltype(opt_string.field);

    ProtoToModelDataConverterScalarString<model_string_type>(field, opt_string.field);
  }

  template <typename opt_type, typename Mutable_retriever, typename Clearer>
  void ModelToProtoDataConverterOptionalString(
      opt_type const& data, Mutable_retriever& mutable_retriever, Clearer& clearer)
  {  // std::string& proto_string_opt){
    if (data.has_field)
    {
      auto* proto_string_opt = mutable_retriever();
      ModelToProtoDataConverterScalarString(data.field, *proto_string_opt);
    }
    else
    {
      clearer();
    }
  }
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_OPTIONAL_STRING_HEADER
