#ifndef SERVICE_INSTANCE_ID_MAPPING_HPP
#define SERVICE_INSTANCE_ID_MAPPING_HPP

#include <json/json.h>
#include <map>
#include <iostream>
#include <string>
#include <vsomeip/vsomeip.hpp>

#include <dlt_logger.hpp>

namespace ipc_wrapper
{

  namespace instance_id_mapping
  {

    /// @brief Default someip instance id for the services not found in the default map
    vsomeip::instance_t const DEFAULT_INSTANCE_ID_UNKNOWN_SERVICE = static_cast<vsomeip::instance_t>(1);

    /// @brief Class responsible for keeping someip instance ids and model_playback enable/disable flag.
    /// Default values can be overridden by the JSON file.
    class ServiceInstanceIdMapping
    {
    public:
      /// @brief Constructor, initializes the default values.
      ServiceInstanceIdMapping();

      /// @brief Parses the JSON file to populate values.
      /// @param filename Filepath to be parsed.
      /// @return True if JSON was parsed correctly, else false.
      bool parse_json(std::string const& filename);

      /// @brief Prints the parsed data.
      void print() const;

      /// @brief Returns the service instance ID for the given key.
      /// @param key The service name.
      /// @return The instance ID for the service, or a default value if the key is not found.
      vsomeip::instance_t get_service_instanceId(std::string const& key);

    private:
      /// @brief  Map storing service instance IDs.
      std::map<std::string, vsomeip::instance_t> service_instanceId_mapping;

      /// @brief Flag indicating if the JSON was parsed correctly.
      bool parsed;
    };

  }  // namespace instance_id_mapping

}  // namespace ipc_wrapper

#endif  // SERVICE_INSTANCE_ID_MAPPING_HPP
