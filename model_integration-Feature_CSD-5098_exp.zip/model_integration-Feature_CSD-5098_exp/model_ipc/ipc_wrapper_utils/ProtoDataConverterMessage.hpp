#ifndef PROTO_DATA_CONVERTER_MESSAGE_HEADER
#define PROTO_DATA_CONVERTER_MESSAGE_HEADER

#include <memory>

namespace jlr::cccm::di
{
  template <typename proto_type, typename model_type>
  void proto_to_model_dataconverter_message(proto_type const&, model_type&);

  template <typename model_type, typename proto_type>
  void model_to_proto_dataconverter_message(model_type const&, proto_type&);
}  // namespace jlr::cccm::di

#endif  // PROTO_DATA_CONVERTER_MESSAGE_HEADER
