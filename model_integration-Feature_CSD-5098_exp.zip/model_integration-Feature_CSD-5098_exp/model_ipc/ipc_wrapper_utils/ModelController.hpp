/// @file ModelController.hpp
/// @brief Defines ModelController class
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date July 2023

#ifndef MODEL_CONROLLER_HEADER_H
#define MODEL_CONROLLER_HEADER_H

#include <unordered_map>
#include <DdsCommunicationHandler.hpp>
#include <SomeipCommunicationHandler.hpp>
#include <TimerHandler.hpp>
#include "ModelControllerInterface.hpp"

// todo : static allocation wherever possible
// todo : put into namespaces
// todo : ensure header guards
namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      /// @brief Singleton Class for binding the ModelClass with the IPC and the timer
      /// @tparam ModelClass The model class
      /// functions from model struct to proto and vice-versa
      template <typename ModelClass>
      class ModelController : public IModelController
      {

      private:
        /// @brief Stores the pointer to the model object
        std::shared_ptr<ModelClass> model_ptr = nullptr;

        /// @brief Vector of the pointers to the SomeipCommunicationHandler class
        /// SomeipCommunicationHandler class is responsible for managing
        /// vsomeip communication
        std::unordered_map<std::string, std::shared_ptr<SomeipCommunicationHandler>> someip_handler;

        /// @brief Stores the pointer to the DdsCommunicationHandler class
        /// DdsCommunicationHandler class is responsible for managing
        /// dds communication
        std::shared_ptr<DdsCommunicationHandler> dds_handler = nullptr;

        /// @brief Stores the pointer to the Timer class. Timer class
        /// handles the timer associated with the model
        std::shared_ptr<Timer> timerHandler = nullptr;

        /// @brief mutex for synchronizing model functions
        std::mutex model_mutex;

      public:
        /// @brief default constructor
        ModelController() = default;

        ModelController(ModelController const&) = delete;
        ModelController& operator=(ModelController const&) = delete;

        /// @brief Stores ModelClass pointer internally and initialises model
        /// @param _model_ptr ModelClass pointer
        void init_model(std::shared_ptr<ModelClass> const& _model_ptr)
        {
          model_ptr = _model_ptr;

          if (model_ptr != nullptr)
          {
            model_ptr->initialize();
            DI_MODEL_LOG_MCTX_INFO << "[Info] : Initialized Model Class" << std::endl;
          }
          else
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : Couldn't initialize Model Class" << std::endl;
          }
        }

        /// @brief Initializes the vsomeip communication required for the model
        /// @param app vsomeip::application pointer, provided by model_launcher
        /// @param appName std::string, provided by model_launcher
        void init_model_someip(std::shared_ptr<vsomeip::application> const app, std::string appName)
        {
          auto const someipCommunicationHander = std::make_shared<SomeipCommunicationHandler>(app, &model_mutex);
          someip_handler[appName] = someipCommunicationHander;
          DI_MODEL_LOG_MCTX_INFO << "[Info] : Initialized VSOMEIP " << appName << std::endl;
        }

        /// @brief Initializes the dds communication required for the model
        void init_model_dds(
            std::shared_ptr<jlr::cccm::di::dds::DDSEntityFactoryInterface> factory, std::string dltAppId)
        {
          dds_handler = std::make_shared<DdsCommunicationHandler>(factory, &model_mutex, dltAppId);
          DI_MODEL_LOG_MCTX_INFO << "[Info] : Initialized DDS" << std::endl;
        }

        /// @brief Initializes the timer required for the model
        /// @param modelTickFun Specifies the ModelClass method to be called
        /// each interval
        /// @param timerPeriod Specifies the time period between interrupts
        /// in milliseconds
        /// @param _threadName name for model timer thread
        void init_model_timer(std::function<void()> modelTickFun, int32_t timerPeriod, std::string _threadName)
        {
          std::string const threadName = _threadName + "_" + std::to_string(timerPeriod);
          timerHandler = std::make_shared<Timer>(model_mutex, modelTickFun, timerPeriod, threadName);
          timerHandler->start();
          DI_MODEL_LOG_MCTX_INFO << "[Info] : Initialized Model Timer" << std::endl;
        }

        /// @brief Getter method for the someip_handler member
        /// @param appName std::string
        /// @return Returns pointer to the member someip_handler
        std::shared_ptr<SomeipCommunicationHandler> get_someip_handler(std::string const appName) const
        {
          std::unordered_map<std::string, std::shared_ptr<SomeipCommunicationHandler>>::const_iterator const it =
              this->someip_handler.find(appName);
          if (it != this->someip_handler.end())
          {
            return it->second;
          }
          return nullptr;
        }

        /// @brief Getter method for the dds_handler member
        /// @return Returns pointer to the member dds_handler
        std::shared_ptr<DdsCommunicationHandler> get_dds_handler() const override
        {
          return dds_handler;
        }

        /// @brief Getter method for the timerHandler member
        /// @return Returns pointer to the member timerHandler
        std::shared_ptr<Timer> get_timer_handler() const
        {
          return timerHandler;
        }

        /// @brief Getter method for the model_ptr member
        /// @return Returns pointer to the member model_ptr
        std::shared_ptr<ModelClass> get_model_ptr() const
        {
          return model_ptr;
        }

        /// @brief terminate all objects.
        void terminate()
        {
          DI_MODEL_LOG_MCTX_INFO << "[Info] : ModelController::terminate" << std::endl;
          if (timerHandler != nullptr)
          {
            timerHandler->stop();
            timerHandler.reset();
          }

          dds_handler.reset();

          if (!someip_handler.empty())
          {
            for (std::unordered_map<std::string, std::shared_ptr<SomeipCommunicationHandler>>::iterator it =
                     someip_handler.begin();
                 it != someip_handler.end();
                 ++it)
            {
              std::shared_ptr<SomeipCommunicationHandler> _someipCommunicationHander = it->second;
              if (_someipCommunicationHander != nullptr)
              {
                _someipCommunicationHander->terminate();
              }
            }
          }
          someip_handler.clear();

          if (model_ptr != nullptr)
          {
            model_ptr->terminate();
          }
          model_ptr.reset();
        }

        /// @brief Terminates the ModelClass object
        /// Didn't call the terminate() method in the ModelController destructor
        /// because we it's a static object and will be destroyed when the main()
        /// returns, which is not desirable as we might have to call dlclose() ahead
        /// of this destruction.
        ~ModelController() override
        {
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
