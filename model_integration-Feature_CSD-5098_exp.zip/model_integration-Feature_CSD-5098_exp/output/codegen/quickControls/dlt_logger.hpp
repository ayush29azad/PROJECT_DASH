

/// @file dlt_logger.hpp
/// @brief Contains all function declaration required to launch models
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date November 2023
#ifndef JLRCCCM_MODEL_INTEGRATION_DLT_HELPER_H
#define JLRCCCM_MODEL_INTEGRATION_DLT_HELPER_H

#if defined(ENABLE_DLT_LOGGING)
#include "logging_api.h"
#include <boost/log/sources/channel_logger.hpp>
#include <boost/log/sources/global_logger_storage.hpp>
#include <boost/log/trivial.hpp>
#include <fmt/core.h>
#include <ModelDltDefines.hpp>
#include <boost/log/sources/severity_channel_logger.hpp>

namespace logging
{
  std::string const ctx{models_dlt::QUICKCONTROLS};
  constexpr bool g_use_multi_contexts{true};
  using LoggerType = boost::log::sources::severity_channel_logger_mt<boost::log::trivial::severity_level, std::string>;

  BOOST_LOG_INLINE_GLOBAL_LOGGER_CTOR_ARGS(
      logger_service_QUICKCONTROLS, LoggerType, (boost::log::keywords::channel = logging::ctx))

}  // namespace logging

/// Global declaration of helper MACRO to multi context FATAL log
#define DI_MODEL_LOG_MCTX_FATAL \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::fatal)
/// Global declaration of helper MACRO to multi context FATAL log
#define DI_MODEL_LOG_MCTX_ERROR \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::error)
/// Global declaration of helper MACRO to multi context WARNING log
#define DI_MODEL_LOG_MCTX_WARN \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::warning)
/// Global declaration of helper MACRO to multi context INFO log
#define DI_MODEL_LOG_MCTX_INFO \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::info)
/// Global declaration of helper MACRO to multi context DEBUG log
#define DI_MODEL_LOG_MCTX_DEBUG \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::debug)
/// Global declaration of helper MACRO to multi context VERBOSE log
#define DI_MODEL_LOG_MCTX_VERBOSE \
  BOOST_LOG_SEV(logging::logger_service_QUICKCONTROLS::get(), boost::log::trivial::severity_level::trace)
#else
#define DI_MODEL_LOG_MCTX_FATAL std::cout
#define DI_MODEL_LOG_MCTX_ERROR std::cout
#define DI_MODEL_LOG_MCTX_WARN std::cout
#define DI_MODEL_LOG_MCTX_INFO std::cout
#define DI_MODEL_LOG_MCTX_DEBUG std::cout
#define DI_MODEL_LOG_MCTX_VERBOSE std::cout

#endif
#endif
