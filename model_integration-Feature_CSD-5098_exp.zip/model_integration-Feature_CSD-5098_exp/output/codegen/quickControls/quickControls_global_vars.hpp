
#ifndef JLRCCCM_QUICKCONTROLS_GLOBAL_VARS_HEADER
#define JLRCCCM_QUICKCONTROLS_GLOBAL_VARS_HEADER

#include "ModelControllerInterface.hpp"
#include "ModelExports.hpp"
#include <memory>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      extern SYMBOL_HIDDEN std::weak_ptr<IModelController> gModelControllerInternal;

      SYMBOL_HIDDEN void set_model_controller(std::weak_ptr<IModelController> const& controller);

      SYMBOL_HIDDEN std::weak_ptr<IModelController> get_model_controller();

    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif  // JLRCCCM_QUICKCONTROLS_GLOBAL_VARS_HEADER
