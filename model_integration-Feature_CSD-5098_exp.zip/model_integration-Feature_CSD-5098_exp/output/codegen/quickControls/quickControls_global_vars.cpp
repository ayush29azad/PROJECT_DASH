
#include <memory>
#include "quickControls_global_vars.hpp"
#include "ModelExports.hpp"

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      SYMBOL_HIDDEN std::weak_ptr<IModelController> gModelControllerInternal;

      SYMBOL_HIDDEN void set_model_controller(std::weak_ptr<IModelController> const& controller)
      {
        gModelControllerInternal = controller;
      }
      SYMBOL_HIDDEN std::weak_ptr<IModelController> get_model_controller()
      {
        return gModelControllerInternal;
      }

    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
