

#ifndef MODEL_DATA_CONVERTER_HEADER_H
#define MODEL_DATA_CONVERTER_HEADER_H

#include <cstdint>
#include <json/json.h>
#include <quickControls.h>
#include <CombinedTopicsPubSubTypes.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      class PlaybackDataConverterquickControls
      {
      public:
        static void create_json(structapertures_SetTailgateOperationRequest const* const model_data, Json::Value& obj)
        {
          obj["tailgate_operation_request"] = static_cast<int32_t>(model_data->tailgate_operation_request);
        }

        static void create_json(
            structapertures_GetTailgateOperationStatusResponse const* const model_data, Json::Value& obj)
        {
          obj["tailgate_operation_status"] = static_cast<int32_t>(model_data->tailgate_operation_status);
          obj["tailgate_error_status"] = static_cast<int32_t>(model_data->tailgate_error_status);
          obj["tailgate_position"] = model_data->tailgate_position;
          obj["status"] = static_cast<int32_t>(model_data->status);
        }

        static void create_json(structapertures_SetDoorsOperationRequest const* const model_data, Json::Value& obj)
        {
          obj["door_selection"] = static_cast<int32_t>(model_data->door_selection);
          obj["door_request"] = static_cast<int32_t>(model_data->door_request);
        }

        static void create_json(
            structapertures_GetDoorOpenCloseStatusResponse const* const model_data, Json::Value& obj)
        {
          obj["driver_door_status"] = static_cast<int32_t>(model_data->driver_door_status);
          obj["passenger_door_status"] = static_cast<int32_t>(model_data->passenger_door_status);
          obj["driver_rear_door_status"] = static_cast<int32_t>(model_data->driver_rear_door_status);
          obj["passenger_rear_door_status"] = static_cast<int32_t>(model_data->passenger_rear_door_status);
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["tailgate_status"] = static_cast<int32_t>(model_data->tailgate_status);
          obj["bonnet_status"] = static_cast<int32_t>(model_data->bonnet_status);
        }

        static void create_json(
            structapertures_GetTailgateControlStatusResponse const* const model_data, Json::Value& obj)
        {
          obj["upper_tailgate"] = static_cast<int32_t>(model_data->upper_tailgate);
          obj["status"] = static_cast<int32_t>(model_data->status);
        }

        static void create_json(structapertures_NotifyTailgateStatus const* const model_data, Json::Value& obj)
        {
          obj["tailgate_operation_status"] = static_cast<int32_t>(model_data->tailgate_operation_status);
          obj["tailgate_error_status"] = static_cast<int32_t>(model_data->tailgate_error_status);
          obj["tailgate_position"] = model_data->tailgate_position;
        }

        static void create_json(structapertures_NotifyTailgateControlStatus const* const model_data, Json::Value& obj)
        {
          obj["upper_tailgate"] = static_cast<int32_t>(model_data->upper_tailgate);
          obj["status"] = static_cast<int32_t>(model_data->status);
        }

        static void create_json(structapertures_NotifyDoorOpenCloseStatus const* const model_data, Json::Value& obj)
        {
          obj["driver_door_status"] = static_cast<int32_t>(model_data->driver_door_status);
          obj["passenger_door_status"] = static_cast<int32_t>(model_data->passenger_door_status);
          obj["driver_rear_door_status"] = static_cast<int32_t>(model_data->driver_rear_door_status);
          obj["passenger_rear_door_status"] = static_cast<int32_t>(model_data->passenger_rear_door_status);
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["tailgate_status"] = static_cast<int32_t>(model_data->tailgate_status);
          obj["bonnet_status"] = static_cast<int32_t>(model_data->bonnet_status);
        }

        static void create_json(structbody_GetValetModeResponse const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["valet_mode_state"] = static_cast<int32_t>(model_data->valet_mode_state);
          obj["valet_mode_availability"] = static_cast<int32_t>(model_data->valet_mode_availability);
        }

        static void create_json(structbody_GetValetModeConfigStatusResponse const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["front_trunk_lockout_status"] = static_cast<int32_t>(model_data->front_trunk_lockout_status);
          obj["tailgate_lockout_status"] = static_cast<int32_t>(model_data->tailgate_lockout_status);
          obj["taildoor_box_lockout_status"] = static_cast<int32_t>(model_data->taildoor_box_lockout_status);
        }

        static void create_json(structbody_NotifyValetModeStatus const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["valet_mode_state"] = static_cast<int32_t>(model_data->valet_mode_state);
          obj["valet_mode_availability"] = static_cast<int32_t>(model_data->valet_mode_availability);
        }

        static void create_json(structbody_NotifyValetModeConfigStatus const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["valet_mode_lockout_target"] = static_cast<int32_t>(model_data->valet_mode_lockout_target);
          obj["valet_mode_lockout_target_status"] = static_cast<int32_t>(model_data->valet_mode_lockout_target_status);
        }

        static void create_json(
            structbody_native_GetBonnetSecondaryLatchStatusResponse const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["secondary_latch_status"] = static_cast<int32_t>(model_data->secondary_latch_status);
        }

        static void create_json(
            structbody_native_NotifyBonnetSecondaryLatchStatus const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["secondary_latch_status"] = static_cast<int32_t>(model_data->secondary_latch_status);
        }

        static void create_json(structpropulsion_RecommendedGearPosition const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["gear_position_recommendation"] = static_cast<int32_t>(model_data->gear_position_recommendation);
          obj["gear_shift_dir_rec"] = static_cast<int32_t>(model_data->gear_shift_dir_rec);
        }

        static void create_json(structpropulsion_GetGearPositionResponse const* const model_data, Json::Value& obj)
        {
          obj["gear_position_to_display"] = static_cast<int32_t>(model_data->gear_position_to_display);
          obj["gear_actual_position"] = static_cast<int32_t>(model_data->gear_actual_position);
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["trans_mode"] = static_cast<int32_t>(model_data->trans_mode);
          obj["gear_mode"] = static_cast<int32_t>(model_data->gear_mode);
          obj["gear_pos_rec"] = Json::objectValue;
          create_json(&(model_data->gear_pos_rec), obj["gear_pos_rec"]);
        }

        static void create_json(structpropulsion_NotifyGearPosition const* const model_data, Json::Value& obj)
        {
          obj["gear_position_to_display"] = static_cast<int32_t>(model_data->gear_position_to_display);
          obj["gear_actual_position"] = static_cast<int32_t>(model_data->gear_actual_position);
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["trans_mode"] = static_cast<int32_t>(model_data->trans_mode);
          obj["gear_mode"] = static_cast<int32_t>(model_data->gear_mode);
          obj["gear_pos_rec"] = Json::objectValue;
          create_json(&(model_data->gear_pos_rec), obj["gear_pos_rec"]);
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
