#ifndef JLRCCCM_MODEL_IPC_WRAPPER_HEADER_quickControls
#define JLRCCCM_MODEL_IPC_WRAPPER_HEADER_quickControls

#include <iostream>
#include <memory>

#include "ModelLibInterface.h"
#include "types.h"
#include "dlt_logger.hpp"
#include "PlaybackDataConverterquickControls.hpp"
#include "ProtoIncludesquickControls.hpp"
#include "release_version.h"
#include "SomeipInstanceIdMapping.hpp"
#include "ModelController.hpp"
#include "quickControls_global_vars.hpp"

namespace cccm::di::models
{
  /// @brief The Concrete Implementation of ModelLibInterface for quickControls
  ///
  /// @details This class will implement init and terminate methods of
  /// ModelLibInterface to register comms with the models as well as timers
  ///
  /// This class is templated to allow injection of a mock model which follows
  /// the same interface as quickControls which allows to test
  ///
  /// @tparam ModelClasss Either quickControls or a mock model which follows the
  /// the same interface
  template <typename ModelClass>
  class WrapperquickControls final : public cccm::di::ModelLibInterface
  {
  private:
    using PlaybackDataConverterquickControls = jlr::cccm::di::PlaybackDataConverterquickControls;
    using ServiceInstanceIdMapping = ipc_wrapper::instance_id_mapping::ServiceInstanceIdMapping;
    // @brief alias of ModelController template for ModelClass
    using ModelControllerType = jlr::cccm::di::ModelController<ModelClass>;
    using SomeipCommunicationHandler = jlr::cccm::di::SomeipCommunicationHandler;

    std::shared_ptr<ModelClass> mModelPtr;
    std::shared_ptr<ModelControllerType> mModelController;

    uint16_t notifyDoorOpenCloseStatusID;
    uint16_t notifyTailgateControlStatusID;
    uint16_t notifyTailgateStatusID;
    uint16_t notifyValetModeConfigStatusID;
    uint16_t notifyValetModeStatusID;
    uint16_t notifyBonnetSecondaryLatchStatusID;
    uint16_t notifyGearPositionID;
    uint16_t getDoorOpenCloseStatusResponseID;
    uint16_t getTailgateControlStatusResponseID;
    uint16_t getTailgateOperationStatusResponseID;
    uint16_t getValetModeConfigStatusResponseID;
    uint16_t getValetModeResponseID;
    uint16_t getBonnetSecondaryLatchStatusResponseID;
    uint16_t getGearPositionResponseID;
    uint16_t setGloveboxOperationRequestID;
    uint16_t setTailgateOperationRequestID;
    uint16_t setDoorsOperationRequestID;

  public:
    /// @brief deleted default constructor to enforce initialisation with a model
    WrapperquickControls() = delete;

    /// @brief constructs the wrapper with a given model instance
    WrapperquickControls(std::shared_ptr<ModelClass> const& _mModelPtr)
        : cccm::di::ModelLibInterface()
        , mModelPtr(_mModelPtr)
        ,

        notifyDoorOpenCloseStatusID(static_cast<uint16_t>(0xA108))
        , notifyTailgateControlStatusID(static_cast<uint16_t>(0xA109))
        , notifyTailgateStatusID(static_cast<uint16_t>(0xA101))
        , notifyValetModeConfigStatusID(static_cast<uint16_t>(0xA009))
        , notifyValetModeStatusID(static_cast<uint16_t>(0xA005))
        , notifyBonnetSecondaryLatchStatusID(static_cast<uint16_t>(0xA001))
        , notifyGearPositionID(static_cast<uint16_t>(0x8005))
        , getDoorOpenCloseStatusResponseID(static_cast<uint16_t>(0x2010))
        , getTailgateControlStatusResponseID(static_cast<uint16_t>(0x2012))
        , getTailgateOperationStatusResponseID(static_cast<uint16_t>(0x2002))
        , getValetModeConfigStatusResponseID(static_cast<uint16_t>(0x100F))
        , getValetModeResponseID(static_cast<uint16_t>(0x1009))
        , getBonnetSecondaryLatchStatusResponseID(static_cast<uint16_t>(0x1002))
        , getGearPositionResponseID(static_cast<uint16_t>(0x1007))
        , setGloveboxOperationRequestID(static_cast<uint16_t>(0x1001))
        , setTailgateOperationRequestID(static_cast<uint16_t>(0x2001))
        , setDoorsOperationRequestID(static_cast<uint16_t>(0x200A))
    {
    }

    /// @brief Default destructor
    ~WrapperquickControls() override = default;

    /// @brief Implements ModelLibInterface init
    ///
    /// @satisfy{Requirement01321452,Requirement01321457,Requirement01321459,Requirement01321608,Requirement01321460,Requirement01321463,Requirement01321626,Requirement01340698,Requirement01321467,Requirement01321613,Requirement01321612,Requirement01415381,Requirement01415387,Requirement01415483,
    /// Requirement01415577, Requirement01446314, Requirement01446316, Requirement01446329, Requirement01445541}
    ///
    /// @param context Launcher context which injects all comms dependencies
    void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) final
    {

      auto const vsomeipMap = context->someipApp_map;
      std::shared_ptr<WorkExecutor> const& workExecutor = context->workExecutor;
      std::shared_ptr<jlr::cccm::di::dds::DDSEntityFactoryInterface> const& ddsFactory = context->ddsFactory;
      std::string const& dltAppId = context->dltApplication.first;
      std::string const& dltAppDescription = context->dltApplication.second;
      std::string const& someipMappingFilename = context->someipMappingFilename;

#if defined(ENABLE_DLT_LOGGING)
      generic_logging::initialize_loggers(
          dltAppId,
          logging::ctx,
          dltAppDescription,
          "DI quickControls",
          std::vector<generic_logging::LoggerKind>{generic_logging::LoggerKind::dlt_log},
          logging::g_use_multi_contexts);
#endif

      // Output which release package this library is from
      DI_MODEL_LOG_MCTX_INFO << "Release version information: " << version::release_version << std::endl;

      if (nullptr == workExecutor)
      {
        DI_MODEL_LOG_MCTX_WARN << "[Warn] : WorkExecutor is NULL, Can Impact the latency";
      }

      this->mModelController = std::make_shared<ModelControllerType>();
      // Set global model controller
      {
        // BUG: Make this operation atomic. If two threads try to create a controller at the same time, this will result
        // in unexpected behavior. However, this can be ignored since that is not expected to happen in the current
        // architecture.
        if (!jlr::cccm::di::get_model_controller().expired())
        {
          throw std::runtime_error("Model controller already exists. Cannot create a new one.");
        }
        jlr::cccm::di::set_model_controller(this->mModelController);
      }

      mModelController->init_model(mModelPtr);

      {
        int32_t const numOfvIds = 1;
        if (vsomeipMap.size() < numOfvIds)
        {
          throw std::runtime_error(
              "Can not initialize someip handlers, number of vid in vsomeip services and in arguments do not match!!");
        }
        std::vector<std::string> const vids = {"vid10"};
        bool allPresent = true;
        for (std::size_t i = 0; i < vids.size(); ++i)
        {
          if (vsomeipMap.find(vids[i]) == vsomeipMap.end())
          {
            allPresent = false;
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : vid " << vids[i] << " is not passed in arguments" << std::endl;
          }
        }
        if (allPresent == false)
        {
          throw std::runtime_error(
              "Can not initialize someip handlers, vids in vsomeip services and in arguments do not match!!");
        }
      }

      // VSOMEIP COMMS HANDLING
      for (auto it = vsomeipMap.begin(); it != vsomeipMap.end(); ++it)
      {
        std::shared_ptr<vsomeip::application> const _app = it->second;
        if (_app != nullptr)
        {
          std::string const _key = it->first;
          mModelController->init_model_someip(_app, _key);
        }
      }

      std::shared_ptr<SomeipCommunicationHandler> someipHandlerVid10 = mModelController->get_someip_handler("vid10");

      bool parsed = false;

      ServiceInstanceIdMapping instanceMapping;

#if defined(INSTANCE_ID_MAPPING)
      parsed = instanceMapping.parse_json(someipMappingFilename);
      if (parsed == false)
      {
        DI_MODEL_LOG_MCTX_WARN << "[Warn] Couldn't parse someip instance id json file, using defaults" << std::endl;
      }
#endif

      // SOMEIP initialisation

      vsomeip::instance_t const propulsionServiceInstanceid =
          instanceMapping.get_service_instanceId("propulsion_service");
      vsomeip::instance_t const propulsionServiceServiceid = static_cast<vsomeip::instance_t>(0x000E);

      DI_MODEL_LOG_MCTX_INFO << "propulsionServiceInstanceid-> " << propulsionServiceInstanceid << std::endl;
      auto const propulsionServiceConsumer =
          someipHandlerVid10->create_consumer(propulsionServiceServiceid, propulsionServiceInstanceid);

      vsomeip::instance_t const aperturesServiceInstanceid =
          instanceMapping.get_service_instanceId("apertures_service");
      vsomeip::instance_t const aperturesServiceServiceid = static_cast<vsomeip::instance_t>(0x0001);

      DI_MODEL_LOG_MCTX_INFO << "aperturesServiceInstanceid-> " << aperturesServiceInstanceid << std::endl;
      auto const aperturesServiceConsumer =
          someipHandlerVid10->create_consumer(aperturesServiceServiceid, aperturesServiceInstanceid);

      vsomeip::instance_t const bodyNativeServiceInstanceid =
          instanceMapping.get_service_instanceId("body_native_service");
      vsomeip::instance_t const bodyNativeServiceServiceid = static_cast<vsomeip::instance_t>(0x0071);

      DI_MODEL_LOG_MCTX_INFO << "bodyNativeServiceInstanceid-> " << bodyNativeServiceInstanceid << std::endl;
      auto const bodyNativeServiceConsumer =
          someipHandlerVid10->create_consumer(bodyNativeServiceServiceid, bodyNativeServiceInstanceid);

      vsomeip::instance_t const bodyServiceInstanceid = instanceMapping.get_service_instanceId("body_service");
      vsomeip::instance_t const bodyServiceServiceid = static_cast<vsomeip::instance_t>(0x0002);

      DI_MODEL_LOG_MCTX_INFO << "bodyServiceInstanceid-> " << bodyServiceInstanceid << std::endl;
      auto const bodyServiceConsumer = someipHandlerVid10->create_consumer(bodyServiceServiceid, bodyServiceInstanceid);

      auto const soip_apertures_NotifyDoorOpenCloseStatus =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structapertures_NotifyDoorOpenCloseStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_NotifyDoorOpenCloseStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_NotifyDoorOpenCloseStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_NotifyDoorOpenCloseStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_NotifyDoorOpenCloseStatus(modelData);
      };
      someipHandlerVid10
          ->notify_in<apertures_service::NotifyDoorOpenCloseStatus, structapertures_NotifyDoorOpenCloseStatus>(
              aperturesServiceConsumer,
              notifyDoorOpenCloseStatusID,
              std::vector<uint16_t>{0x2214},
              soip_apertures_NotifyDoorOpenCloseStatus);

      auto const soip_apertures_NotifyTailgateControlStatus =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structapertures_NotifyTailgateControlStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_NotifyTailgateControlStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_NotifyTailgateControlStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_NotifyTailgateControlStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_NotifyTailgateControlStatus(modelData);
      };
      someipHandlerVid10
          ->notify_in<apertures_service::NotifyTailgateControlStatus, structapertures_NotifyTailgateControlStatus>(
              aperturesServiceConsumer,
              notifyTailgateControlStatusID,
              std::vector<uint16_t>{0x2215},
              soip_apertures_NotifyTailgateControlStatus);

      auto const soip_apertures_NotifyTailgateStatus =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structapertures_NotifyTailgateStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_NotifyTailgateStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_NotifyTailgateStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_NotifyTailgateStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_NotifyTailgateStatus(modelData);
      };
      someipHandlerVid10->notify_in<apertures_service::NotifyTailgateStatus, structapertures_NotifyTailgateStatus>(
          aperturesServiceConsumer,
          notifyTailgateStatusID,
          std::vector<uint16_t>{0x2211, 0x2212},
          soip_apertures_NotifyTailgateStatus);

      auto const soip_body_NotifyValetModeConfigStatus =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structbody_NotifyValetModeConfigStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_NotifyValetModeConfigStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_NotifyValetModeConfigStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structbody_NotifyValetModeConfigStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_NotifyValetModeConfigStatus(modelData);
      };
      someipHandlerVid10->notify_in<body_service::NotifyValetModeConfigStatus, structbody_NotifyValetModeConfigStatus>(
          bodyServiceConsumer,
          notifyValetModeConfigStatusID,
          std::vector<uint16_t>{0x1111},
          soip_body_NotifyValetModeConfigStatus);

      auto const soip_body_NotifyValetModeStatus =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structbody_NotifyValetModeStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_NotifyValetModeStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_NotifyValetModeStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structbody_NotifyValetModeStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_NotifyValetModeStatus(modelData);
      };
      someipHandlerVid10->notify_in<body_service::NotifyValetModeStatus, structbody_NotifyValetModeStatus>(
          bodyServiceConsumer,
          notifyValetModeStatusID,
          std::vector<uint16_t>{0x1111, 0x1114},
          soip_body_NotifyValetModeStatus);

      auto const soip_body_native_NotifyBonnetSecondaryLatchStatus =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structbody_native_NotifyBonnetSecondaryLatchStatus const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_native_NotifyBonnetSecondaryLatchStatus";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_native_NotifyBonnetSecondaryLatchStatus"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structbody_native_NotifyBonnetSecondaryLatchStatus"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_native_NotifyBonnetSecondaryLatchStatus(modelData);
      };
      someipHandlerVid10->notify_in<
          body_native_service::NotifyBonnetSecondaryLatchStatus,
          structbody_native_NotifyBonnetSecondaryLatchStatus>(
          bodyNativeServiceConsumer,
          notifyBonnetSecondaryLatchStatusID,
          std::vector<uint16_t>{0x1111},
          soip_body_native_NotifyBonnetSecondaryLatchStatus);

      auto const soip_propulsion_NotifyGearPosition =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structpropulsion_NotifyGearPosition const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_propulsion_NotifyGearPosition";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structpropulsion_NotifyGearPosition"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structpropulsion_NotifyGearPosition"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_propulsion_NotifyGearPosition(modelData);
      };
      someipHandlerVid10->notify_in<propulsion_service::NotifyGearPosition, structpropulsion_NotifyGearPosition>(
          propulsionServiceConsumer,
          notifyGearPositionID,
          std::vector<uint16_t>{0x3133},
          soip_propulsion_NotifyGearPosition);

      auto const soip_apertures_GetDoorOpenCloseStatusResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structapertures_GetDoorOpenCloseStatusResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_GetDoorOpenCloseStatusResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_GetDoorOpenCloseStatusResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_GetDoorOpenCloseStatusResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_GetDoorOpenCloseStatusResponse(modelData);
      };
      someipHandlerVid10->response_in<
          apertures_service::GetDoorOpenCloseStatusRequest,
          apertures_service::GetDoorOpenCloseStatusResponse,
          structapertures_GetDoorOpenCloseStatusResponse>(
          aperturesServiceConsumer, getDoorOpenCloseStatusResponseID, soip_apertures_GetDoorOpenCloseStatusResponse);

      auto const soip_apertures_GetTailgateControlStatusResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structapertures_GetTailgateControlStatusResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_GetTailgateControlStatusResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_GetTailgateControlStatusResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_GetTailgateControlStatusResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_GetTailgateControlStatusResponse(modelData);
      };
      someipHandlerVid10->response_in<
          apertures_service::GetTailgateControlStatusRequest,
          apertures_service::GetTailgateControlStatusResponse,
          structapertures_GetTailgateControlStatusResponse>(
          aperturesServiceConsumer,
          getTailgateControlStatusResponseID,
          soip_apertures_GetTailgateControlStatusResponse);

      auto const soip_apertures_GetTailgateOperationStatusResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structapertures_GetTailgateOperationStatusResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_apertures_GetTailgateOperationStatusResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structapertures_GetTailgateOperationStatusResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structapertures_GetTailgateOperationStatusResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_apertures_GetTailgateOperationStatusResponse(modelData);
      };
      someipHandlerVid10->response_in<
          apertures_service::GetTailgateOperationStatusRequest,
          apertures_service::GetTailgateOperationStatusResponse,
          structapertures_GetTailgateOperationStatusResponse>(
          aperturesServiceConsumer,
          getTailgateOperationStatusResponseID,
          soip_apertures_GetTailgateOperationStatusResponse);

      auto const soip_body_GetValetModeConfigStatusResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structbody_GetValetModeConfigStatusResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_GetValetModeConfigStatusResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_GetValetModeConfigStatusResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structbody_GetValetModeConfigStatusResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_GetValetModeConfigStatusResponse(modelData);
      };
      someipHandlerVid10->response_in<
          body_service::GetValetModeConfigStatusRequest,
          body_service::GetValetModeConfigStatusResponse,
          structbody_GetValetModeConfigStatusResponse>(
          bodyServiceConsumer, getValetModeConfigStatusResponseID, soip_body_GetValetModeConfigStatusResponse);

      auto const soip_body_GetValetModeResponse =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structbody_GetValetModeResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_GetValetModeResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_GetValetModeResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(modelData, obj["args"][0]["structbody_GetValetModeResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_GetValetModeResponse(modelData);
      };
      someipHandlerVid10->response_in<
          body_service::GetValetModeRequest,
          body_service::GetValetModeResponse,
          structbody_GetValetModeResponse>(bodyServiceConsumer, getValetModeResponseID, soip_body_GetValetModeResponse);

      auto const soip_body_native_GetBonnetSecondaryLatchStatusResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structbody_native_GetBonnetSecondaryLatchStatusResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_body_native_GetBonnetSecondaryLatchStatusResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structbody_native_GetBonnetSecondaryLatchStatusResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structbody_native_GetBonnetSecondaryLatchStatusResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_body_native_GetBonnetSecondaryLatchStatusResponse(modelData);
      };
      someipHandlerVid10->response_in<
          body_native_service::GetBonnetSecondaryLatchStatusRequest,
          body_native_service::GetBonnetSecondaryLatchStatusResponse,
          structbody_native_GetBonnetSecondaryLatchStatusResponse>(
          bodyNativeServiceConsumer,
          getBonnetSecondaryLatchStatusResponseID,
          soip_body_native_GetBonnetSecondaryLatchStatusResponse);

      auto const soip_propulsion_GetGearPositionResponse =
          [mModelPtr = mModelPtr, dltAppId = dltAppId](structpropulsion_GetGearPositionResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_propulsion_GetGearPositionResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structpropulsion_GetGearPositionResponse"] = Json::objectValue;
          PlaybackDataConverterquickControls::create_json(
              modelData, obj["args"][0]["structpropulsion_GetGearPositionResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_propulsion_GetGearPositionResponse(modelData);
      };
      someipHandlerVid10->response_in<
          propulsion_service::GetGearPositionRequest,
          propulsion_service::GetGearPositionResponse,
          structpropulsion_GetGearPositionResponse>(
          propulsionServiceConsumer, getGearPositionResponseID, soip_propulsion_GetGearPositionResponse);

      someipHandlerVid10->unpaired_response_in<
          body_native_service::SetGloveboxOperationRequest,
          body_native_service::SetGloveboxOperationResponse>(bodyNativeServiceConsumer, setGloveboxOperationRequestID);

      someipHandlerVid10->unpaired_response_in<
          apertures_service::SetTailgateOperationRequest,
          apertures_service::SetTailgateOperationResponse>(aperturesServiceConsumer, setTailgateOperationRequestID);

      someipHandlerVid10->unpaired_response_in<
          apertures_service::SetDoorsOperationRequest,
          apertures_service::SetDoorsOperationResponse>(aperturesServiceConsumer, setDoorsOperationRequestID);

      // On available

      auto const on_available = [mModelPtr = mModelPtr, dltAppId = dltAppId](
                                    uint16_t const serviceId, uint16_t const instanceId, bool const isAvailable)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_on_available";
          obj["args"] = Json::arrayValue;

          obj["args"][0] = Json::objectValue;
          obj["args"][0]["serviceId"] = serviceId;
          obj["args"][1] = Json::objectValue;
          obj["args"][1]["instanceId"] = instanceId;
          obj["args"][2] = Json::objectValue;
          obj["args"][2]["isAvailable"] = isAvailable;

          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
        }
#endif
        mModelPtr->soip_on_available(serviceId, instanceId, isAvailable);
      };

      someipHandlerVid10->set_on_available(propulsionServiceConsumer, on_available);

      someipHandlerVid10->set_on_available(aperturesServiceConsumer, on_available);

      someipHandlerVid10->set_on_available(bodyNativeServiceConsumer, on_available);

      someipHandlerVid10->set_on_available(bodyServiceConsumer, on_available);

      // DDS COMMS HANDLING

      mModelController->init_model_dds(ddsFactory, dltAppId);
      auto ddsHandler = mModelController->get_dds_handler();
      ddsHandler->set_work_executor(workExecutor);

      {
        std::unique_ptr<dds_ipc::quickControlsPubSubType> quickControlsPtr =
            std::make_unique<dds_ipc::quickControlsPubSubType>();
        bool const topicOutRegistrationStatus =
            ddsHandler->topic_out("dds_ipc::quickControls", quickControlsPtr.release());
        if (topicOutRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS publish topic, dds_ipc::dds_ipc::quickControls Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS publish topic, dds_ipc::dds_ipc::quickControls failed!!";
        }
      }

      {
        std::function<void(structquickControlsGUI const*)> modelCallBack{};
        modelCallBack = [mModelPtr = mModelPtr, dltAppId = dltAppId](structquickControlsGUI const* modelData)
        {
#if defined(ENABLE_MODEL_PLAYBACK)
          bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                        boost::log::trivial::severity_level::trace;
#endif
          if (jsonPayload)
          {

            /*{
              Json::Value obj = Json::objectValue;
              obj["model_func_name"] = "ddsRx_quickControlsGUI";
              obj["args"] = Json::arrayValue;
              obj["args"][0] = Json::objectValue;
              obj["args"][0]["structquickControlsGUI"] = Json::objectValue;
              PlaybackDataConverterquickControls::create_json(modelData, obj["args"][0]["structquickControlsGUI"] );
              Json::StreamWriterBuilder wBuilder;
              wBuilder["indentation"] = "";
              const std::string document = Json::writeString(wBuilder,obj);
              DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
            }*/
          }
#endif
          mModelPtr->ddsRx_quickControlsGUI(modelData);
        };

        auto const callBack = [modelCallBack, ddsHandler = ddsHandler.get(), workExecutor = workExecutor.get()]()
        {
          structquickControlsGUI modelData;

          if (ddsHandler->recv(&modelData, "dds_ipc::quickControlsGUI") == true)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "Received dds_ipc::quickControlsGUI data from ddsHandler" << std::endl;
            if (workExecutor != nullptr)
            {
              auto data_ = modelData;
              workExecutor->addWork(
                  [modelCallBack, data_]()
                  {
                    modelCallBack(&data_);
                  });
            }
            else
            {
              modelCallBack(&modelData);
            }
          }
          else
          {
            DI_MODEL_LOG_MCTX_WARN << "[Warn]: No data read from ddsHandler" << std::endl;
          }
        };

        std::unique_ptr<dds_ipc::quickControlsGUIPubSubType> quickControlsGUIPtr =
            std::make_unique<dds_ipc::quickControlsGUIPubSubType>();
        bool const topicInRegistrationStatus =
            ddsHandler->topic_in("dds_ipc::quickControlsGUI", quickControlsGUIPtr.release(), callBack);
        if (topicInRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::quickControlsGUI Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::quickControlsGUI failed!!";
        }
      }

      {
        std::function<void(structvehicleLifecycleInt const*)> modelCallBack{};
        modelCallBack = [mModelPtr = mModelPtr, dltAppId = dltAppId](structvehicleLifecycleInt const* modelData)
        {
#if defined(ENABLE_MODEL_PLAYBACK)
          bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                        boost::log::trivial::severity_level::trace;
#endif
          if (jsonPayload)
          {

            /*{
              Json::Value obj = Json::objectValue;
              obj["model_func_name"] = "ddsRx_vehicleLifecycleInt";
              obj["args"] = Json::arrayValue;
              obj["args"][0] = Json::objectValue;
              obj["args"][0]["structvehicleLifecycleInt"] = Json::objectValue;
              PlaybackDataConverterquickControls::create_json(modelData, obj["args"][0]["structvehicleLifecycleInt"] );
              Json::StreamWriterBuilder wBuilder;
              wBuilder["indentation"] = "";
              const std::string document = Json::writeString(wBuilder,obj);
              DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
            }*/
          }
#endif
          mModelPtr->ddsRx_vehicleLifecycleInt(modelData);
        };

        auto const callBack = [modelCallBack, ddsHandler = ddsHandler.get(), workExecutor = workExecutor.get()]()
        {
          structvehicleLifecycleInt modelData;

          if (ddsHandler->recv(&modelData, "dds_ipc::vehicleLifecycleInt") == true)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "Received dds_ipc::vehicleLifecycleInt data from ddsHandler" << std::endl;
            if (workExecutor != nullptr)
            {
              auto data_ = modelData;
              workExecutor->addWork(
                  [modelCallBack, data_]()
                  {
                    modelCallBack(&data_);
                  });
            }
            else
            {
              modelCallBack(&modelData);
            }
          }
          else
          {
            DI_MODEL_LOG_MCTX_WARN << "[Warn]: No data read from ddsHandler" << std::endl;
          }
        };

        std::unique_ptr<dds_ipc::vehicleLifecycleIntPubSubType> vehicleLifecycleIntPtr =
            std::make_unique<dds_ipc::vehicleLifecycleIntPubSubType>();
        bool const topicInRegistrationStatus =
            ddsHandler->topic_in("dds_ipc::vehicleLifecycleInt", vehicleLifecycleIntPtr.release(), callBack);
        if (topicInRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::vehicleLifecycleInt Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::vehicleLifecycleInt failed!!";
        }
      }

      // MODEL TIMER HANDLING

      int32_t const timer_period = static_cast<int32_t>(100);
      std::string const _threadName = std::string("quickControls") + std::string("_timerThread");

      auto const timerFun = [mModelPtr = mModelPtr, dltAppId = dltAppId]()
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "tic_100ms";
          obj["args"] = Json::arrayValue;
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_VERBOSE << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return somethingg
        }
#endif
        mModelPtr->tic_100ms();
      };
      mModelController->init_model_timer(timerFun, timer_period, _threadName);
    }

    /// @brief Implements ModelLibInterface terminate
    void terminate() final
    {
      mModelController->terminate();
      // https://dev.to/fenbf/how-a-weakptr-might-prevent-full-memory-cleanup-of-managed-object-i0i
      jlr::cccm::di::set_model_controller({});
    }
  };
};  // namespace cccm::di::models

#endif
