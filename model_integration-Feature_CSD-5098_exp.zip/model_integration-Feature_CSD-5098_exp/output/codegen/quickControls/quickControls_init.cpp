
#include <memory>
#include <fstream>
#include <json/json.h>
#include <cstdint>
#include "ModelController.hpp"
#include <quickControls.h>
#include "WrapperquickControls.h"
#include "quickControls_global_vars.hpp"
#include "creator.h"

extern "C" std::shared_ptr<cccm::di::ModelLibInterface> creator()
{
  // @brief alias of ModelController template for quickControlsModelClass
  // using ModelControllerType
  //  = jlr::cccm::di::ModelController<quickControlsModelClass>;

  return std::make_shared<cccm::di::models::WrapperquickControls<quickControlsModelClass>>(
      std::make_shared<quickControlsModelClass>());
}
