#include "dlt_logger.hpp"
#include "ProtoDataConverterMessage.hpp"
#include <SomeipServiceConsumer.hpp>
#include <SomeipServiceProvider.hpp>
#include <DdsCommunicationHandler.hpp>

#include <ModelController.hpp>
#include "quickControls_global_vars.hpp"
#include "ProtoIncludesquickControls.hpp"
#include "quickControls.h"
#include "early_ccf.hpp"
#include <ml_API_earlyCCF_GetEarlyCCFParamRequest.h>

#include <soip_apertures_GetDoorOpenCloseStatusRequest.h>
#include <soip_apertures_GetTailgateControlStatusRequest.h>
#include <soip_apertures_GetTailgateOperationStatusRequest.h>
#include <soip_body_GetValetModeConfigStatusRequest.h>
#include <soip_body_GetValetModeRequest.h>
#include <soip_body_native_GetBonnetSecondaryLatchStatusRequest.h>
#include <soip_propulsion_GetGearPositionRequest.h>
#include <soip_apertures_SetTailgateOperationRequest.h>
#include <soip_apertures_SetDoorsOperationRequest.h>
#include <soip_body_native_SetGloveboxOperationRequest.h>
#include <ddsTx_quickControls.h>
#include <ml_API_earlyCCF_GetEarlyCCFParamRequest.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      extern "C"
      {

        /// @brief Handles ML_API request for EarlyCCF
        /// @param rtu_ml_API_earlyCCF_GetEarlyCCFParamRequest Model request structure containing MDF IDs
        /// @satisfy{Requirement01637438,Requirement01637440,Requirement01637441}
        void ml_API_earlyCCF_GetEarlyCCFParamRequest(
            structml_API_earlyCCF_GetEarlyCCFParamRequest const* const rtu_ml_API_earlyCCF_GetEarlyCCFParamRequest)
        {
          // 1. Initialize EarlyCCF library (singleton pattern - thread-safe)
          static std::unique_ptr<nmspEarlyCCF::EarlyCCFImpl> gEarlyCcf = nullptr;
          static std::once_flag initFlag;

          /// @satisfy{Requirement01637630}
          std::call_once(
              initFlag,
              []()
              {
                gEarlyCcf = std::make_unique<nmspEarlyCCF::EarlyCCFImpl>();
                DI_MODEL_LOG_MCTX_INFO << "[Info] : EarlyCCF library initialized";
              });

          if (gEarlyCcf == nullptr)
          {
            DI_MODEL_LOG_MCTX_ERROR
                << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest : EarlyCCF initialization failed!";
            return;
          }

          // 2. Get model controller
          std::shared_ptr<IModelController> const controller = get_model_controller().lock();
          if (!static_cast<bool>(controller))
          {
            DI_MODEL_LOG_MCTX_ERROR
                << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest : ModelController not initialized!";
            return;
          }

          // 3. Convert Model struct → Platform library format (int32_t → uint32_t)
          /// @satisfy{Requirement01637443,Requirement01637443}
          nmspEarlyCCF::GetEarlyCCFParamRequest request;
          request.params.clear();

          for (uint32_t i = 0U; i < rtu_ml_API_earlyCCF_GetEarlyCCFParamRequest->params.payload_length; ++i)
          {
            nmspEarlyCCF::RepMdfidEarlyCCF mdf;
            mdf.mdf_id = static_cast<uint32_t>(rtu_ml_API_earlyCCF_GetEarlyCCFParamRequest->params.payload[i].mdf_id);
            request.params.push_back(mdf);
          }

          DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : ml_API_earlyCCF_GetEarlyCCFParamRequest : Calling EarlyCCF with "
                                  << request.params.size() << " MDF IDs";

          try
          {
            // 4. Call platform library (BLOCKING call)
            /// @satisfy{Requirement01637445}
            nmspEarlyCCF::GetEarlyCCFParamResponse const response = gEarlyCcf->get_ccf(request);

            DI_MODEL_LOG_MCTX_DEBUG << "[Debug] : ml_API_earlyCCF_GetEarlyCCFParamRequest : EarlyCCF returned "
                                    << response.params.size()
                                    << " results, status=" << static_cast<int32_t>(response.status);

            // Validate response
            if (response.params.empty())
            {
              DI_MODEL_LOG_MCTX_INFO
                  << "[Info] : ml_API_earlyCCF_GetEarlyCCFParamRequest : EarlyCCF returned empty response";
            }

            /// @satisfy{Requirement01637443,Requirement01637443}
            // 5. Convert Platform response → Model struct (uint32_t → int32_t)
            structml_API_earlyCCF_GetEarlyCCFParamResponse modelResponse{};

            uint32_t const max_array_size = 50U;
            modelResponse.params.payload_length = std::min(
                static_cast<uint32_t>(response.params.size()),
                max_array_size  // Max array size from model
            );

            for (uint32_t i = 0U; i < modelResponse.params.payload_length; ++i)
            {
              if (i >= max_array_size)
              {
                DI_MODEL_LOG_MCTX_INFO
                    << "[Info] : ml_API_earlyCCF_GetEarlyCCFParamRequest : Truncating response at 50 items";
                break;
              }

              modelResponse.params.payload[i].mdf = static_cast<int32_t>(response.params[i].mdf);
              modelResponse.params.payload[i].value = static_cast<int32_t>(response.params[i].value);
              modelResponse.params.payload[i].mdf_status =
                  static_cast<ml_API_earlyCCF_EnumStatusMDFID>(response.params[i].mdf_status);

              DI_MODEL_LOG_MCTX_DEBUG << "[Early_Conf_Conversion] Param[" << i
                                      << "] MDF=" << modelResponse.params.payload[i].mdf;

              DI_MODEL_LOG_MCTX_DEBUG << "[Early_Conf_Conversion] Param[" << i
                                      << "] Value=" << modelResponse.params.payload[i].value;

              DI_MODEL_LOG_MCTX_DEBUG << "[Early_Conf_Conversion] Param[" << i << "] Status="
                                      << static_cast<int32_t>(modelResponse.params.payload[i].mdf_status);
            }

            modelResponse.status = static_cast<ml_API_earlyCCF_EnumStatusCCF>(response.status);

            // 6. Call model response handler
            /// @satisfy{Requirement01637446,Requirement01637586}
            auto const modelController = std::static_pointer_cast<ModelController<quickControlsModelClass>>(controller);
            if (modelController != nullptr)
            {
              auto const model = modelController->get_model_ptr();
              if (model != nullptr)
              {
                model->ml_API_earlyCCF_GetEarlyCCFParamResponse(&modelResponse);
                DI_MODEL_LOG_MCTX_DEBUG
                    << "[Debug] : ml_API_earlyCCF_GetEarlyCCFParamRequest : Response delivered to model";
              }
              else
              {
                DI_MODEL_LOG_MCTX_ERROR << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest : Model pointer is null!";
              }
            }
            else
            {
              DI_MODEL_LOG_MCTX_ERROR
                  << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest : ModelController cast failed!";
            }
          }
          catch (std::exception const& e)
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest failed: " << e.what();
          }
          catch (...)
          {
            DI_MODEL_LOG_MCTX_ERROR
                << "[Error] : ml_API_earlyCCF_GetEarlyCCFParamRequest failed with unknown exception";
          }
        }

        /// @brief Sends out a someip request for body_service::GetValetModeRequest
        /// @satisfy{Requirement01321459}
        void soip_body_GetValetModeRequest()
        {
          body_service::GetValetModeRequest const protoData;
          consumer::MessageChannel<body_service::GetValetModeRequest, body_service::GetValetModeResponse>::
              get_instance()
                  .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for body_native_service::GetBonnetSecondaryLatchStatusRequest
        /// @satisfy{Requirement01321459}
        void soip_body_native_GetBonnetSecondaryLatchStatusRequest()
        {
          body_native_service::GetBonnetSecondaryLatchStatusRequest const protoData;
          consumer::MessageChannel<
              body_native_service::GetBonnetSecondaryLatchStatusRequest,
              body_native_service::GetBonnetSecondaryLatchStatusResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for body_service::GetValetModeConfigStatusRequest
        /// @satisfy{Requirement01321459}
        void soip_body_GetValetModeConfigStatusRequest()
        {
          body_service::GetValetModeConfigStatusRequest const protoData;
          consumer::MessageChannel<
              body_service::GetValetModeConfigStatusRequest,
              body_service::GetValetModeConfigStatusResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for apertures_service::GetTailgateOperationStatusRequest
        /// @satisfy{Requirement01321459}
        void soip_apertures_GetTailgateOperationStatusRequest()
        {
          apertures_service::GetTailgateOperationStatusRequest const protoData;
          consumer::MessageChannel<
              apertures_service::GetTailgateOperationStatusRequest,
              apertures_service::GetTailgateOperationStatusResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for body_native_service::SetGloveboxOperationRequest
        /// @satisfy{Requirement01321459}
        void soip_body_native_SetGloveboxOperationRequest()
        {
          body_native_service::SetGloveboxOperationRequest const protoData;
          consumer::MessageChannel<
              body_native_service::SetGloveboxOperationRequest,
              body_native_service::SetGloveboxOperationResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for apertures_service::GetTailgateControlStatusRequest
        /// @satisfy{Requirement01321459}
        void soip_apertures_GetTailgateControlStatusRequest()
        {
          apertures_service::GetTailgateControlStatusRequest const protoData;
          consumer::MessageChannel<
              apertures_service::GetTailgateControlStatusRequest,
              apertures_service::GetTailgateControlStatusResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for propulsion_service::GetGearPositionRequest
        /// @satisfy{Requirement01321459}
        void soip_propulsion_GetGearPositionRequest()
        {
          propulsion_service::GetGearPositionRequest const protoData;
          consumer::MessageChannel<
              propulsion_service::GetGearPositionRequest,
              propulsion_service::GetGearPositionResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for apertures_service::GetDoorOpenCloseStatusRequest
        /// @satisfy{Requirement01321459}
        void soip_apertures_GetDoorOpenCloseStatusRequest()
        {
          apertures_service::GetDoorOpenCloseStatusRequest const protoData;
          consumer::MessageChannel<
              apertures_service::GetDoorOpenCloseStatusRequest,
              apertures_service::GetDoorOpenCloseStatusResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for apertures_service::SetTailgateOperationRequest
        /// @satisfy{Requirement01321459}
        void soip_apertures_SetTailgateOperationRequest(
            structapertures_SetTailgateOperationRequest const* rtu_apertures_SetTailgateOperationRequest)
        {
          apertures_service::SetTailgateOperationRequest protoData;
          jlr::cccm::di::model_to_proto_dataconverter_message(*rtu_apertures_SetTailgateOperationRequest, protoData);
          consumer::MessageChannel<
              apertures_service::SetTailgateOperationRequest,
              apertures_service::SetTailgateOperationResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for apertures_service::SetDoorsOperationRequest
        /// @satisfy{Requirement01321459}
        void soip_apertures_SetDoorsOperationRequest(
            structapertures_SetDoorsOperationRequest const* rtu_apertures_SetDoorsOperationRequest)
        {
          apertures_service::SetDoorsOperationRequest protoData;
          jlr::cccm::di::model_to_proto_dataconverter_message(*rtu_apertures_SetDoorsOperationRequest, protoData);
          consumer::MessageChannel<
              apertures_service::SetDoorsOperationRequest,
              apertures_service::SetDoorsOperationResponse>::get_instance()
              .sendRequest(protoData);
        }

        void ddsTx_quickControls(structquickControls const* rtu_quickControls)
        {
          std::shared_ptr<IModelController> const controller = get_model_controller().lock();
          if (!static_cast<bool>(controller))
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ddsTx_quickControls : ModelController is not initialized!!";
            return;
          }
          if (!static_cast<bool>(controller->get_dds_handler()))
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ddsTx_quickControls : DDS Handler is not initialized!!";
            return;
          }
          structquickControls mutableQuickControls = *rtu_quickControls;
          if (!controller->get_dds_handler()->send(&mutableQuickControls, "dds_ipc::quickControls"))
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ddsTx_quickControls : sent to HMI Fail!!";
            return;
          }
          else
          {
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS bQuickControls_IsOn "
                                    << static_cast<std::int32_t>(rtu_quickControls->bQuickControls_IsOn);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsChrgLeft_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsChrgLeft_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsChrgLeft_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsChrgLeft_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsChrgRight_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsChrgRight_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsChrgRight_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsChrgRight_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsFrunk_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsFrunk_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsFrunk_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsFrunk_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsGlovebox_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsGlovebox_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem1_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem1_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem1_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem1_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem2_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem2_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem2_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem2_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem3_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem3_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsSeatMem3_Status "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsSeatMem3_Status);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsTrunkClose_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsTrunkClose_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsTrunkOpen_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsTrunkOpen_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsTrunkPClse_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsTrunkPClse_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControlsTrunkPOpen_State "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControlsTrunkPOpen_State);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControls_LeftChrgInlet "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControls_LeftChrgInlet);
            DI_MODEL_LOG_MCTX_DEBUG << "[quickControls] DDS eQuickControls_RightChrgInlet "
                                    << static_cast<std::int32_t>(rtu_quickControls->eQuickControls_RightChrgInlet);

            DI_MODEL_LOG_MCTX_DEBUG << "ddsTx_quickControls : sent to HMI Success!!";
          }
        }

      }  // extern "C"
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
