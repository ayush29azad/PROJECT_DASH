
#include "ProtoDataConverterMessage.hpp"
#include "ProtoDataConverterScalarNumeric.hpp"
#include "ProtoDataConverterEnum.hpp"
#include "ProtoDataConverterScalarString.hpp"
#include "ProtoDataConverterScalarBytes.hpp"
#include "ProtoDataConverterRepeatedScalarNumeric.hpp"
#include "ProtoDataConverterRepeatedEnum.hpp"
#include "ProtoDataConverterRepeatedString.hpp"
#include "ProtoDataConverterRepeatedBytes.hpp"
#include "ProtoDataConverterRepeatedMessage.hpp"

#include <quickControls.h>
#include <apertures_service.pb.h>
#include <body_native_service.pb.h>
#include <body_service.pb.h>
#include <propulsion_service.pb.h>

namespace jlr::cccm::di
{

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetDoorOpenCloseStatusResponse, structapertures_GetDoorOpenCloseStatusResponse>(
      apertures_service::GetDoorOpenCloseStatusResponse const& proto_message,
      structapertures_GetDoorOpenCloseStatusResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetTailgateControlStatusResponse, structapertures_GetTailgateControlStatusResponse>(
      apertures_service::GetTailgateControlStatusResponse const& proto_message,
      structapertures_GetTailgateControlStatusResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetTailgateOperationStatusResponse, structapertures_GetTailgateOperationStatusResponse>(
      apertures_service::GetTailgateOperationStatusResponse const& proto_message,
      structapertures_GetTailgateOperationStatusResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      body_service::GetValetModeConfigStatusResponse, structbody_GetValetModeConfigStatusResponse>(
      body_service::GetValetModeConfigStatusResponse const& proto_message,
      structbody_GetValetModeConfigStatusResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<body_service::GetValetModeResponse, structbody_GetValetModeResponse>(
      body_service::GetValetModeResponse const& proto_message, structbody_GetValetModeResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      body_native_service::GetBonnetSecondaryLatchStatusResponse,
      structbody_native_GetBonnetSecondaryLatchStatusResponse>(
      body_native_service::GetBonnetSecondaryLatchStatusResponse const& proto_message,
      structbody_native_GetBonnetSecondaryLatchStatusResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      propulsion_service::GetGearPositionResponse, structpropulsion_GetGearPositionResponse>(
      propulsion_service::GetGearPositionResponse const& proto_message,
      structpropulsion_GetGearPositionResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      propulsion_service::RecommendedGearPosition, structpropulsion_RecommendedGearPosition>(
      propulsion_service::RecommendedGearPosition const& proto_message,
      structpropulsion_RecommendedGearPosition& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::NotifyDoorOpenCloseStatus, structapertures_NotifyDoorOpenCloseStatus>(
      apertures_service::NotifyDoorOpenCloseStatus const& proto_message,
      structapertures_NotifyDoorOpenCloseStatus& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::NotifyTailgateControlStatus, structapertures_NotifyTailgateControlStatus>(
      apertures_service::NotifyTailgateControlStatus const& proto_message,
      structapertures_NotifyTailgateControlStatus& model_message);

  template <>
  void
  proto_to_model_dataconverter_message<apertures_service::NotifyTailgateStatus, structapertures_NotifyTailgateStatus>(
      apertures_service::NotifyTailgateStatus const& proto_message,
      structapertures_NotifyTailgateStatus& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      body_service::NotifyValetModeConfigStatus, structbody_NotifyValetModeConfigStatus>(
      body_service::NotifyValetModeConfigStatus const& proto_message,
      structbody_NotifyValetModeConfigStatus& model_message);

  template <>
  void proto_to_model_dataconverter_message<body_service::NotifyValetModeStatus, structbody_NotifyValetModeStatus>(
      body_service::NotifyValetModeStatus const& proto_message, structbody_NotifyValetModeStatus& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      body_native_service::NotifyBonnetSecondaryLatchStatus, structbody_native_NotifyBonnetSecondaryLatchStatus>(
      body_native_service::NotifyBonnetSecondaryLatchStatus const& proto_message,
      structbody_native_NotifyBonnetSecondaryLatchStatus& model_message);

  template <>
  void
  proto_to_model_dataconverter_message<propulsion_service::NotifyGearPosition, structpropulsion_NotifyGearPosition>(
      propulsion_service::NotifyGearPosition const& proto_message, structpropulsion_NotifyGearPosition& model_message);

  template <>
  void model_to_proto_dataconverter_message<
      structapertures_SetTailgateOperationRequest, apertures_service::SetTailgateOperationRequest>(
      structapertures_SetTailgateOperationRequest const& model_message,
      apertures_service::SetTailgateOperationRequest& proto_message);

  template <>
  void model_to_proto_dataconverter_message<
      structapertures_SetDoorsOperationRequest, apertures_service::SetDoorsOperationRequest>(
      structapertures_SetDoorsOperationRequest const& model_message,
      apertures_service::SetDoorsOperationRequest& proto_message);

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetDoorOpenCloseStatusResponse, structapertures_GetDoorOpenCloseStatusResponse>(
      apertures_service::GetDoorOpenCloseStatusResponse const& proto_message,
      structapertures_GetDoorOpenCloseStatusResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.driver_door_status(), model_message.driver_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.passenger_door_status(), model_message.passenger_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.driver_rear_door_status(), model_message.driver_rear_door_status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.passenger_rear_door_status(), model_message.passenger_rear_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_status(), model_message.tailgate_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.bonnet_status(), model_message.bonnet_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetTailgateControlStatusResponse, structapertures_GetTailgateControlStatusResponse>(
      apertures_service::GetTailgateControlStatusResponse const& proto_message,
      structapertures_GetTailgateControlStatusResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.upper_tailgate(), model_message.upper_tailgate);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::GetTailgateOperationStatusResponse, structapertures_GetTailgateOperationStatusResponse>(
      apertures_service::GetTailgateOperationStatusResponse const& proto_message,
      structapertures_GetTailgateOperationStatusResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_operation_status(), model_message.tailgate_operation_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_error_status(), model_message.tailgate_error_status);
    }

    {
      ProtoToModelDataConverterScalarNumeric(proto_message.tailgate_position(), model_message.tailgate_position);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      body_service::GetValetModeConfigStatusResponse, structbody_GetValetModeConfigStatusResponse>(
      body_service::GetValetModeConfigStatusResponse const& proto_message,
      structbody_GetValetModeConfigStatusResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.front_trunk_lockout_status(), model_message.front_trunk_lockout_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_lockout_status(), model_message.tailgate_lockout_status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.taildoor_box_lockout_status(), model_message.taildoor_box_lockout_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<body_service::GetValetModeResponse, structbody_GetValetModeResponse>(
      body_service::GetValetModeResponse const& proto_message, structbody_GetValetModeResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.valet_mode_state(), model_message.valet_mode_state);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.valet_mode_availability(), model_message.valet_mode_availability);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      body_native_service::GetBonnetSecondaryLatchStatusResponse,
      structbody_native_GetBonnetSecondaryLatchStatusResponse>(
      body_native_service::GetBonnetSecondaryLatchStatusResponse const& proto_message,
      structbody_native_GetBonnetSecondaryLatchStatusResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.secondary_latch_status(), model_message.secondary_latch_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      propulsion_service::GetGearPositionResponse, structpropulsion_GetGearPositionResponse>(
      propulsion_service::GetGearPositionResponse const& proto_message,
      structpropulsion_GetGearPositionResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.gear_position_to_display(), model_message.gear_position_to_display);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.gear_actual_position(), model_message.gear_actual_position);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.trans_mode(), model_message.trans_mode);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.gear_mode(), model_message.gear_mode);
    }

    {
      proto_to_model_dataconverter_message(proto_message.gear_pos_rec(), model_message.gear_pos_rec);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      propulsion_service::RecommendedGearPosition, structpropulsion_RecommendedGearPosition>(
      propulsion_service::RecommendedGearPosition const& proto_message,
      structpropulsion_RecommendedGearPosition& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.gear_position_recommendation(), model_message.gear_position_recommendation);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.gear_shift_dir_rec(), model_message.gear_shift_dir_rec);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::NotifyDoorOpenCloseStatus, structapertures_NotifyDoorOpenCloseStatus>(
      apertures_service::NotifyDoorOpenCloseStatus const& proto_message,
      structapertures_NotifyDoorOpenCloseStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.driver_door_status(), model_message.driver_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.passenger_door_status(), model_message.passenger_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.driver_rear_door_status(), model_message.driver_rear_door_status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.passenger_rear_door_status(), model_message.passenger_rear_door_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_status(), model_message.tailgate_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.bonnet_status(), model_message.bonnet_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      apertures_service::NotifyTailgateControlStatus, structapertures_NotifyTailgateControlStatus>(
      apertures_service::NotifyTailgateControlStatus const& proto_message,
      structapertures_NotifyTailgateControlStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.upper_tailgate(), model_message.upper_tailgate);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }
  }

  template <>
  void
  proto_to_model_dataconverter_message<apertures_service::NotifyTailgateStatus, structapertures_NotifyTailgateStatus>(
      apertures_service::NotifyTailgateStatus const& proto_message, structapertures_NotifyTailgateStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_operation_status(), model_message.tailgate_operation_status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.tailgate_error_status(), model_message.tailgate_error_status);
    }

    {
      ProtoToModelDataConverterScalarNumeric(proto_message.tailgate_position(), model_message.tailgate_position);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      body_service::NotifyValetModeConfigStatus, structbody_NotifyValetModeConfigStatus>(
      body_service::NotifyValetModeConfigStatus const& proto_message,
      structbody_NotifyValetModeConfigStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.valet_mode_lockout_target(), model_message.valet_mode_lockout_target);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.valet_mode_lockout_target_status(), model_message.valet_mode_lockout_target_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<body_service::NotifyValetModeStatus, structbody_NotifyValetModeStatus>(
      body_service::NotifyValetModeStatus const& proto_message, structbody_NotifyValetModeStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.valet_mode_state(), model_message.valet_mode_state);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.valet_mode_availability(), model_message.valet_mode_availability);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      body_native_service::NotifyBonnetSecondaryLatchStatus, structbody_native_NotifyBonnetSecondaryLatchStatus>(
      body_native_service::NotifyBonnetSecondaryLatchStatus const& proto_message,
      structbody_native_NotifyBonnetSecondaryLatchStatus& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.secondary_latch_status(), model_message.secondary_latch_status);
    }
  }

  template <>
  void
  proto_to_model_dataconverter_message<propulsion_service::NotifyGearPosition, structpropulsion_NotifyGearPosition>(
      propulsion_service::NotifyGearPosition const& proto_message, structpropulsion_NotifyGearPosition& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.gear_position_to_display(), model_message.gear_position_to_display);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.gear_actual_position(), model_message.gear_actual_position);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.trans_mode(), model_message.trans_mode);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.gear_mode(), model_message.gear_mode);
    }

    {
      proto_to_model_dataconverter_message(proto_message.gear_pos_rec(), model_message.gear_pos_rec);
    }
  }

  template <>
  void model_to_proto_dataconverter_message<
      structapertures_SetTailgateOperationRequest, apertures_service::SetTailgateOperationRequest>(
      structapertures_SetTailgateOperationRequest const& model_message,
      apertures_service::SetTailgateOperationRequest& proto_message)
  {

    {
      using proto_enum_type = decltype(proto_message.tailgate_operation_request());
      auto setter = [pm = &proto_message](proto_enum_type const value) -> void
      {
        pm->set_tailgate_operation_request(value);
      };

      ModelToProtoDataConverterEnum<proto_enum_type>(model_message.tailgate_operation_request, setter);
    }
  }

  template <>
  void model_to_proto_dataconverter_message<
      structapertures_SetDoorsOperationRequest, apertures_service::SetDoorsOperationRequest>(
      structapertures_SetDoorsOperationRequest const& model_message,
      apertures_service::SetDoorsOperationRequest& proto_message)
  {

    {
      using proto_enum_type = decltype(proto_message.door_selection());
      auto setter = [pm = &proto_message](proto_enum_type const value) -> void
      {
        pm->set_door_selection(value);
      };

      ModelToProtoDataConverterEnum<proto_enum_type>(model_message.door_selection, setter);
    }

    {
      using proto_enum_type = decltype(proto_message.door_request());
      auto setter = [pm = &proto_message](proto_enum_type const value) -> void
      {
        pm->set_door_request(value);
      };

      ModelToProtoDataConverterEnum<proto_enum_type>(model_message.door_request, setter);
    }
  }

}  // namespace jlr::cccm::di
