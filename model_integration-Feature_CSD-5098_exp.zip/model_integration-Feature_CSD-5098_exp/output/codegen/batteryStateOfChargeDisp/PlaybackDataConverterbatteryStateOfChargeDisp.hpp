

#ifndef MODEL_DATA_CONVERTER_HEADER_H
#define MODEL_DATA_CONVERTER_HEADER_H

#include <cstdint>
#include <json/json.h>
#include <batteryStateOfChargeDisp.h>
#include <CombinedTopicsPubSubTypes.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      class PlaybackDataConverterbatteryStateOfChargeDisp
      {
      public:
        static void create_json(structenergymanagement_ReserveBatterySoc const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["reserve_battery_soc_feature"] = static_cast<int32_t>(model_data->reserve_battery_soc_feature);
          obj["reserve_battery_soc_level"] = model_data->reserve_battery_soc_level;
        }

        static void create_json(
            structenergymanagement_GetBatteryChargeResponse const* const model_data, Json::Value& obj)
        {
          obj["batt_level_colour"] = static_cast<int32_t>(model_data->batt_level_colour);
          obj["battery_state_of_charge"] = model_data->battery_state_of_charge;
          obj["status"] = static_cast<int32_t>(model_data->status);
        }

        static void create_json(
            structenergymanagement_GetEVReserveModeBatterySOCDataResponse const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["ev_reserve_soc_lower_limit"] = model_data->ev_reserve_soc_lower_limit;
          obj["ev_reserve_soc_upper_limit"] = model_data->ev_reserve_soc_upper_limit;
          obj["ev_reserve_soc_current_level"] = model_data->ev_reserve_soc_current_level;
          obj["ev_reserve_soc_target_level"] = model_data->ev_reserve_soc_target_level;
          obj["reserve_soc_data_status"] = Json::objectValue;
          create_json(&(model_data->reserve_soc_data_status), obj["reserve_soc_data_status"]);
        }

        static void create_json(structenergymanagement_NotifyBatteryCharge const* const model_data, Json::Value& obj)
        {
          obj["batt_level_colour"] = static_cast<int32_t>(model_data->batt_level_colour);
          obj["battery_state_of_charge"] = model_data->battery_state_of_charge;
          obj["status"] = static_cast<int32_t>(model_data->status);
        }

        static void create_json(
            structenergymanagement_NotifyEVReserveModeBatterySOCData const* const model_data, Json::Value& obj)
        {
          obj["status"] = static_cast<int32_t>(model_data->status);
          obj["ev_reserve_soc_lower_limit"] = model_data->ev_reserve_soc_lower_limit;
          obj["ev_reserve_soc_upper_limit"] = model_data->ev_reserve_soc_upper_limit;
          obj["ev_reserve_soc_current_level"] = model_data->ev_reserve_soc_current_level;
          obj["ev_reserve_soc_target_level"] = model_data->ev_reserve_soc_target_level;
          obj["reserve_soc_data_status"] = Json::objectValue;
          create_json(&(model_data->reserve_soc_data_status), obj["reserve_soc_data_status"]);
        }
      };
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
