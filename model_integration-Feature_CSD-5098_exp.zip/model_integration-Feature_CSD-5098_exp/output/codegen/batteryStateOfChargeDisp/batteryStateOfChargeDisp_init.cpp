
#include <memory>
#include <fstream>
#include <json/json.h>
#include <cstdint>
#include "ModelController.hpp"
#include <batteryStateOfChargeDisp.h>
#include "WrapperbatteryStateOfChargeDisp.h"
#include "batteryStateOfChargeDisp_global_vars.hpp"
#include "creator.h"

extern "C" std::shared_ptr<cccm::di::ModelLibInterface> creator()
{
  // @brief alias of ModelController template for batteryStateOfChargeDispModelClass
  // using ModelControllerType
  //  = jlr::cccm::di::ModelController<batteryStateOfChargeDispModelClass>;

  return std::make_shared<cccm::di::models::WrapperbatteryStateOfChargeDisp<batteryStateOfChargeDispModelClass>>(
      std::make_shared<batteryStateOfChargeDispModelClass>());
}
