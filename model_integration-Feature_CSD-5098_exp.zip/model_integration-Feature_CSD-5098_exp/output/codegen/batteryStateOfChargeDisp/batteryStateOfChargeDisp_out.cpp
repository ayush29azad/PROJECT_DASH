#include "dlt_logger.hpp"
#include "ProtoDataConverterMessage.hpp"
#include <SomeipServiceConsumer.hpp>
#include <SomeipServiceProvider.hpp>
#include <DdsCommunicationHandler.hpp>

#include <ModelController.hpp>
#include "batteryStateOfChargeDisp_global_vars.hpp"
#include "ProtoIncludesbatteryStateOfChargeDisp.hpp"
#include "batteryStateOfChargeDisp.h"

#include <soip_energymanagement_GetBatteryChargeRequest.h>
#include <soip_energymanagement_GetEVReserveModeBatterySOCDataRequest.h>
#include <ddsTx_batteryStateOfChargeDisp.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {

      extern "C"
      {

        /// @brief Sends out a someip request for energymanagement_service::GetBatteryChargeRequest
        /// @satisfy{Requirement01321459}
        void soip_energymanagement_GetBatteryChargeRequest()
        {
          energymanagement_service::GetBatteryChargeRequest const protoData;
          consumer::MessageChannel<
              energymanagement_service::GetBatteryChargeRequest,
              energymanagement_service::GetBatteryChargeResponse>::get_instance()
              .sendRequest(protoData);
        }

        /// @brief Sends out a someip request for energymanagement_service::GetEVReserveModeBatterySOCDataRequest
        /// @satisfy{Requirement01321459}
        void soip_energymanagement_GetEVReserveModeBatterySOCDataRequest()
        {
          energymanagement_service::GetEVReserveModeBatterySOCDataRequest const protoData;
          consumer::MessageChannel<
              energymanagement_service::GetEVReserveModeBatterySOCDataRequest,
              energymanagement_service::GetEVReserveModeBatterySOCDataResponse>::get_instance()
              .sendRequest(protoData);
        }

        void ddsTx_batteryStateOfChargeDisp(structbatteryStateOfChargeDisp const* rtu_batteryStateOfChargeDisp)
        {
          std::shared_ptr<IModelController> const controller = get_model_controller().lock();
          if (!static_cast<bool>(controller))
          {
            DI_MODEL_LOG_MCTX_ERROR
                << "[Error] : ddsTx_batteryStateOfChargeDisp : ModelController is not initialized!!";
            return;
          }
          if (!static_cast<bool>(controller->get_dds_handler()))
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ddsTx_batteryStateOfChargeDisp : DDS Handler is not initialized!!";
            return;
          }
          structbatteryStateOfChargeDisp mutableBatteryStateOfChargeDisp = *rtu_batteryStateOfChargeDisp;
          if (!controller->get_dds_handler()->send(
                  &mutableBatteryStateOfChargeDisp, "dds_ipc::batteryStateOfChargeDisp"))
          {
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : ddsTx_batteryStateOfChargeDisp : sent to HMI Fail!!";
            return;
          }
          else
          {
            DI_MODEL_LOG_MCTX_DEBUG << "[batteryStateOfChargeDisp] DDS bBatteryStateOfCharge_Lock_IsOn "
                                    << static_cast<std::int32_t>(
                                           rtu_batteryStateOfChargeDisp->bBatteryStateOfCharge_Lock_IsOn);
            DI_MODEL_LOG_MCTX_DEBUG << "[batteryStateOfChargeDisp] DDS eBatteryStateOfCharge_Colour "
                                    << static_cast<std::int32_t>(
                                           rtu_batteryStateOfChargeDisp->eBatteryStateOfCharge_Colour);
            DI_MODEL_LOG_MCTX_DEBUG << "[batteryStateOfChargeDisp] DDS iBatteryStateOfCharge_Lock_Pos "
                                    << static_cast<std::int32_t>(
                                           rtu_batteryStateOfChargeDisp->iBatteryStateOfCharge_Lock_Pos);
            DI_MODEL_LOG_MCTX_DEBUG << "[batteryStateOfChargeDisp] DDS iBatteryStateOfCharge_Value "
                                    << static_cast<std::int32_t>(
                                           rtu_batteryStateOfChargeDisp->iBatteryStateOfCharge_Value);

            DI_MODEL_LOG_MCTX_DEBUG << "ddsTx_batteryStateOfChargeDisp : sent to HMI Success!!";
          }
        }

      }  // extern "C"
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
