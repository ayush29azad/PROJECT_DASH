
#include "ProtoDataConverterMessage.hpp"
#include "ProtoDataConverterScalarNumeric.hpp"
#include "ProtoDataConverterEnum.hpp"
#include "ProtoDataConverterScalarString.hpp"
#include "ProtoDataConverterScalarBytes.hpp"
#include "ProtoDataConverterRepeatedScalarNumeric.hpp"
#include "ProtoDataConverterRepeatedEnum.hpp"
#include "ProtoDataConverterRepeatedString.hpp"
#include "ProtoDataConverterRepeatedBytes.hpp"
#include "ProtoDataConverterRepeatedMessage.hpp"

#include <batteryStateOfChargeDisp.h>
#include <energymanagement_service.pb.h>

namespace jlr::cccm::di
{

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::GetBatteryChargeResponse, structenergymanagement_GetBatteryChargeResponse>(
      energymanagement_service::GetBatteryChargeResponse const& proto_message,
      structenergymanagement_GetBatteryChargeResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::GetEVReserveModeBatterySOCDataResponse,
      structenergymanagement_GetEVReserveModeBatterySOCDataResponse>(
      energymanagement_service::GetEVReserveModeBatterySOCDataResponse const& proto_message,
      structenergymanagement_GetEVReserveModeBatterySOCDataResponse& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::ReserveBatterySoc, structenergymanagement_ReserveBatterySoc>(
      energymanagement_service::ReserveBatterySoc const& proto_message,
      structenergymanagement_ReserveBatterySoc& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::NotifyBatteryCharge, structenergymanagement_NotifyBatteryCharge>(
      energymanagement_service::NotifyBatteryCharge const& proto_message,
      structenergymanagement_NotifyBatteryCharge& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::NotifyEVReserveModeBatterySOCData,
      structenergymanagement_NotifyEVReserveModeBatterySOCData>(
      energymanagement_service::NotifyEVReserveModeBatterySOCData const& proto_message,
      structenergymanagement_NotifyEVReserveModeBatterySOCData& model_message);

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::GetBatteryChargeResponse, structenergymanagement_GetBatteryChargeResponse>(
      energymanagement_service::GetBatteryChargeResponse const& proto_message,
      structenergymanagement_GetBatteryChargeResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.batt_level_colour(), model_message.batt_level_colour);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.battery_state_of_charge(), model_message.battery_state_of_charge);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::GetEVReserveModeBatterySOCDataResponse,
      structenergymanagement_GetEVReserveModeBatterySOCDataResponse>(
      energymanagement_service::GetEVReserveModeBatterySOCDataResponse const& proto_message,
      structenergymanagement_GetEVReserveModeBatterySOCDataResponse& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_lower_limit(), model_message.ev_reserve_soc_lower_limit);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_upper_limit(), model_message.ev_reserve_soc_upper_limit);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_current_level(), model_message.ev_reserve_soc_current_level);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_target_level(), model_message.ev_reserve_soc_target_level);
    }

    {
      proto_to_model_dataconverter_message(
          proto_message.reserve_soc_data_status(), model_message.reserve_soc_data_status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::ReserveBatterySoc, structenergymanagement_ReserveBatterySoc>(
      energymanagement_service::ReserveBatterySoc const& proto_message,
      structenergymanagement_ReserveBatterySoc& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterEnum(
          proto_message.reserve_battery_soc_feature(), model_message.reserve_battery_soc_feature);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.reserve_battery_soc_level(), model_message.reserve_battery_soc_level);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::NotifyBatteryCharge, structenergymanagement_NotifyBatteryCharge>(
      energymanagement_service::NotifyBatteryCharge const& proto_message,
      structenergymanagement_NotifyBatteryCharge& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.batt_level_colour(), model_message.batt_level_colour);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.battery_state_of_charge(), model_message.battery_state_of_charge);
    }

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }
  }

  template <>
  void proto_to_model_dataconverter_message<
      energymanagement_service::NotifyEVReserveModeBatterySOCData,
      structenergymanagement_NotifyEVReserveModeBatterySOCData>(
      energymanagement_service::NotifyEVReserveModeBatterySOCData const& proto_message,
      structenergymanagement_NotifyEVReserveModeBatterySOCData& model_message)
  {

    {
      ProtoToModelDataConverterEnum(proto_message.status(), model_message.status);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_lower_limit(), model_message.ev_reserve_soc_lower_limit);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_upper_limit(), model_message.ev_reserve_soc_upper_limit);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_current_level(), model_message.ev_reserve_soc_current_level);
    }

    {
      ProtoToModelDataConverterScalarNumeric(
          proto_message.ev_reserve_soc_target_level(), model_message.ev_reserve_soc_target_level);
    }

    {
      proto_to_model_dataconverter_message(
          proto_message.reserve_soc_data_status(), model_message.reserve_soc_data_status);
    }
  }

}  // namespace jlr::cccm::di
