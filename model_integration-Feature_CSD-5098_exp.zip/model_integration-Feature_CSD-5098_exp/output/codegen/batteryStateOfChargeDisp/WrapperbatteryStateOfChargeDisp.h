#ifndef JLRCCCM_MODEL_IPC_WRAPPER_HEADER_batteryStateOfChargeDisp
#define JLRCCCM_MODEL_IPC_WRAPPER_HEADER_batteryStateOfChargeDisp

#include <iostream>
#include <memory>

#include "ModelLibInterface.h"
#include "types.h"
#include "dlt_logger.hpp"
#include "PlaybackDataConverterbatteryStateOfChargeDisp.hpp"
#include "ProtoIncludesbatteryStateOfChargeDisp.hpp"
#include "release_version.h"
#include "SomeipInstanceIdMapping.hpp"
#include "ModelController.hpp"
#include "batteryStateOfChargeDisp_global_vars.hpp"

namespace cccm::di::models
{
  /// @brief The Concrete Implementation of ModelLibInterface for batteryStateOfChargeDisp
  ///
  /// @details This class will implement init and terminate methods of
  /// ModelLibInterface to register comms with the models as well as timers
  ///
  /// This class is templated to allow injection of a mock model which follows
  /// the same interface as batteryStateOfChargeDisp which allows to test
  ///
  /// @tparam ModelClasss Either batteryStateOfChargeDisp or a mock model which follows the
  /// the same interface
  template <typename ModelClass>
  class WrapperbatteryStateOfChargeDisp final : public cccm::di::ModelLibInterface
  {
  private:
    using PlaybackDataConverterbatteryStateOfChargeDisp = jlr::cccm::di::PlaybackDataConverterbatteryStateOfChargeDisp;
    using ServiceInstanceIdMapping = ipc_wrapper::instance_id_mapping::ServiceInstanceIdMapping;
    // @brief alias of ModelController template for ModelClass
    using ModelControllerType = jlr::cccm::di::ModelController<ModelClass>;
    using SomeipCommunicationHandler = jlr::cccm::di::SomeipCommunicationHandler;

    std::shared_ptr<ModelClass> mModelPtr;
    std::shared_ptr<ModelControllerType> mModelController;

    uint16_t notifyBatteryChargeID;
    uint16_t notifyEVReserveModeBatterySOCDataID;
    uint16_t getBatteryChargeResponseID;
    uint16_t getEVReserveModeBatterySOCDataResponseID;

  public:
    /// @brief deleted default constructor to enforce initialisation with a model
    WrapperbatteryStateOfChargeDisp() = delete;

    /// @brief constructs the wrapper with a given model instance
    WrapperbatteryStateOfChargeDisp(std::shared_ptr<ModelClass> const& _mModelPtr)
        : cccm::di::ModelLibInterface()
        , mModelPtr(_mModelPtr)
        ,

        notifyBatteryChargeID(static_cast<uint16_t>(0x8001))
        , notifyEVReserveModeBatterySOCDataID(static_cast<uint16_t>(0x8019))
        , getBatteryChargeResponseID(static_cast<uint16_t>(0x0001))
        , getEVReserveModeBatterySOCDataResponseID(static_cast<uint16_t>(0x0020))
    {
    }

    /// @brief Default destructor
    ~WrapperbatteryStateOfChargeDisp() override = default;

    /// @brief Implements ModelLibInterface init
    ///
    /// @satisfy{Requirement01321452,Requirement01321457,Requirement01321459,Requirement01321608,Requirement01321460,Requirement01321463,Requirement01321626,Requirement01340698,Requirement01321467,Requirement01321613,Requirement01321612,Requirement01415381,Requirement01415387,Requirement01415483,
    /// Requirement01415577, Requirement01446314, Requirement01446316, Requirement01446329, Requirement01445541}
    ///
    /// @param context Launcher context which injects all comms dependencies
    void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) final
    {

      auto const vsomeipMap = context->someipApp_map;
      std::shared_ptr<WorkExecutor> const& workExecutor = context->workExecutor;
      std::shared_ptr<jlr::cccm::di::dds::DDSEntityFactoryInterface> const& ddsFactory = context->ddsFactory;
      std::string const& dltAppId = context->dltApplication.first;
      std::string const& dltAppDescription = context->dltApplication.second;
      std::string const& someipMappingFilename = context->someipMappingFilename;

#if defined(ENABLE_DLT_LOGGING)
      generic_logging::initialize_loggers(
          dltAppId,
          logging::ctx,
          dltAppDescription,
          "DI batteryStateOfChargeDisp",
          std::vector<generic_logging::LoggerKind>{generic_logging::LoggerKind::dlt_log},
          logging::g_use_multi_contexts);
#endif

      // Output which release package this library is from
      DI_MODEL_LOG_MCTX_INFO << "Release version information: " << version::release_version << std::endl;

      if (nullptr == workExecutor)
      {
        DI_MODEL_LOG_MCTX_WARN << "[Warn] : WorkExecutor is NULL, Can Impact the latency";
      }

      this->mModelController = std::make_shared<ModelControllerType>();
      // Set global model controller
      {
        // BUG: Make this operation atomic. If two threads try to create a controller at the same time, this will result
        // in unexpected behavior. However, this can be ignored since that is not expected to happen in the current
        // architecture.
        if (!jlr::cccm::di::get_model_controller().expired())
        {
          throw std::runtime_error("Model controller already exists. Cannot create a new one.");
        }
        jlr::cccm::di::set_model_controller(this->mModelController);
      }

      mModelController->init_model(mModelPtr);

      {
        int32_t const numOfvIds = 1;
        if (vsomeipMap.size() < numOfvIds)
        {
          throw std::runtime_error(
              "Can not initialize someip handlers, number of vid in vsomeip services and in arguments do not match!!");
        }
        std::vector<std::string> const vids = {"vid10"};
        bool allPresent = true;
        for (std::size_t i = 0; i < vids.size(); ++i)
        {
          if (vsomeipMap.find(vids[i]) == vsomeipMap.end())
          {
            allPresent = false;
            DI_MODEL_LOG_MCTX_ERROR << "[Error] : vid " << vids[i] << " is not passed in arguments" << std::endl;
          }
        }
        if (allPresent == false)
        {
          throw std::runtime_error(
              "Can not initialize someip handlers, vids in vsomeip services and in arguments do not match!!");
        }
      }

      // VSOMEIP COMMS HANDLING
      for (auto it = vsomeipMap.begin(); it != vsomeipMap.end(); ++it)
      {
        std::shared_ptr<vsomeip::application> const _app = it->second;
        if (_app != nullptr)
        {
          std::string const _key = it->first;
          mModelController->init_model_someip(_app, _key);
        }
      }

      std::shared_ptr<SomeipCommunicationHandler> someipHandlerVid10 = mModelController->get_someip_handler("vid10");

      bool parsed = false;

      ServiceInstanceIdMapping instanceMapping;

#if defined(INSTANCE_ID_MAPPING)
      parsed = instanceMapping.parse_json(someipMappingFilename);
      if (parsed == false)
      {
        DI_MODEL_LOG_MCTX_WARN << "[Warn] Couldn't parse someip instance id json file, using defaults" << std::endl;
      }
#endif

      // SOMEIP initialisation

      vsomeip::instance_t const energymanagementServiceInstanceid =
          instanceMapping.get_service_instanceId("energymanagement_service");
      vsomeip::instance_t const energymanagementServiceServiceid = static_cast<vsomeip::instance_t>(0x0009);

      DI_MODEL_LOG_MCTX_INFO << "energymanagementServiceInstanceid-> " << energymanagementServiceInstanceid
                             << std::endl;
      auto const energymanagementServiceConsumer =
          someipHandlerVid10->create_consumer(energymanagementServiceServiceid, energymanagementServiceInstanceid);

      auto const soip_energymanagement_NotifyBatteryCharge =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structenergymanagement_NotifyBatteryCharge const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_energymanagement_NotifyBatteryCharge";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structenergymanagement_NotifyBatteryCharge"] = Json::objectValue;
          PlaybackDataConverterbatteryStateOfChargeDisp::create_json(
              modelData, obj["args"][0]["structenergymanagement_NotifyBatteryCharge"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_energymanagement_NotifyBatteryCharge(modelData);
      };
      someipHandlerVid10
          ->notify_in<energymanagement_service::NotifyBatteryCharge, structenergymanagement_NotifyBatteryCharge>(
              energymanagementServiceConsumer,
              notifyBatteryChargeID,
              std::vector<uint16_t>{0x4455, 0x1111},
              soip_energymanagement_NotifyBatteryCharge);

      auto const soip_energymanagement_NotifyEVReserveModeBatterySOCData =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structenergymanagement_NotifyEVReserveModeBatterySOCData const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_energymanagement_NotifyEVReserveModeBatterySOCData";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structenergymanagement_NotifyEVReserveModeBatterySOCData"] = Json::objectValue;
          PlaybackDataConverterbatteryStateOfChargeDisp::create_json(
              modelData, obj["args"][0]["structenergymanagement_NotifyEVReserveModeBatterySOCData"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_energymanagement_NotifyEVReserveModeBatterySOCData(modelData);
      };
      someipHandlerVid10->notify_in<
          energymanagement_service::NotifyEVReserveModeBatterySOCData,
          structenergymanagement_NotifyEVReserveModeBatterySOCData>(
          energymanagementServiceConsumer,
          notifyEVReserveModeBatterySOCDataID,
          std::vector<uint16_t>{0x3146},
          soip_energymanagement_NotifyEVReserveModeBatterySOCData);

      auto const soip_energymanagement_GetBatteryChargeResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structenergymanagement_GetBatteryChargeResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_energymanagement_GetBatteryChargeResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structenergymanagement_GetBatteryChargeResponse"] = Json::objectValue;
          PlaybackDataConverterbatteryStateOfChargeDisp::create_json(
              modelData, obj["args"][0]["structenergymanagement_GetBatteryChargeResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_energymanagement_GetBatteryChargeResponse(modelData);
      };
      someipHandlerVid10->response_in<
          energymanagement_service::GetBatteryChargeRequest,
          energymanagement_service::GetBatteryChargeResponse,
          structenergymanagement_GetBatteryChargeResponse>(
          energymanagementServiceConsumer, getBatteryChargeResponseID, soip_energymanagement_GetBatteryChargeResponse);

      auto const soip_energymanagement_GetEVReserveModeBatterySOCDataResponse =
          [mModelPtr = mModelPtr,
           dltAppId = dltAppId](structenergymanagement_GetEVReserveModeBatterySOCDataResponse const* const modelData)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_energymanagement_GetEVReserveModeBatterySOCDataResponse";
          obj["args"] = Json::arrayValue;
          obj["args"][0] = Json::objectValue;
          obj["args"][0]["structenergymanagement_GetEVReserveModeBatterySOCDataResponse"] = Json::objectValue;
          PlaybackDataConverterbatteryStateOfChargeDisp::create_json(
              modelData, obj["args"][0]["structenergymanagement_GetEVReserveModeBatterySOCDataResponse"]);
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return something
        }
#endif
        mModelPtr->soip_energymanagement_GetEVReserveModeBatterySOCDataResponse(modelData);
      };
      someipHandlerVid10->response_in<
          energymanagement_service::GetEVReserveModeBatterySOCDataRequest,
          energymanagement_service::GetEVReserveModeBatterySOCDataResponse,
          structenergymanagement_GetEVReserveModeBatterySOCDataResponse>(
          energymanagementServiceConsumer,
          getEVReserveModeBatterySOCDataResponseID,
          soip_energymanagement_GetEVReserveModeBatterySOCDataResponse);

      // On available

      auto const on_available = [mModelPtr = mModelPtr, dltAppId = dltAppId](
                                    uint16_t const serviceId, uint16_t const instanceId, bool const isAvailable)
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "soip_on_available";
          obj["args"] = Json::arrayValue;

          obj["args"][0] = Json::objectValue;
          obj["args"][0]["serviceId"] = serviceId;
          obj["args"][1] = Json::objectValue;
          obj["args"][1]["instanceId"] = instanceId;
          obj["args"][2] = Json::objectValue;
          obj["args"][2]["isAvailable"] = isAvailable;

          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_DEBUG << document << "\n";
        }
#endif
        mModelPtr->soip_on_available(serviceId, instanceId, isAvailable);
      };

      someipHandlerVid10->set_on_available(energymanagementServiceConsumer, on_available);

      // DDS COMMS HANDLING

      mModelController->init_model_dds(ddsFactory, dltAppId);
      auto ddsHandler = mModelController->get_dds_handler();
      ddsHandler->set_work_executor(workExecutor);

      {
        std::unique_ptr<dds_ipc::batteryStateOfChargeDispPubSubType> batteryStateOfChargeDispPtr =
            std::make_unique<dds_ipc::batteryStateOfChargeDispPubSubType>();
        bool const topicOutRegistrationStatus =
            ddsHandler->topic_out("dds_ipc::batteryStateOfChargeDisp", batteryStateOfChargeDispPtr.release());
        if (topicOutRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS publish topic, dds_ipc::dds_ipc::batteryStateOfChargeDisp Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS publish topic, dds_ipc::dds_ipc::batteryStateOfChargeDisp failed!!";
        }
      }

      {
        std::function<void(structdynamicConfigInt const*)> modelCallBack{};
        modelCallBack = [mModelPtr = mModelPtr, dltAppId = dltAppId](structdynamicConfigInt const* modelData)
        {
#if defined(ENABLE_MODEL_PLAYBACK)
          bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                        boost::log::trivial::severity_level::trace;
#endif
          if (jsonPayload)
          {

            /*{
              Json::Value obj = Json::objectValue;
              obj["model_func_name"] = "ddsRx_dynamicConfigInt";
              obj["args"] = Json::arrayValue;
              obj["args"][0] = Json::objectValue;
              obj["args"][0]["structdynamicConfigInt"] = Json::objectValue;
              PlaybackDataConverterbatteryStateOfChargeDisp::create_json(modelData,
            obj["args"][0]["structdynamicConfigInt"] ); Json::StreamWriterBuilder wBuilder; wBuilder["indentation"] =
            ""; const std::string document = Json::writeString(wBuilder,obj); DI_MODEL_LOG_MCTX_DEBUG << document <<
            "\n";
            }*/
          }
#endif
          mModelPtr->ddsRx_dynamicConfigInt(modelData);
        };

        auto const callBack = [modelCallBack, ddsHandler = ddsHandler.get(), workExecutor = workExecutor.get()]()
        {
          structdynamicConfigInt modelData;

          if (ddsHandler->recv(&modelData, "dds_ipc::dynamicConfigInt") == true)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "Received dds_ipc::dynamicConfigInt data from ddsHandler" << std::endl;
            if (workExecutor != nullptr)
            {
              auto data_ = modelData;
              workExecutor->addWork(
                  [modelCallBack, data_]()
                  {
                    modelCallBack(&data_);
                  });
            }
            else
            {
              modelCallBack(&modelData);
            }
          }
          else
          {
            DI_MODEL_LOG_MCTX_WARN << "[Warn]: No data read from ddsHandler" << std::endl;
          }
        };

        std::unique_ptr<dds_ipc::dynamicConfigIntPubSubType> dynamicConfigIntPtr =
            std::make_unique<dds_ipc::dynamicConfigIntPubSubType>();
        bool const topicInRegistrationStatus =
            ddsHandler->topic_in("dds_ipc::dynamicConfigInt", dynamicConfigIntPtr.release(), callBack);
        if (topicInRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::dynamicConfigInt Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::dynamicConfigInt failed!!";
        }
      }

      {
        std::function<void(structvehicleLifecycleInt const*)> modelCallBack{};
        modelCallBack = [mModelPtr = mModelPtr, dltAppId = dltAppId](structvehicleLifecycleInt const* modelData)
        {
#if defined(ENABLE_MODEL_PLAYBACK)
          bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
          jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                        boost::log::trivial::severity_level::trace;
#endif
          if (jsonPayload)
          {

            /*{
              Json::Value obj = Json::objectValue;
              obj["model_func_name"] = "ddsRx_vehicleLifecycleInt";
              obj["args"] = Json::arrayValue;
              obj["args"][0] = Json::objectValue;
              obj["args"][0]["structvehicleLifecycleInt"] = Json::objectValue;
              PlaybackDataConverterbatteryStateOfChargeDisp::create_json(modelData,
            obj["args"][0]["structvehicleLifecycleInt"] ); Json::StreamWriterBuilder wBuilder; wBuilder["indentation"] =
            ""; const std::string document = Json::writeString(wBuilder,obj); DI_MODEL_LOG_MCTX_DEBUG << document <<
            "\n";
            }*/
          }
#endif
          mModelPtr->ddsRx_vehicleLifecycleInt(modelData);
        };

        auto const callBack = [modelCallBack, ddsHandler = ddsHandler.get(), workExecutor = workExecutor.get()]()
        {
          structvehicleLifecycleInt modelData;

          if (ddsHandler->recv(&modelData, "dds_ipc::vehicleLifecycleInt") == true)
          {
            DI_MODEL_LOG_MCTX_DEBUG << "Received dds_ipc::vehicleLifecycleInt data from ddsHandler" << std::endl;
            if (workExecutor != nullptr)
            {
              auto data_ = modelData;
              workExecutor->addWork(
                  [modelCallBack, data_]()
                  {
                    modelCallBack(&data_);
                  });
            }
            else
            {
              modelCallBack(&modelData);
            }
          }
          else
          {
            DI_MODEL_LOG_MCTX_WARN << "[Warn]: No data read from ddsHandler" << std::endl;
          }
        };

        std::unique_ptr<dds_ipc::vehicleLifecycleIntPubSubType> vehicleLifecycleIntPtr =
            std::make_unique<dds_ipc::vehicleLifecycleIntPubSubType>();
        bool const topicInRegistrationStatus =
            ddsHandler->topic_in("dds_ipc::vehicleLifecycleInt", vehicleLifecycleIntPtr.release(), callBack);
        if (topicInRegistrationStatus == true)
        {
          DI_MODEL_LOG_MCTX_INFO
              << "[Info]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::vehicleLifecycleInt Success!!";
        }
        else
        {
          DI_MODEL_LOG_MCTX_ERROR
              << "[error]  : Registration of DDS subscriber topic, dds_ipc::dds_ipc::vehicleLifecycleInt failed!!";
        }
      }

      // MODEL TIMER HANDLING

      int32_t const timer_period = static_cast<int32_t>(100);
      std::string const _threadName = std::string("batteryStateOfChargeDisp") + std::string("_timerThread");

      auto const timerFun = [mModelPtr = mModelPtr, dltAppId = dltAppId]()
      {
#if defined(ENABLE_MODEL_PLAYBACK)
        bool jsonPayload = true;
#if defined(ENABLE_DLT_LOGGING)
        jsonPayload = generic_logging::get_log_level_for_dlt_only(dltAppId, logging::ctx) ==
                      boost::log::trivial::severity_level::trace;
#endif
        if (jsonPayload)
        {
          Json::Value obj = Json::objectValue;
          obj["model_func_name"] = "tic_100ms";
          obj["args"] = Json::arrayValue;
          Json::StreamWriterBuilder wBuilder;
          wBuilder["indentation"] = "";
          std::string const document = Json::writeString(wBuilder, obj);
          DI_MODEL_LOG_MCTX_VERBOSE << document << "\n";
          // Assuming that the following function does not return anything
          // Type system should catch it if it does actually return somethingg
        }
#endif
        mModelPtr->tic_100ms();
      };
      mModelController->init_model_timer(timerFun, timer_period, _threadName);
    }

    /// @brief Implements ModelLibInterface terminate
    void terminate() final
    {
      mModelController->terminate();
      // https://dev.to/fenbf/how-a-weakptr-might-prevent-full-memory-cleanup-of-managed-object-i0i
      jlr::cccm::di::set_model_controller({});
    }
  };
};  // namespace cccm::di::models

#endif
