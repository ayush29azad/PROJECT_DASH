#!/bin/bash
# This script can be run both locally and in pipeline, and is to be run from the scope of parent folder
set -e

source "$(pwd)"/scripts/common/env_setup.sh

cp $ROOTPATH/scripts/code-quality/merge_gtest_reports.py $ROOTPATH/common-infrastructure/python_jira_automation/
cd $ROOTPATH/common-infrastructure/python_jira_automation/

if [[ "$CI" == true ]]; then
    echo "Running jira upload job -------------"
    python3 merge_gtest_reports.py $ROOTPATH/Gtest_reports/Gtest/jsonreports/ jsonreports/
    mv jsonreports/test_report.json jsonreports/$2
    ls -al jsonreports
    python3 unitTestJiraAutomation.py $1 --pipeline 
fi

set +e
