#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

FILE_NAME="conanfile.py"
REGEX="non_safety_models_static_libs/.*@jlrcccm.*/"

# environment setup
git submodule update --init --recursive
git fetch --tags

VERSION=$(git tag -l "v[0-9]*" | sort -r --version-sort | head -n 1)

OUTPUT=$(git diff -G "$REGEX" "$VERSION" HEAD "$FILE_NAME")

if [ -z "$OUTPUT" ]; then
    echo "No relevant changes in conanfile"
    exit 0
fi

non_safety_tag=$(echo "$OUTPUT" | grep "$REGEX" | awk -F'[/@]' '{print $2}' | tail -n 1)

if [ -z "$non_safety_tag" ]; then
    echo "[Error] No non-safety tag extracted, exit job!";
    exit 1;
fi

package="non_safety_models_static_libs/${non_safety_tag}@jlrcccm/dev"

if conan search $package -r jlr-cccm > /dev/null 2>&1; then
    echo "$package Package already exists"
    exit 0;
else
    # Create and upload package 
    echo "Creating package: $package"
    ${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

    #For Linux
    conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models $package \
        --profile=${PROJECT_DIR}/common-infrastructure/conan/profile/linux-x86_64-release

    conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models $package \
        --profile=${PROJECT_DIR}/common-infrastructure/conan/profile/linux-x86_64-debug
    
    #For QNX
    if [[ -z $CI ]]
    then
        QNX_BASE=`pwd`/sdp
    fi

    source "${QNX_BASE}/qnxsdp-env.sh"

    conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models ${package} \
        --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-release \
        --profile:build=default 

    conan create ${PROJECT_DIR}/artifacts_fetch/non_safety_models ${package} \
        --profile:host=${PROJECT_DIR}/common-infrastructure/conan/profile/qnx-7.1-debug \
        --profile:build=default   
fi

if [[ -n $CI ]]
then
    conan upload $package --all -r jlr-cccm -c --force
fi
