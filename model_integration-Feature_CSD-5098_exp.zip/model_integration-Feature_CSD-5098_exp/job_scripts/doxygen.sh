#!/usr/bin/env bash

set -eo pipefail

source `pwd`/scripts/common/env_setup.sh

DOXY_OUTPUT_FILE="doxy.out"
RED='\033[0;31m'
GREEN='\033[0;32m'
WHITE='\033[0m'

# if [[ -n $CI ]]; then
#         echo "unpacking code-gen artifacts -----------"
# 	tar -xzf model_autocode_gen.tar.gz
# 	rm -rf "${ROOTPATH}"/auto_codegen_scripts
# 	rm -rf "${ROOTPATH}"/model_autocode_gen.tar.gz
# fi
touch $DOXY_OUTPUT_FILE
echo "+++++++++++++++++++++++++++++"
echo "$ROOTPATH"
tree -L 4

mkdir -p $ROOTPATH/include/ipc
cp $ROOTPATH/model_ipc/ipc_wrapper_utils/*.h $ROOTPATH/include/ipc
cp $ROOTPATH/model_ipc/ipc_wrapper_utils/*.hpp $ROOTPATH/include/ipc

DOXYGEN_INPUT_FILES="$ROOTPATH/include/ipc  ${ROOTPATH}/model_ipc/ipc_wrapper_utils ${ROOTPATH}/model_launcher/src ${ROOTPATH}/model_launcher/include"

# Provide the input files for doxygen
( cat Doxyfile; echo "INPUT=${ROOTPATH}/model_ipc/ipc_wrapper_utils ${ROOTPATH}/model_launcher/src ${ROOTPATH}/model_launcher/include" ) | doxygen -


if grep -iq 'warning\|error' "$DOXY_OUTPUT_FILE";
then
        echo -e "\\n"
        echo -e "${RED}FAIL: Doxygen generated with warnings"
        echo -e "\\n"
        echo    "Doxygen Warnings:"
        echo -e "${WHITE}"
        cat $DOXY_OUTPUT_FILE
        exit 1
else
	if [ -d $ROOTPATH/doxygen/latex ];
	then
		DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends tzdata
		apt-get install texlive-latex-extra -y
		cd $ROOTPATH/doxygen/latex
		make
	fi
        echo -e "\\n"
        echo -e "${GREEN}PASS: Doxygen generated without any warnings"
        echo -e "${WHITE}"
        echo -e "\\n"
fi

rm -rf "$ROOTPATH"/include/ipc
