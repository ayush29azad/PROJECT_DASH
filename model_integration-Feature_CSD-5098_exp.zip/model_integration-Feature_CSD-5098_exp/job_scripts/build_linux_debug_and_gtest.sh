#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

if [ "$#" -ne 2 ]
then
    echo "version or channel not provided"
    echo "using version=VERSION_UNSPECIFIED and channel=testing"
    export version=VERSION_UNSPECIFIED
    export channel=testing
else
    export version=$1
    export channel=$2
fi

if [[ -z $CI ]]
then
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
   LINUX_DEBUG_PROFILE="common-infrastructure/conan/profile/linux-x86_64-debug"
fi

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

if [[ -n $CI ]]
then
    conan create ${PROJECT_DIR} $package \
        -pr:h=${PROJECT_DIR}/${LINUX_DEBUG_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} \
        --build=missing --build=model_integration

else
    rm -rf ${PROJECT_DIR}/{build-debug,output} && mkdir -p ${PROJECT_DIR}/build-debug 
    conan install -if=${PROJECT_DIR}/build-debug -of=${PROJECT_DIR}/build-debug -pr:h=${PROJECT_DIR}/${LINUX_DEBUG_PROFILE} \
         -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package
    conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build-debug -imf=${PROJECT_DIR}
    conan build -bf=${PROJECT_DIR}/build-debug -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=linux_artifacts/Debug
    conan package -bf=${PROJECT_DIR}/build-debug -sf=${PROJECT_DIR} -pf=linux_artifacts/Debug ${PROJECT_DIR}
fi

BUILD_FOLDER_PATH=$(conan info $package -pr:h=${PROJECT_DIR}/${LINUX_DEBUG_PROFILE} -pr:b=${PROJECT_DIR}/${LINUX_RELEASE_PROFILE} --only=build_folder --paths | grep build_folder | grep model_integration | awk '{print $NF}')
mkdir -p ${PROJECT_DIR}/autogen_output
cp -rPf $BUILD_FOLDER_PATH/output/* ${PROJECT_DIR}/autogen_output
if [[ -d ${BUILD_FOLDER_PATH}/out ]]; then
    mkdir -p $PROJECT_DIR/Gtest_reports/Gtest
    cp -rf ${BUILD_FOLDER_PATH}/test/unit/jsonreports ${PROJECT_DIR}/Gtest_reports/Gtest/
    cp -rPf ${BUILD_FOLDER_PATH}/out/* $PROJECT_DIR/Gtest_reports

    if [[ "$CI" == true ]]; then
        source ${UTILS_PATH}/artifactory_utils.sh
        FILE_NAME="GTest_Reports_${version}.tar.gz"
        tar -czf ${FILE_NAME} Gtest_reports
        rt_upload --target-props "version=${version}" "${PROJECT_DIR}/${FILE_NAME}" ${GTEST_RT_LOCATION}/${FILE_NAME}
        echo "Gtest Report files uploaded to artifactory: ${GTEST_RT_LOCATION}/${FILE_NAME}"
    fi
fi


if [[ -n $CI ]]
then
    echo "Running in pipeline"
    conan upload $package --all -r jlr-cccm -c --force
fi

if [[ -z ${CI} ]] ; then
    chmod +x "${ROOTPATH}"/scripts/code-build/success.sh && "${ROOTPATH}"/scripts/code-build/success.sh
fi
