#!/bin/bash
set -exo pipefail

# install_packages
semantic-release

if [[ $CI_COMMIT_REF_NAME == "$MAIN_BRANCH" ]]; then
  git config --global user.name "${GITLAB_USER_NAME}"
  git config --global user.email "${GITLAB_USER_EMAIL}"
  git checkout development
  git pull origin development
  git rebase main
  git push -o ci.skip https://root:"$GITLAB_TOKEN"@"$CI_SERVER_HOST"/"$CI_PROJECT_PATH".git
  git checkout -
fi

set +e
