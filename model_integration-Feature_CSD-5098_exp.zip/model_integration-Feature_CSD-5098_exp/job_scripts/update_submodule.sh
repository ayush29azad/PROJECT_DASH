#!/bin/bash
# This script can be run both locally and in pipeline, and is to be run from the scope of parent folder
set -e

source "$(pwd)"/scripts/common/env_setup.sh

"${ROOTPATH}"/scripts/submodule-update/update_submodule.sh

if [[ "$CI" == true ]] ; then
    # push the updated submodules, in pipeline only
    git add .

    jira_ticket=`echo $CI_COMMIT_REF_NAME | grep -Eo "$JIRA_TICKET_REGEX" | head -1`    
    git commit -m "ci: ${jira_ticket} update submodule in .gitmodules (trigger commit - $CI_COMMIT_SHORT_SHA)" || echo "ci: ${jira_ticket} update submodule: Nothing to commit - no change to .gitmodules file"
    git push -o ci-skip https://root:"$GITLAB_TOKEN"@"$CI_SERVER_HOST"/"$CI_PROJECT_PATH".git HEAD:"$CI_COMMIT_REF_NAME"
fi

set +e
