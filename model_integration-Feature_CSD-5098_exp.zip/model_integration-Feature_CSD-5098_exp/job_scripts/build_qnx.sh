#!/bin/bash

set -exo pipefail

source `pwd`/scripts/common/env_setup.sh
PROJECT_DIR=$(cd "$(dirname "$0")/.."; pwd)
export PROJECT_DIR=$PROJECT_DIR
echo $PROJECT_DIR

if [ "$#" -ne 2 ]
then
    echo "version or channel not provided"
    echo "using version=VERSION_UNSPECIFIED and channel=testing"
    export version=VERSION_UNSPECIFIED
    export channel=testing
else
    export version=$1
    export channel=$2
fi

echo "version=$version"
echo "channel=$channel"

package=model_integration/$version@jlrcccm/$channel
echo "package=$package"

if [[ -z $CI ]]
then
   QNX_BASE=`pwd`/sdp
   QNX_RELEASE_PROFILE="common-infrastructure/conan/profile/qnx-7.1-release"
   QNX_DEBUG_PROFILE="common-infrastructure/conan/profile/qnx-7.1-debug"
   LINUX_RELEASE_PROFILE="common-infrastructure/conan/profile/linux-x86_64-release"
fi

source "${QNX_BASE}/qnxsdp-env.sh"

${PROJECT_DIR}/common-infrastructure/scripts/init-build-dir

if [[ -n $CI ]]
then
    build_ci_release(){
        conan create ${PROJECT_DIR} $package \
        -pr:h=${QNX_RELEASE_PROFILE} -pr:b=${LINUX_RELEASE_PROFILE} \
        --build=missing --build=model_integration
    }
    
    build_ci_debug(){
        conan create ${PROJECT_DIR} $package \
            -pr:h=${QNX_DEBUG_PROFILE} -pr:b=${LINUX_RELEASE_PROFILE} \
            --build=missing --build=model_integration
    }

    build_ci_release
    # build_ci_debug
else
    build_local_release(){
        # Local QNX Release build
        rm -rf ${PROJECT_DIR}/{build,output} && mkdir -p ${PROJECT_DIR}/build 
        conan install -if=${PROJECT_DIR}/build -of=${PROJECT_DIR}/build -pr:h=${QNX_RELEASE_PROFILE} \
            -pr:b=${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package
        conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build -imf=${PROJECT_DIR}
        conan build -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=qnx_artifacts/Release
        conan package -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} -pf=qnx_artifacts/Release ${PROJECT_DIR}
    }

    build_local_debug(){
        # Local QNX Debug build
        rm -rf ${PROJECT_DIR}/{build,output} && mkdir -p ${PROJECT_DIR}/build 
        conan install -if=${PROJECT_DIR}/build -of=${PROJECT_DIR}/build -pr:h=${QNX_DEBUG_PROFILE} \
            -pr:b=${LINUX_RELEASE_PROFILE} --build=missing --no-imports ${PROJECT_DIR} $package
        conan imports ${PROJECT_DIR} -if=${PROJECT_DIR}/build -imf=${PROJECT_DIR}
        conan build -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} ${PROJECT_DIR} -pf=qnx_artifacts/Debug
        conan package -bf=${PROJECT_DIR}/build -sf=${PROJECT_DIR} -pf=qnx_artifacts/Debug ${PROJECT_DIR}
    }

    build_local_release
    # build_local_debug
fi

if [[ -n $CI ]]
then
    echo "Running in pipeline"
    if conan search $package -r jlr-cccm > /dev/null 2>&1; then
        echo "Removing old QNX conan packages"
        conan remove $package -r jlr-cccm -q "os=Neutrino and arch=armv8" --force
    fi
    conan upload $package --all -r jlr-cccm -c --force
fi

if [[ -z ${CI} ]] ; then
    chmod +x "${ROOTPATH}"/scripts/code-build/success.sh && "${ROOTPATH}"/scripts/code-build/success.sh
fi
