#!/bin/bash
# This script can be run both locally and in pipeline, and is to be run from the scope of parent folder
set -e

source "$(pwd)"/scripts/common/env_setup.sh

# if [[ "$CI" == true ]]; then
# 	echo "Unpack code-gen artifacts -------------"
# 	tar -xzf model_autocode_gen.tar.gz

# 	rm -rf "${ROOTPATH}"/model_autocode_gen.tar.gz
# fi
tree -L 4
"${ROOTPATH}"/scripts/test/unittest/run_unittest_auto_codegen_scripts.sh

if [[ ! -z ${GITLAB_CI} ]]; then
  git fetch --tags
  VERSION=$(git describe --tags)
  source ${UTILS_PATH}/artifactory_utils.sh
  FILE_NAME="Unittest_reports_${VERSION}.tar.gz"
  tar -czf ${FILE_NAME} Unittest_reports
  rt_upload --target-props "version=${VERSION}" "${CI_PROJECT_DIR}/${FILE_NAME}" $LOCATION/$FILE_NAME
fi
set +e
