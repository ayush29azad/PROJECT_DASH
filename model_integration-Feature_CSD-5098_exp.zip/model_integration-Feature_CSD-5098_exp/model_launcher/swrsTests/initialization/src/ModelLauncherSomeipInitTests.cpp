#include <iostream>
#include <typeinfo>
#include <WorkExecutor.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <vsomeip/vsomeip.hpp>
#include <ModelLauncher.h>
#include <ValidModelA.h>
#include <DDSEntityFactory.hpp>
#include <ArgParser.h>
#include <ModelContextFactoryInterface.h>
#include <Application.h>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace std;
using namespace cccm::di::launcher;
using namespace jlr::cccm::di::dds;
using namespace eprosima::fastdds::dds;

using ::testing::_;
using ::testing::AtLeast;
using ::testing::Eq;
using ::testing::Invoke;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;
using LauncherContext = cccm::di::launcher::LauncherContext;

namespace model_launcher_main
{
  void model_launcher_terminate();
}

class MockTopicDataType : public TopicDataType
{
};

namespace cccm::di::launcher
{
  class MockModelContextFactory : public ModelContextFactoryInterface
  {
  public:
    MockModelContextFactory(ArgParser& argParser)
    {
    }
    using SomeIpAppMap = std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>;
    MOCK_METHOD(SomeIpAppMap, create_someip_applications, (), (override));
    MOCK_METHOD(std::shared_ptr<DDSEntityFactoryInterface>, create_dds_factory, (), (override));
    MOCK_METHOD(std::shared_ptr<WorkExecutor>, create_workexecutor, (), (override));
    MOCK_METHOD(std::shared_ptr<LauncherContext>, create_context, (), (override));
    MOCK_METHOD(ArgParser&, get_input_arguments, (), (const, override));
  };
}  // namespace cccm::di::launcher

class ModelLauncherSomeipInitTests : public ::testing::Test
{
  void SetUp()
  {
    RecordProperty("rsp_revision_number", "Rev_2");
    mockSomeipApp = make_shared<vsomeip::application>();
    mockDdsFactory = std::make_shared<DDSEntityFactory>(SHARED_MEM);
    mockWorkExecutor = std::make_shared<WorkExecutor>("workExecutorDLT");
  }
  void TearDown()
  {
  }

public:
  std::shared_ptr<vsomeip::application> mockSomeipApp = nullptr;
  std::shared_ptr<DDSEntityFactoryInterface> mockDdsFactory = nullptr;
  std::shared_ptr<WorkExecutor> mockWorkExecutor = nullptr;
};

/// @brief Applications terminates gracefully if vsomeip::application couldn't be created
TEST_F(ModelLauncherSomeipInitTests, graceful_someip_app_creation_failure)
{
  RecordProperty("requirements", "Requirement01165180");
  int argc = 8;
  char const* argv[] = {"model_launcher", "--models", "ValidModelA", "ValidModelB", "--dlt_id", "MD01", "--vid", "10"};

  ArgParser argParser;
  bool parsed = argParser.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::unique_ptr<MockModelContextFactory> mockContextFactory = std::make_unique<MockModelContextFactory>(argParser);

  std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
  someipApp_map.insert({"vid10", mockSomeipApp});
  mockContext->someipApp_map = someipApp_map;
  mockContext->ddsFactory = mockDdsFactory;
  mockContext->workExecutor = mockWorkExecutor;

  EXPECT_CALL(*(mockContextFactory.get()), get_input_arguments())
      .Times(2)
      .WillRepeatedly(::testing::ReturnRef(argParser));

  EXPECT_CALL(*(mockContextFactory.get()), create_context()).Times(1).WillOnce(Return(mockContext));

  int ret = model_launcher_main::model_launcher_main(std::move(mockContextFactory));
  EXPECT_EQ(ret, 0);

  auto models = ModelLauncher::get_instance().get_models();
  int modelCount = models.size();
  EXPECT_EQ(modelCount, 0);
}

/// @brief Applications terminates gracefully if ddsFactory couldn't be created
TEST_F(ModelLauncherSomeipInitTests, graceful_ddsFactory_creation_failure)
{
  RecordProperty("requirements", "Requirement01165181");
  int argc = 8;
  char const* argv[] = {"model_launcher", "--models", "ValidModelA", "ValidModelB", "--dlt_id", "MD01", "--vid", "10"};

  ArgParser argParser;
  bool parsed = argParser.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::unique_ptr<MockModelContextFactory> mockContextFactory = std::make_unique<MockModelContextFactory>(argParser);

  std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
  someipApp_map.insert({"vid10", mockSomeipApp});
  mockContext->someipApp_map = someipApp_map;
  mockContext->ddsFactory = nullptr;
  mockContext->workExecutor = mockWorkExecutor;

  EXPECT_CALL(*(mockContextFactory.get()), get_input_arguments())
      .Times(2)
      .WillRepeatedly(::testing::ReturnRef(argParser));

  EXPECT_CALL(*(mockContextFactory.get()), create_context()).Times(1).WillOnce(Return(mockContext));

  int ret = model_launcher_main::model_launcher_main(std::move(mockContextFactory));
  EXPECT_EQ(ret, 0);

  auto models = ModelLauncher::get_instance().get_models();
  int modelCount = models.size();
  EXPECT_EQ(modelCount, 0);
}

// // Function to simulate threaded delay
// void ThreadedDelay() {
//   std::this_thread::sleep_for(std::chrono::seconds(1));
// }

// /// @brief single vsomeip::application pointer shared across models
// TEST_F(ModelLauncherSomeipInitTests, single_vsomeip_ptr_shared_across_models)
// {
//   int argc = 6;
//   char const* argv[] = {"model_launcher", "--models", "ValidModelA", "ValidModelB", "--dlt_id", "MD01"};

//   ArgParser argParser;
//   bool parsed = argParser.parse_args(argc, argv);

//   EXPECT_EQ(parsed, true);

//   std::unique_ptr<MockModelContextFactory> mockContextFactory
//     = std::make_unique<MockModelContextFactory>(argParser);

//   std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
//   mockContext->someipApp = mockSomeipApp;
//   mockContext->ddsFactory = mockDdsFactory;
//   mockContext->workExecutor = mockWorkExecutor;

//   EXPECT_CALL(*(mockContextFactory.get()), get_input_arguments())
//     .Times(2)
//     .WillRepeatedly(::testing::ReturnRef(argParser));

//   EXPECT_CALL(*(mockContextFactory.get()), create_context())
//     .Times(1)
//     .WillOnce(Return(mockContext));

//   EXPECT_CALL(*mockSomeipApp, init())
//     .Times(1)
//     .WillOnce(Return(true));

//   EXPECT_CALL(*mockWorkExecutor, run()).Times(1);
//   EXPECT_CALL(*mockWorkExecutor, getThreadStatus())
//     .WillRepeatedly(Return(true));

//   EXPECT_CALL(*mockWorkExecutor, signalThread())
//     .Times(AtLeast(1));

//   std::thread blockingThread;

//   EXPECT_CALL(*mockSomeipApp, start())
//     .Times(1)
//     .WillOnce(Invoke([&blockingThread] {
//         blockingThread = std::thread(ThreadedDelay);
//     }));

//   int ret = model_launcher_main::model_launcher_main(std::move(mockContextFactory));
//   auto models = ModelLauncher::get_instance().get_models();
//   model_launcher_main::model_launcher_terminate();
//   EXPECT_EQ(ret, 0);

//   int modelCount = models.size();
//   EXPECT_EQ(modelCount, 2);

//   std::shared_ptr<ValidModelA> m1 = std::dynamic_pointer_cast<ValidModelA>(models[0]);
//   std::shared_ptr<ValidModelA> m2 = std::dynamic_pointer_cast<ValidModelA>(models[1]);

//   // Same vsomeip::application instance for both the models
//   EXPECT_EQ(mockSomeipApp.get(), m1->passedPointer.get());
//   EXPECT_EQ(mockSomeipApp.get(), m2->passedPointer.get());

//   if(blockingThread.joinable())
//   {
//     blockingThread.join();
//   }
// }

/// @brief Single vsomeip::application instance sharing across models
TEST_F(ModelLauncherSomeipInitTests, single_vsomeip_application_shared_test)
{
  RecordProperty("requirements", "Requirement01165180");
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
  someipApp_map.insert({"vid10", mockSomeipApp});
  mockContext->someipApp_map = someipApp_map;
  mockContext->ddsFactory = mockDdsFactory;
  mockContext->workExecutor = mockWorkExecutor;

  ModelLauncher::get_instance().set_context(mockContext);

  auto result = ModelLauncher::get_instance().load_all_models(modelLibs);
  auto models = ModelLauncher::get_instance().get_models();
  int modelCount = models.size();

  std::shared_ptr<ValidModelA> m1 = std::dynamic_pointer_cast<ValidModelA>(models[0]);
  std::shared_ptr<ValidModelA> m2 = std::dynamic_pointer_cast<ValidModelA>(models[1]);

  // Same vsomeip::application instance for both the models
  EXPECT_EQ(someipApp_map["vid10"].get(), m1->someipApp_map["vid10"].get());
  EXPECT_EQ(someipApp_map["vid10"].get(), m2->someipApp_map["vid10"].get());

  EXPECT_EQ(2, modelCount);
}
