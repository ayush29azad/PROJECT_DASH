#include <iostream>
#include <dlfcn.h>
#include <memory>

#include "ValidModelA.h"

using createFuncType = std::shared_ptr<cccm::di::ModelLibInterface> (*)();

std::shared_ptr<cccm::di::ModelLibInterface> creator()
{
  return std::make_shared<ValidModelA>();
}

/// @brief mock method dlsym()
/// @param __handle
/// @param __name
/// @return mock value after populating DLLibMockHelper data structure
void* dlsym(void* __restrict __handle, char const* __restrict __name)
{
  if (__handle == nullptr)
  {
    return nullptr;
  }

  std::string symName(__name);
  auto& dlsymCalls = DLLibMockHelper::getInstance().actualdlsymCalls;
  dlsymCalls[symName]++;

  if (symName == "creator")
  {
    createFuncType ptr = &creator;

    auto actualLibHandles = DLLibMockHelper::getInstance().actualLibHandles;
    for (auto el : actualLibHandles)
    {
      if (el.first == "libValidModelA.so" || el.first == "libValidModelB.so")
        return reinterpret_cast<void*>(ptr);
      else
        return nullptr;
    }
  }
  else
  {
    return nullptr;
  }
}

/// @brief mock method dlopen()
/// @param __file
/// @param __mode
/// @return mock value after populating DLLibMockHelper data structure
void* dlopen(char const* __file, int __mode)
{
  auto& actualLibMap = DLLibMockHelper::getInstance().actualLibModes;
  auto& actualLibHandles = DLLibMockHelper::getInstance().actualLibHandles;
  actualLibMap[__file] = __mode;

  void* ptr = new int;
  actualLibHandles[__file] = ptr;

  return ptr;
}

/// @brief mock method dlclose()
/// @param __handle
/// @return mock value after populating DLLibMockHelper data structure
int dlclose(void* __handle)
{
  auto& actualdlcloseCalls = DLLibMockHelper::getInstance().actualdlcloseCalls;
  actualdlcloseCalls++;

  return 0;
}
