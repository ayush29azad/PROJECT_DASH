#include <iostream>
#include <typeinfo>
#include <WorkExecutor.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <vsomeip/vsomeip.hpp>
#include <ModelLauncher.h>
#include <ValidModelA.h>
#include <DDSEntityFactory.hpp>
#include <ArgParser.h>
#include <ModelContextFactoryInterface.h>
#include <DdsCommunicationHandler.hpp>
#include <Application.h>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace std;
using namespace cccm::di::launcher;
using namespace jlr::cccm::di::dds;
using namespace eprosima::fastdds::dds;

using ::testing::_;
using ::testing::AtLeast;
using ::testing::Eq;
using ::testing::Invoke;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;
using DDSManager = jlr::cccm::di::dds::DDSManager;
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;
using LauncherContext = cccm::di::launcher::LauncherContext;
using DdsCommunicationHandler = jlr::cccm::di::DdsCommunicationHandler;
class MockTopicDataType : public TopicDataType
{
};

void onDataAvailable_dummyTopic()
{
}

class ModelLauncherDdsInitTests : public ::testing::Test
{
  void SetUp()
  {
    RecordProperty("rsp_revision_number", "Rev_2");
  }
  void TearDown()
  {
  }
};

/// @brief Model launcher shall use dds_manager APIs for creating entities
TEST_F(ModelLauncherDdsInitTests, dds_manager_api_usage_test)
{
  RecordProperty("requirements", "Requirement01165181");
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
  auto ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);

  std::mutex model_mutex;
  std::shared_ptr<DdsCommunicationHandler> ddsHandler =
      std::make_shared<DdsCommunicationHandler>(ddsFactory, &model_mutex, "dummyDltId");

  TopicDataType* topicDataTypePtr = new MockTopicDataType();
  std::string const topicName = "dummyTopic";

  std::shared_ptr<DDSManagerInterface> ddsManager = ddsHandler->get_manager();
  auto ddsManagerPtr = std::dynamic_pointer_cast<DDSManager>(ddsManager);

  EXPECT_NE(ddsManagerPtr, nullptr);

  EXPECT_CALL(*(ddsManagerPtr.get()), register_publisher(topicName, topicDataTypePtr)).Times(1).WillOnce(Return(true));

  bool res1 = ddsHandler->topic_out(topicName, topicDataTypePtr);

  EXPECT_CALL(*(ddsManagerPtr.get()), register_subscriber(topicName, topicDataTypePtr)).Times(1).WillOnce(Return(true));

  bool res2 = ddsHandler->topic_in(topicName, topicDataTypePtr, &onDataAvailable_dummyTopic);

  int* data = new int(5);

  EXPECT_CALL(*(ddsManagerPtr.get()), send_data(data, topicName)).Times(1).WillOnce(Return(true));

  bool res3 = ddsHandler->send(data, topicName);

  EXPECT_CALL(*(ddsManagerPtr.get()), recv_data(data, topicName)).Times(1).WillOnce(Return(true));

  bool res4 = ddsHandler->recv(data, topicName);

  EXPECT_EQ(res1, true);
  EXPECT_EQ(res2, true);
  EXPECT_EQ(res3, true);
  EXPECT_EQ(res4, true);

  delete data;
}

/// @brief Model launcher shall use dds_manager APIs for creating entities
TEST_F(ModelLauncherDdsInitTests, dds_manager_api_failure_test)
{
  RecordProperty("requirements", "Requirement01165181");
  std::vector<std::string> modelLibs = {"ValidModelA", "ValidModelB"};

  using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
  auto ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);

  std::mutex model_mutex;
  std::shared_ptr<DdsCommunicationHandler> ddsHandler =
      std::make_shared<DdsCommunicationHandler>(ddsFactory, &model_mutex, "dummyDltId");

  TopicDataType* topicDataTypePtr = new MockTopicDataType();
  std::string const topicName = "dummyTopic";

  std::shared_ptr<DDSManagerInterface> ddsManager = ddsHandler->get_manager();
  auto ddsManagerPtr = std::dynamic_pointer_cast<DDSManager>(ddsManager);

  EXPECT_NE(ddsManagerPtr, nullptr);

  EXPECT_CALL(*(ddsManagerPtr.get()), register_publisher(topicName, topicDataTypePtr)).Times(1).WillOnce(Return(false));

  bool res1 = ddsHandler->topic_out(topicName, topicDataTypePtr);

  EXPECT_CALL(*(ddsManagerPtr.get()), register_subscriber(topicName, topicDataTypePtr))
      .Times(1)
      .WillOnce(Return(false));

  bool res2 = ddsHandler->topic_in(topicName, topicDataTypePtr, &onDataAvailable_dummyTopic);

  int* data = new int(5);

  EXPECT_CALL(*(ddsManagerPtr.get()), send_data(data, topicName)).Times(1).WillOnce(Return(false));

  bool res3 = ddsHandler->send(data, topicName);

  EXPECT_CALL(*(ddsManagerPtr.get()), recv_data(data, topicName)).Times(1).WillOnce(Return(false));

  bool res4 = ddsHandler->recv(data, topicName);

  EXPECT_EQ(res1, false);
  EXPECT_EQ(res2, false);
  EXPECT_EQ(res3, false);
  EXPECT_EQ(res4, false);

  delete data;
}
