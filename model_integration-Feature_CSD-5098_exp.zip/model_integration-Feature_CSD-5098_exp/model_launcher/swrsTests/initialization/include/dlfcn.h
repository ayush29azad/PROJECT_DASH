#ifndef DLFCN_MOCK_H
#define DLFCN_MOCK_H

#include <iostream>
#include <map>
#include <string>

#define RTLD_NEXT ((void*)-1l)
#define RTLD_DEFAULT ((void*)0)
#define RTLD_LAZY 0x00001 /* Lazy function call binding.  */
#define RTLD_NOW 0x00002 /* Immediate function call binding.  */
#define RTLD_BINDING_MASK 0x3 /* Mask of binding time value.  */
#define RTLD_NOLOAD 0x00004 /* Do not load the object.  */
#define RTLD_DEEPBIND 0x00008 /* Use deep binding.  */

void* dlsym(void* __restrict __handle, char const* __restrict __name);
void* dlopen(char const* __file, int __mode);
int dlclose(void* __handle);

/// @brief DLLibMockHelper class helps us mock the free C-style functions.
/// Idea is to create a global static DataStructure(DLLibMockHelper), that can
/// be accessed from the tests and the mock free methods. The mock DL lib calls
/// like dlopen(), dlsym() can populate this data structure and the tests can
/// verify the data structure whether it holds the expected values of not
class DLLibMockHelper
{
public:
  std::map<std::string, int> actualLibModes;
  std::map<std::string, void*> actualLibHandles;
  std::map<std::string, int> actualdlsymCalls;
  int actualdlcloseCalls = 0;

private:
  DLLibMockHelper()
  {
  }

  ~DLLibMockHelper()
  {
  }

  DLLibMockHelper(DLLibMockHelper const&) = delete;
  DLLibMockHelper& operator=(DLLibMockHelper const&) = delete;

public:
  static DLLibMockHelper& getInstance()
  {
    static DLLibMockHelper dlLibInstance;
    return dlLibInstance;
  }

  void clear()
  {
    actualLibModes.clear();
    actualdlsymCalls.clear();
    for (std::pair<std::string, void*> el : actualLibHandles)
    {
      int* ptr = (int*)el.second;
      delete ptr;
    }
    actualLibHandles.clear();
    actualdlcloseCalls = 0;
  }
};

#endif
