/// @file WorkExecutor.h
/// @brief WorkExecutor for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef _JLRWORKEXECUTOR_HEADER_
#define _JLRWORKEXECUTOR_HEADER_

#include <iostream>
#include <thread>
#include <functional>
#include <gmock/gmock.h>
#include <gtest/gtest.h>

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        class WorkExecutor
        {
        public:
          WorkExecutor()
          {
          }
          WorkExecutor(std::string dlt_app_name)
          {
          }

          MOCK_METHOD(void, stop, (), ());
          MOCK_METHOD(void, run, (), ());
          MOCK_METHOD(void, signalThread, (), ());
          MOCK_METHOD(void, setThreadStatus, (bool), ());
          MOCK_METHOD(bool, getThreadStatus, (), ());
          MOCK_METHOD(void, stopThread, (), ());
          MOCK_METHOD(int8_t, addWork, (std::function<void()>), ());

          ~WorkExecutor()
          {
          }
        };
      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
