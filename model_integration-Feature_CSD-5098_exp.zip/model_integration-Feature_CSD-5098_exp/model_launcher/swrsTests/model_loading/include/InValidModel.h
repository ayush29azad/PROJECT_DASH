#include "ModelLibInterface.h"

class InvalidModel : public cccm::di::ModelLibInterface
{
public:
  InvalidModel(){};
  ~InvalidModel(){};

  void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) override {};
  void terminate() override {};
};

cccm::di::ModelLibInterface* creator_()
{
  return new InvalidModel();
}
