#include <iostream>
#include <typeinfo>
#include <WorkExecutor.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <vsomeip/vsomeip.hpp>
#include <ModelLauncher.h>
#include <ValidModelA.h>
#include <DDSEntityFactory.hpp>
#include <ArgParser.h>
#include <ModelContextFactoryInterface.h>
#include <Application.h>

#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace std;
using namespace cccm::di::launcher;
using namespace jlr::cccm::di::dds;
using namespace eprosima::fastdds::dds;

using ::testing::_;
using ::testing::AtLeast;
using ::testing::Eq;
using ::testing::Invoke;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using WorkExecutor = jlr::cccm::di::work_executor::WorkExecutor;
using LauncherContext = cccm::di::launcher::LauncherContext;

namespace model_launcher_main
{
  void handle_signal(int32_t signal);
  void model_launcher_terminate();
}  // namespace model_launcher_main

namespace cccm::di::launcher
{
  class MockModelContextFactory : public ModelContextFactoryInterface
  {
  public:
    MockModelContextFactory(ArgParser& argParser)
    {
    }
    using SomeIpAppMap = std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>;
    MOCK_METHOD(SomeIpAppMap, create_someip_applications, (), (override));
    MOCK_METHOD(std::shared_ptr<DDSEntityFactoryInterface>, create_dds_factory, (), (override));
    MOCK_METHOD(std::shared_ptr<WorkExecutor>, create_workexecutor, (), (override));
    MOCK_METHOD(std::shared_ptr<LauncherContext>, create_context, (), (override));
    MOCK_METHOD(ArgParser&, get_input_arguments, (), (const, override));
  };
}  // namespace cccm::di::launcher

class ModelLauncherShutdownTests : public ::testing::Test
{
  void SetUp()
  {
    RecordProperty("rsp_revision_number", "Rev_2");
    mockSomeipApp = make_shared<vsomeip::application>();
    someipApp_map.insert({"vid10", mockSomeipApp});
    mockDdsFactory = std::make_shared<DDSEntityFactory>(SHARED_MEM);
    mockWorkExecutor = std::make_shared<WorkExecutor>("workExecutorDLT");
  }
  void TearDown()
  {
  }

public:
  // Function to simulate delay
  void ThreadDelay()
  {
    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
  }
  std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
  std::shared_ptr<vsomeip::application> mockSomeipApp = nullptr;
  std::shared_ptr<DDSEntityFactoryInterface> mockDdsFactory = nullptr;
  std::shared_ptr<WorkExecutor> mockWorkExecutor = nullptr;
};

/// @brief Shutdown test :: Signal SIGINT (2)
TEST_F(ModelLauncherShutdownTests, model_launcher_shutdown_test_signal_2)
{
  RecordProperty("requirements", "Requirement01165234");
  int argc = 8;
  char const* argv[] = {"model_launcher", "--models", "ValidModelA", "ValidModelB", "--dlt_id", "MD01", "--vid", "10"};

  ArgParser argParser;
  bool parsed = argParser.parse_args(argc, argv);

  EXPECT_EQ(parsed, true);

  std::unique_ptr<MockModelContextFactory> mockContextFactory = std::make_unique<MockModelContextFactory>(argParser);

  std::shared_ptr<LauncherContext> mockContext = std::make_shared<LauncherContext>();
  mockContext->someipApp_map = someipApp_map;
  mockContext->ddsFactory = mockDdsFactory;
  mockContext->workExecutor = mockWorkExecutor;

  EXPECT_CALL(*(mockContextFactory.get()), get_input_arguments())
      .Times(2)
      .WillRepeatedly(::testing::ReturnRef(argParser));

  EXPECT_CALL(*(mockContextFactory.get()), create_context()).Times(1).WillOnce(Return(mockContext));

  EXPECT_CALL(*someipApp_map["vid10"], init()).Times(1).WillOnce(Return(true));

  EXPECT_CALL(*mockWorkExecutor, run()).Times(1);
  EXPECT_CALL(*mockWorkExecutor, getThreadStatus()).WillRepeatedly(Return(true));

  // Simulating signal 2 (SIGINT) after 1.5 seconds
  auto SignalHandling = [&]()
  {
    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
    // Workexecutorthread shall stop
    EXPECT_CALL(*mockWorkExecutor, stop()).Times(1);

    // vsomeip::application shall stop
    EXPECT_CALL(*someipApp_map["vid10"], stop()).Times(1);

    // models shall terminate
    auto models = ModelLauncher::get_instance().get_models();
    int modelCount = models.size();
    EXPECT_EQ(2, modelCount);

    std::shared_ptr<ValidModelA> m1 = std::dynamic_pointer_cast<ValidModelA>(models[0]);
    std::shared_ptr<ValidModelA> m2 = std::dynamic_pointer_cast<ValidModelA>(models[1]);
    EXPECT_CALL(*m1, terminate()).Times(1);
    EXPECT_CALL(*m2, terminate()).Times(1);

    model_launcher_main::handle_signal(2);
  };

  std::thread signalHandlingThread(SignalHandling);

  EXPECT_CALL(*someipApp_map["vid10"], start())
      .Times(1)
      .WillOnce(Invoke(
          [this]
          {
            this->ThreadDelay();
          }));

  EXPECT_CALL(*mockWorkExecutor, signalThread()).Times(AtLeast(1));
  EXPECT_CALL(*mockWorkExecutor, setThreadStatus(false)).Times(AtLeast(1));

  int ret = model_launcher_main::model_launcher_main(std::move(mockContextFactory));
  if (signalHandlingThread.joinable())
  {
    signalHandlingThread.join();
  }
  EXPECT_EQ(ret, 0);
}
