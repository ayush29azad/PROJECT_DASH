/// @file ArgParser.h
/// @brief Contains all function declaration required to parse cmd arguments
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date November 2023
#ifndef JLRCCCM_ARG_PARSER_H
#define JLRCCCM_ARG_PARSER_H

#include <vector>
#include <string>

namespace cccm::di::launcher
{
  /// @brief ArgParser class is used parse the command line arguments
  ///
  /// @details It will parse the command line arguments and store all
  /// requied model names in vector of strings and dlt context as string
  ///
  class ArgParser final
  {
  private:
    /// @brief dlt_id argument name
    static std::string const OPT_DLT_ID;

    /// @brief models argument name
    static std::string const OPT_MODELS;

    /// @brief vid argument name
    static std::string const OPT_VID;

    /// @brief default dlt_id if nothing is passed
    static std::string const DEFAULT_DLT_ID;

    /// @brief no option passed
    static std::size_t const NO_OPTION = 0;

    /// @brief Stores the parsed model libs list
    std::vector<std::string> mModelLibs;

    /// @brief Stores the parsed dlt app id
    std::string mDltAppId;

    /// @brief std::vector<std::string> to store vlan Id
    std::vector<std::string> vid;

    /// @brief Store whether this launcher instance is a comfort writer or not
    bool mEnableComfortWriter = false;

  public:
    /// @brief Constuctor
    ArgParser();

    /// @brief Destructor
    ~ArgParser();

    /// @brief Parses the command line arguments
    /// @param argc Number of command line arguments
    /// @param argv List of command line argmuments
    /// @return Returns true if model list and dlt id were
    /// parsed correctly else returns false;
    /// @satisfy{Requirement01165030, Requirement01165031, Requirement01165034, Requirement01165037,
    /// Requirement01165039, Requirement01165040, Requirement01165042, Requirement01165192, Requirement01165194}
    bool parse_args(int32_t const argc, char const* const* argv);

    /// @brief Method to fetch the dlt app id parsed from command line
    ///
    /// @retval The dlt app id string
    /// @satisfy{Requirement01165034, Requirement01165039}
    std::string const get_dlt_id() const;

    /// @brief Method to fetch all the model lib names parsed
    ///
    /// @retval vector<string> containing the list of model libs
    /// @satisfy{Requirement01165030}
    std::vector<std::string> const get_model_libs() const;

    /// @brief Method to get vid vector
    ///
    /// @retval vector<string> containing the list of vid
    std::vector<std::string> const getvIds() const;

    /// @brief Getter method for member mEnableComfortWriter
    /// @return True if the model_launcher instance acts as comfort writer
    bool get_comfort_writer() const;
  };
}  // namespace cccm::di::launcher

#endif
