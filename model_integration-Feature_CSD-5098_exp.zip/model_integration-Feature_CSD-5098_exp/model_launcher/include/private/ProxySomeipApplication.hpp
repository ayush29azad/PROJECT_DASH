#ifndef VSOMEIP_V3_PROXY_APPLICATION_HPP_
#define VSOMEIP_V3_PROXY_APPLICATION_HPP_

#include <memory>
#include <map>
#include <vector>
#include <functional>
#include <mutex>
#include <vsomeip/vsomeip.hpp>

namespace vsomeip_v3_proxy
{

  using namespace vsomeip_v3;

  namespace types
  {
    /**
     * @brief Aliase for nested map structure to represent available services.
     */
    using available_t = std::map<
        vsomeip_v3::service_t,
        std::map<vsomeip_v3::instance_t, std::map<vsomeip_v3::major_version_t, vsomeip_v3::minor_version_t>>>;
    /**
     * @brief Aliaf for maps remote information to a string path for SD acceptance configuration.
     */
    using sd_acceptance_map_type_t = std::map<remote_info_t, std::string>;
  }  // namespace types

  /**
   * @class ProxyApplication
   * @brief A proxy wrapper for a vsomeip_v3 application, delegating functionality to another application instance.
   */
  class ProxyApplication : public vsomeip_v3::application
  {
  public:
    /**
     * @brief Constructs a ProxyApplication with a delegate application.
     * @param delegate A shared pointer to the delegate vsomeip application.
     */
    explicit ProxyApplication(std::shared_ptr<vsomeip_v3::application> delegate);

    /**
     * @brief Destructor.
     */
    ~ProxyApplication() override;

    /**
     * @brief Gets the name of the application.
     * @return A constant reference to the application name string.
     */
    std::string const& get_name() const override;

    /**
     * @brief Gets the client ID of the application.
     * @return The client ID.
     */
    vsomeip_v3::client_t get_client() const override;

    /**
     * @brief Gets the diagnosis information of the application.
     * @return The diagnosis data.
     */
    vsomeip_v3::diagnosis_t get_diagnosis() const override;

    /**
     * @brief Initializes the application.
     * @return True if initialization is successful, false otherwise.
     */
    bool init() override;

    /**
     * @brief Starts the application.
     */
    void start() override;

    /**
     * @brief Stops the application.
     */
    void stop() override;

    /**
     * @brief Processes a given number.
     * @param _number The number to process.
     */
    void process(int32_t _number) override;

    /**
     * @brief Gets the security mode of the application.
     * @return The security mode.
     */
    vsomeip_v3::security_mode_e get_security_mode() const override;

    /**
     * @brief Offers a service.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void offer_service(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Stops offering a service.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void stop_offer_service(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Offers an event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _notifier The event ID.
     * @param _eventgroups The set of event groups.
     * @param _type The event type.
     * @param _cycle The cycle time.
     * @param _change_resets_cycle Whether a change resets the cycle.
     * @param _update_on_change Whether to update on change.
     * @param _epsilon_change_func The epsilon change function.
     * @param _reliability The reliability type.
     */
    void offer_event(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _notifier,
        std::set<eventgroup_t> const& _eventgroups, vsomeip_v3::event_type_e _type, std::chrono::milliseconds _cycle,
        bool _change_resets_cycle, bool _update_on_change, epsilon_change_func_t const& _epsilon_change_func,
        vsomeip_v3::reliability_type_e _reliability) override;

    /**
     * @brief Stops offering an event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _event The event ID.
     */
    void stop_offer_event(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event) override;

    /**
     * @brief Requests a service.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void request_service(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Releases a previously requested service.
     * @param _service The service ID.
     * @param _instance The instance ID.
     */
    void release_service(vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance) override;

    /**
     * @brief Requests an event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _event The event ID.
     * @param _eventgroups The set of event groups.
     * @param _type The event type.
     * @param _reliability The reliability type.
     */
    void request_event(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
        std::set<vsomeip_v3::eventgroup_t> const& _eventgroups, vsomeip_v3::event_type_e _type,
        vsomeip_v3::reliability_type_e _reliability) override;

    /**
     * @brief Releases a previously requested event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _event The event ID.
     */
    void release_event(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event) override;

    /**
     * @brief Subscribes to an event group.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _major The major version.
     * @param _event The event ID.
     */
    void subscribe(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::major_version_t _major, vsomeip_v3::event_t _event) override;

    /**
     * @brief Unsubscribes from an event group.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     */
    void unsubscribe(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
        vsomeip_v3::eventgroup_t _eventgroup) override;

    /**
     * @brief Checks if a service is available.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     * @return True if the service is available, false otherwise.
     */
    bool is_available(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) const override;

    /**
     * @typedef available_t
     * @brief Represents a nested map structure to track available services by service, instance, and version.
     */
    typedef std::map<
        vsomeip_v3::service_t,
        std::map<vsomeip_v3::instance_t, std::map<vsomeip_v3::major_version_t, vsomeip_v3::minor_version_t>>>
        available_t;

    /**
     * @brief Checks if a specific service version is available.
     * @param _available Reference to the availability map.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     * @return True if available, false otherwise.
     */
    bool are_available(
        available_t& _available, vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
        vsomeip_v3::major_version_t _major, vsomeip_v3::minor_version_t _minor) const override;

    /**
     * @brief Sends a message.
     * @param _message The message to send.
     */
    void send(std::shared_ptr<message> _message) override;

    /**
     * @brief Notifies all subscribers of an event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _event The event ID.
     * @param _payload The payload to send.
     * @param _force Whether to force the notification.
     */
    void notify(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
        std::shared_ptr<payload> _payload, bool _force) const override;

    /**
     * @brief Notifies a specific client of an event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _event The event ID.
     * @param _payload The payload to send.
     * @param _client The client ID.
     * @param _force Whether to force the notification.
     */
    void notify_one(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
        std::shared_ptr<payload> _payload, vsomeip_v3::client_t _client, bool _force) const override;

    /**
     * @brief Registers a state handler callback.
     * @param _handler The state handler function.
     */
    void register_state_handler(vsomeip_v3::state_handler_t const& _handler) override;

    /**
     * @brief Unregisters the state handler.
     */
    void unregister_state_handler() override;

    /**
     * @brief Registers a message handler for a specific method.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _method The method ID.
     * @param _handler The message handler function.
     */
    void register_message_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method,
        vsomeip_v3::message_handler_t const& _handler) override;

    /**
     * @brief Unregisters a message handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _method The method ID.
     */
    void unregister_message_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method) override;

    /**
     * @brief Registers an availability handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _handler The availability handler function.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void register_availability_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
        vsomeip_v3::availability_handler_t const& _handler, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Unregisters an availability handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void unregister_availability_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Registers a subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The subscription handler function.
     */
    VSOMEIP_DEPRECATED_UID_GID void register_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        subscription_handler_t const& _handler) override;

    /**
     * @brief Registers an asynchronous subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The async subscription handler function.
     */
    VSOMEIP_DEPRECATED_UID_GID void register_async_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        async_subscription_handler_t const& _handler) override;

    /**
     * @brief Unregisters a subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     */
    void unregister_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
        vsomeip_v3::eventgroup_t _eventgroup) override;

    /**
     * @brief Clears all registered handlers.
     */
    void clear_all_handler() override;

    /**
     * @brief Checks if the application is acting as a routing node.
     * @return True if routing, false otherwise.
     */
    bool is_routing() const override;

    /**
     * @brief Sets the routing state of the application.
     * @param _routing_state The new routing state.
     */
    void set_routing_state(vsomeip_v3::routing_state_e _routing_state) override;

    /**
     * @brief Unsubscribes from a specific event group and event.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _event The event ID.
     */
    void unsubscribe(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::event_t _event) override;

    /**
     * @brief Registers a handler for subscription status changes.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _event The event ID.
     * @param _handler The subscription status handler.
     * @param _is_selective Whether the subscription is selective.
     */
    void register_subscription_status_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::event_t _event, vsomeip_v3::subscription_status_handler_t _handler, bool _is_selective) override;

    /**
     * @brief Unregisters a subscription status handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _event The event ID.
     */
    void unregister_subscription_status_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::event_t _event) override;

    /**
     * @brief Asynchronously retrieves offered services.
     * @param _offer_type The type of offer to query.
     * @param _handler The handler to call with the results.
     */
    void get_offered_services_async(
        vsomeip_v3::offer_type_e _offer_type, vsomeip_v3::offered_services_handler_t const& _handler) override;

    /**
     * @brief Sets a watchdog handler.
     * @param _handler The watchdog handler function.
     * @param _interval The watchdog interval.
     */
    void set_watchdog_handler(vsomeip_v3::watchdog_handler_t const& _handler, std::chrono::seconds _interval) override;

    /**
     * @brief Sets SD acceptance requirement for a specific remote.
     *
     * @param _remote The remote information.
     * @param _path The path associated with the remote.
     * @param _enable Flag to enable or disable SD acceptance.
     */
    void set_sd_acceptance_required(remote_info_t const& _remote, std::string const& _path, bool _enable) override;

    /**
     * @typedef sd_acceptance_map_type_t
     * @brief Maps remote information to a string path for SD acceptance configuration.
     */
    typedef std::map<remote_info_t, std::string> sd_acceptance_map_type_t;

    /**
     * @brief Sets SD acceptance requirement for multiple remotes.
     * @param _remotes A map of remotes and their paths.
     * @param _enable Whether to enable or disable acceptance.
     */
    void set_sd_acceptance_required(sd_acceptance_map_type_t const& _remotes, bool _enable) override;

    /**
     * @brief Gets the current SD acceptance configuration.
     * @return A map of remote info to path.
     */
    sd_acceptance_map_type_t get_sd_acceptance_required() override;

    /**
     * @brief Registers a handler for SD acceptance events.
     * @param _handler The handler function.
     */
    void register_sd_acceptance_handler(vsomeip_v3::sd_acceptance_handler_t const& _handler) override;

    /**
     * @brief Registers a handler for reboot notifications.
     * @param _handler The handler function.
     */
    void register_reboot_notification_handler(vsomeip_v3::reboot_notification_handler_t const& _handler) override;

    /**
     * @brief Registers a handler for routing readiness.
     * @param _handler The handler function.
     */
    void register_routing_ready_handler(vsomeip_v3::routing_ready_handler_t const& _handler) override;

    /**
     * @brief Registers a handler for routing state changes.
     * @param _handler The handler function.
     */
    void register_routing_state_handler(vsomeip_v3::routing_state_handler_t const& _handler) override;

    /**
     * @brief Updates the configuration of a service.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _port The port number.
     * @param _reliable Whether the service is reliable.
     * @param _magic_cookies_enabled Whether magic cookies are enabled.
     * @param _offer Whether to offer the service.
     * @return True if the update was successful.
     */
    bool update_service_configuration(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, std::uint16_t _port, bool _reliable,
        bool _magic_cookies_enabled, bool _offer) override;

    /**
     * @brief Updates the security policy configuration.
     * @param _uid User ID.
     * @param _gid Group ID.
     * @param _policy Shared pointer to the policy.
     * @param _payload Shared pointer to the payload.
     * @param _handler The update handler.
     */
    void update_security_policy_configuration(
        uint32_t _uid, uint32_t _gid, std::shared_ptr<policy> _policy, std::shared_ptr<payload> _payload,
        vsomeip_v3::security_update_handler_t const& _handler) override;

    /**
     * @brief Removes a security policy configuration.
     * @param _uid User ID.
     * @param _gid Group ID.
     * @param _handler The update handler.
     */
    void remove_security_policy_configuration(
        uint32_t _uid, uint32_t _gid, vsomeip_v3::security_update_handler_t const& _handler) override;

    /**
     * @brief Registers an extended subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The extended subscription handler.
     */
    VSOMEIP_DEPRECATED_UID_GID void register_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        subscription_handler_ext_t const& _handler) override;

    /**
     * @brief Registers an extended asynchronous subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The async subscription handler.
     */
    VSOMEIP_DEPRECATED_UID_GID void register_async_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        async_subscription_handler_ext_t const& _handler) override;

    /**
     * @brief Subscribes to an event group with debounce filtering.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _major The major version.
     * @param _event The event ID.
     * @param _filter The debounce filter.
     */
    void subscribe_with_debounce(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::major_version_t _major, vsomeip_v3::event_t _event,
        vsomeip_v3::debounce_filter_t const& _filter) override;

    /**
     * @brief Registers a message acceptance handler.
     * @param _handler The handler function.
     */
    void register_message_acceptance_handler(vsomeip_v3::message_acceptance_handler_t const& _handler) override;

    /**
     * @brief Gets additional plugin data.
     * @param _plugin_name The name of the plugin.
     * @return A map of key-value pairs.
     */
    std::map<std::string, std::string> get_additional_data(std::string const& _plugin_name) override;

    /**
     * @brief Registers an availability state handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _handler The availability state handler.
     * @param _major The major version.
     * @param _minor The minor version.
     */
    void register_availability_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
        vsomeip_v3::availability_state_handler_t const& _handler, vsomeip_v3::major_version_t _major,
        vsomeip_v3::minor_version_t _minor) override;

    /**
     * @brief Registers a secure subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The secure subscription handler.
     */
    void register_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::subscription_handler_sec_t const& _handler) override;

    /**
     * @brief Registers a secure asynchronous subscription handler.
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _eventgroup The event group ID.
     * @param _handler The secure async subscription handler.
     */
    void register_async_subscription_handler(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
        vsomeip_v3::async_subscription_handler_sec_t _handler) override;

  private:
    /**
     * @brief Delegate application to which calls are forwarded.
     */
    std::shared_ptr<vsomeip_v3::application> delegate_;

    /**
     * @typedef availibility_handler_key_t
     * @brief A tuple used as a key to uniquely identify a service instance and version.
     *
     * Consists of:
     * - service_t
     * - instance_t
     * - major_version_t
     * - minor_version_t
     */
    using availibility_handler_key_t = std::tuple<
        vsomeip_v3::service_t, vsomeip_v3::instance_t, vsomeip_v3::major_version_t, vsomeip_v3::minor_version_t>;

    /**
     * @brief Map of availability handlers indexed by service-instance-version key.
     */
    std::map<availibility_handler_key_t, std::vector<vsomeip_v3::availability_handler_t>> availibility_handlers_;

    /**
     * @brief Map of availability handlers count indexed by service-instance-version key.
     */
    std::map<availibility_handler_key_t, int32_t> availibility_handlers_count;

    /**
     * @typedef message_handler_key_t
     * @brief A tuple used as a key to uniquely identify a service instance and method.
     *
     * Consists of:
     * - service_t
     * - instance_t
     * - method_t
     */
    using message_handler_key_t = std::tuple<vsomeip_v3::service_t, vsomeip_v3::instance_t, vsomeip_v3::method_t>;

    /**
     * @brief Map of message handlers indexed by service-instance-method key.
     */
    std::map<message_handler_key_t, std::vector<vsomeip_v3::message_handler_t>> message_handlers_;

    /**
     * @brief Map of message handlers count indexed by service-instance-method key.
     */
    std::map<message_handler_key_t, int32_t> message_handlers_count;

    /**
     * @brief Synchronization mutex
     */
    std::mutex mMutex;

    /**
     * @brief Registers a message handler for a specific method or event
     * @param _service The service ID.
     * @param _instance The instance ID.
     * @param _method The method ID.
     * @param _handler The message handler function.
     * @param _type The handler registration type.
     */
    void register_message_handler_ext(
        vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method,
        vsomeip_v3::message_handler_t const& _handler, vsomeip_v3::handler_registration_type_e _type) override;
  };

}  // namespace vsomeip_v3_proxy

#endif  // VSOMEIP_V3_PROXY_APPLICATION_HPP_
