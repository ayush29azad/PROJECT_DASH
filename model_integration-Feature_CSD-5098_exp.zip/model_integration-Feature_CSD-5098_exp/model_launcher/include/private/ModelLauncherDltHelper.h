/// @file ModelLauncherDltHelper.h
/// @brief Contains all function declaration required to launch models
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date November 2023
#ifndef JLRCCCM_MODEL_LAUNCHER_DLT_HELPER_H
#define JLRCCCM_MODEL_LAUNCHER_DLT_HELPER_H

#if defined(ENABLE_DLT_LOGGING)
#include "logging_api.h"
// #include <fmt/core.h>
#include <boost/log/sources/channel_logger.hpp>
#include <boost/log/sources/global_logger_storage.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/sources/severity_channel_logger.hpp>

namespace keywords = boost::log::keywords;
namespace sources = boost::log::sources;
namespace logging
{
  using LoggerType = boost::log::sources::severity_channel_logger_mt<boost::log::trivial::severity_level, std::string>;

  /// Global declaration of work executor thread DLT context
  std::string const g_ml_dlt_context{"MAIN"};
  std::string const dltAppDescription = "DI Model Launcher";

  BOOST_LOG_INLINE_GLOBAL_LOGGER_CTOR_ARGS(g_ml_logger_service, LoggerType, (keywords::channel = g_ml_dlt_context))
}  // namespace logging
#else
/// Global declaration of BOOST_LOG_SEV this will be used when ENABLE_DLT_LOGGING is disabled
#define BOOST_LOG_SEV(log_service, log_level) std::cout
#endif  // ENABLE_DLT_LOGGING

/// Global declaration of helper MACRO to multi context FATAL log
#define ML_LOG_MCTX_FATAL BOOST_LOG_SEV(logging::g_ml_logger_service::get(), boost::log::trivial::severity_level::fatal)
/// Global declaration of helper MACRO to multi context ERROR log
#define ML_LOG_MCTX_ERROR BOOST_LOG_SEV(logging::g_ml_logger_service::get(), boost::log::trivial::severity_level::error)
/// Global declaration of helper MACRO to multi context WARNING log
#define ML_LOG_MCTX_WARN \
  BOOST_LOG_SEV(logging::g_ml_logger_service::get(), boost::log::trivial::severity_level::warning)
/// Global declaration of helper MACRO to multi context INFO log
#define ML_LOG_MCTX_INFO BOOST_LOG_SEV(logging::g_ml_logger_service::get(), boost::log::trivial::severity_level::info)
/// Global declaration of helper MACRO to multi context DEBUG log
#define ML_LOG_MCTX_DEBUG BOOST_LOG_SEV(logging::g_ml_logger_service::get(), boost::log::trivial::severity_level::debug)

#endif  // JLRCCCM_MODEL_LAUNCHER_DLT_HELPER_H
