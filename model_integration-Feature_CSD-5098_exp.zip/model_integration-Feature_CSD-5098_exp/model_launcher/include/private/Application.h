/// @file Application.h
/// @brief Contains the declaration for the model_launcher_main method
///
/// @copyright "Copyright (C) 2025, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2025
#ifndef JLRCCCM_MODEL_LAUNCHER_APPLICATION_H
#define JLRCCCM_MODEL_LAUNCHER_APPLICATION_H

#include <memory>
#include <ArgParser.h>
#include <ModelContextFactory.h>

/// @brief using type ModelContextFactoryInterface as cccm::di::launcher::ModelContextFactoryInterface
using ModelContextFactoryInterface = cccm::di::launcher::ModelContextFactoryInterface;

namespace model_launcher_main
{
  /// @brief additional declaration to remove the dependency on the ModelLauncherMain.h
  /// @param contextFactory pointer to the context factory instance
  /// @return return 0 if executed correctly
  extern uint32_t model_launcher_main(std::unique_ptr<ModelContextFactoryInterface> contextFactory);
}  // namespace model_launcher_main

#endif
