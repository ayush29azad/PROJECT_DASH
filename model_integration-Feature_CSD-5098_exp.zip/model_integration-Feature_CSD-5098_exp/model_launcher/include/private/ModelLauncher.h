/// @file ModelLauncher.h
/// @brief Contains all function declaration required to launch models
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date November 2023
#ifndef JLRCCCM_MODEL_LAUNCHER_H
#define JLRCCCM_MODEL_LAUNCHER_H

#include <iostream>
#include <dlfcn.h>
#include <thread>
#include <vector>
#include <cstring>
#include <vsomeip/vsomeip.hpp>

#include <list>
#include <signal.h>
#include <map>
#include <WorkExecutor.h>
#include <ModelLauncherDltHelper.h>
#include <ModelLoader.h>
#include <ModelLibInterface.h>

#ifdef COMFORT_WRITER
#include <ComfortWriter.h>
#include <mutex>
#endif

namespace cccm::di::launcher
{
  /// @brief ModelLauncher is used launche models using configuration json file
  ///
  /// @details its helps to launch all modles mentioned in the configraion jsonf file and opens the dynamic libraries
  /// using dlopen.
  ///
  class ModelLauncher
  {

  private:
    ModelLauncher()
    {
      ML_LOG_MCTX_INFO << "Model launcher object created" << std::endl;
    }

    ~ModelLauncher()
    {
      ML_LOG_MCTX_INFO << "Model launcher object destroyed" << std::endl;
    }

    ModelLauncher(ModelLauncher const&) = delete;
    ModelLauncher& operator=(ModelLauncher const&) = delete;

    /// @brief stores the object pointers to be passed to the model_library
    /// which right now includes workexecutor pointer and the vsomeip
    /// application pointer
    std::shared_ptr<cccm::di::launcher::LauncherContext> mContext = nullptr;

    /// @brief Container to store all the model objects
    std::vector<std::shared_ptr<cccm::di::ModelLibInterface>> mModels;

    /// @brief Container to store all the model loader objects, each such
    /// loader will use dlopen() to launch a model, stores the handle to the
    /// dlopened library
    std::vector<std::shared_ptr<cccm::di::dlopener::DLOpenInterface<cccm::di::ModelLibInterface>>> mLoaders;

#ifdef COMFORT_WRITER
    std::unique_ptr<ComfortWriter> mComfortWriter;
#endif

  public:
#ifdef COMFORT_WRITER
    void init_comfort_writer(bool const enable_comfort_writer);
    void terminate_comfort_writer();
#endif

    /// @brief Method to get instance
    /// @retval returns ModelLauncher object
    static ModelLauncher& get_instance()
    {
      static ModelLauncher sInstance;
      return sInstance;
    }

    /// @brief Method to get vsomeip app object
    ///
    /// @retval void* returns vsomeip application object
    std::shared_ptr<vsomeip::application> const get_app(std::string const appName) const;

    /// @brief Setter method for the mContext
    /// @param context pointer to the context object
    /// @satisfy{Requirement01165180, Requirement01165181, Requirement01165182}
    void set_context(std::shared_ptr<cccm::di::launcher::LauncherContext> const context);

    /// @brief Getter method for mContext
    /// @return Returns value set for mContext poniter
    std::shared_ptr<cccm::di::launcher::LauncherContext> const get_context() const;

    /// @brief Getter method for mModels
    /// @return Returns vector of pointers to the model objects
    std::vector<std::shared_ptr<cccm::di::ModelLibInterface>> const get_models() const;

    /// @brief Getter method for mLoaders
    /// @return Return vector of pointers to the model loader objects
    std::vector<std::shared_ptr<cccm::di::dlopener::DLOpenInterface<cccm::di::ModelLibInterface>>> const get_loaders()
        const;

    /// @brief Method to loads all models
    /// @param modelLibs vector of names of the model libraries
    ///
    /// @retval void* returns handler of dlopen
    /// @satisfy{Requirement01165123, Requirement01165125, Requirement01165134, Requirement01165135,
    /// Requirement01165180, Requirement01165181, Requirement01165182}
    uint32_t load_all_models(std::vector<std::string> const modelLibs);

    /// @brief Method to initilise application
    ///
    /// @retval None
    /// @satisfy{Requirement01165180}
    void init_applications();
    /// @brief Method to start someip application
    ///
    /// @retval None
    /// @satisfy{Requirement01165180}
    void start_applications();

    /// @brief Method to top someip application
    ///
    /// @retval None
    /// @satisfy{Requirement01165234}
    void stop_applications() const;

    /// @brief Method to terminate the models
    ///
    /// @retval None
    /// @satisfy{Requirement01165234}
    void terminate();

    /// @brief method to dl_close() all the loaded libs
    uint32_t dlCloseAll() const;
  };
};  // namespace cccm::di::launcher
#endif
