#ifndef _DLFCN_H
#define _DLFCN_H

#include <iostream>
#include <string.h>

#define RTLD_NEXT ((void*)-1l)
#define RTLD_DEFAULT ((void*)0)
#define RTLD_LAZY 0x00001 /* Lazy function call binding.  */
#define RTLD_NOW 0x00002 /* Immediate function call binding.  */
#define RTLD_BINDING_MASK 0x3 /* Mask of binding time value.  */
#define RTLD_NOLOAD 0x00004 /* Do not load the object.  */
#define RTLD_DEEPBIND 0x00008 /* Use deep binding.  */

void* dlsym(void* __restrict __handle, char const* __restrict __name);
void* dlopen(char const* __file, int __mode);
char const* dlerror(void);
int dlclose(void* __handle);
#endif
