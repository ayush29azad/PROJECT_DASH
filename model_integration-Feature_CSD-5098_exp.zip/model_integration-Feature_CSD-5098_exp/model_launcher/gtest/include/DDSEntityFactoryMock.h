#ifndef DDS_ENTITY_FACTORY_MOCK_H
#define DDS_ENTITY_FACTORY_MOCK_H

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <string>

// Include the actual interface definitions so the compiler knows these types
#include "DDSEntityFactoryInterface.hpp"
#include "DDSManagerInterface.hpp"

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace dds
      {

        class MockDDSEntityFactory : public DDSEntityFactoryInterface
        {
        public:
          virtual DDSManagerInterface* create_manager(
              eprosima::fastdds::dds::DataReaderListener* listener, std::string dltAppName) override
          {
            return create_manager_proxy_2(listener, dltAppName);
          }

          virtual DDSManagerInterface* create_manager(
              eprosima::fastdds::dds::DataReaderListener* listener, std::string dltAppName,
              std::string appDescription) override  // Added override
          {
            // Added 'return' here
            return create_manager_proxy_3(listener, dltAppName, appDescription);
          }

          MOCK_METHOD(
              DDSManagerInterface*, create_manager_proxy_2, (eprosima::fastdds::dds::DataReaderListener*, std::string));
          MOCK_METHOD(
              DDSManagerInterface*, create_manager_proxy_3,
              (eprosima::fastdds::dds::DataReaderListener*, std::string, std::string));

          MOCK_METHOD(eprosima::fastdds::dds::DataReader*, get_reader, (std::string const&), (override));
          MOCK_METHOD(eprosima::fastdds::dds::DataWriter*, get_writer, (std::string const&), (override));
          MOCK_METHOD(eprosima::fastdds::dds::DataReaderQos, get_reader_qos, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::DataWriterQos, get_writer_qos, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::DomainParticipant*, get_participant, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::Topic*, get_topic, (std::string const&), (override));
          MOCK_METHOD(eprosima::fastdds::dds::Publisher*, get_publisher, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::Subscriber*, get_subscriber, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::TopicQos, get_topic_qos, (), (override));
          MOCK_METHOD(eprosima::fastdds::dds::DomainParticipantQos, get_participant_qos, (), (override));
        };

      }  // namespace dds
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif  // DDS_ENTITY_FACTORY_MOCK_H
