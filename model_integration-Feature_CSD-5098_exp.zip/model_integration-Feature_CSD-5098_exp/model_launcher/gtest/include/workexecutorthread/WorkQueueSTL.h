
/// @file WorkQueueSTL.h
/// @brief WorkQueueSTL for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef _WORKQUEUESTL_JLRWORKEXECUTOR_HEADER_
#define _WORKQUEUESTL_JLRWORKEXECUTOR_HEADER_

#include <iostream>
#include <memory>
#include <WorkQueue.h>
#include <WorkQueueSTL.h>
#include <SafeQueue.h>
// class SafeQueue<Work>;

namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        class WorkQueueSTL : public WorkQueue
        {

        private:
          // todo : develop a thread safe std printer class which can be inherited from
          std::shared_ptr<std::mutex> printMutex;
          std::shared_ptr<SafeQueue<Work>> q = nullptr;

        public:
          // todo : delete other constructors and operators
          WorkQueueSTL()
          {
          }

          // todo : could be blocking, make it non blocking
          virtual int8_t send(Work* work)
          {
          }

          // todo : could be blocking, make it non blocking
          // todo : workPtr should point to alive work object
          virtual Work& recv()
          {
          }

          virtual bool checkForEmpty()
          {
          }

          ~WorkQueueSTL()
          {
          }
        };
      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr

#endif
