/// @file Work.h
/// @brief Work for doxygen examples
///
/// @copyright "Copyright (C) 2020, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date October 2023

#ifndef _WORK_HEADER_
#define _WORK_HEADER_

#include <iostream>
#include <future>
#include <thread>
#include <functional>
#if defined(ENABLE_DLT_LOGGING)
#include "logging_api.h"
#endif

#define DEBUG_LOG_METHOD_START  // BOOST_LOG_TRIVIAL(info) << __func__ << " +++START+++ " << __LINE__ << std::endl;
#define DEBUG_LOG_METHOD_END  // BOOST_LOG_TRIVIAL(info) << __func__ << " +++END+++ " << __LINE__ << std::endl;
namespace jlr
{
  namespace cccm
  {
    namespace di
    {
      namespace work_executor
      {
        class Work
        {

        private:
          void* modelData = nullptr;
          std::function<void(void*)> modelFunArg = nullptr;
          std::function<void()> modelFunNoArg = nullptr;
          uint32_t defaultPriority = static_cast<uint32_t>(5);

        public:
          Work()
          {
          }

          Work(std::function<void()> const _modelFunNoArg)
          {
          }

          std::function<void()> getModelFun() const {};

          Work(void* const _modeldata, std::function<void(void*)> const _modelFun){};

          virtual ~Work(){};

          // todo : other getters and setters, delete copy, move, assignment

          uint32_t* get_priority() {};

          void operator()() {};

          bool isEmpty() {};
        };

      }  // namespace work_executor
    }  // namespace di
  }  // namespace cccm
}  // namespace jlr
#endif
