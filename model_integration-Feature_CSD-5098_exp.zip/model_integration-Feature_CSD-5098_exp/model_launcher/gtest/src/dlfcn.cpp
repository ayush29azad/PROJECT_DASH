#include <dlfcn.h>
#include <vsomeip/vsomeip.hpp>
#include <iostream>
#include <memory>
#include <ModelLibInterface.h>

class DummyModel : public cccm::di::ModelLibInterface
{
public:
  DummyModel(){};
  ~DummyModel(){};

  void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) override {};
  void terminate() override {};
};

std::shared_ptr<cccm::di::ModelLibInterface> dummy_creator()
{
  return std::make_shared<DummyModel>();
}

void* dlsym(void* __restrict __handle, char const* __restrict __name)
{
  if (__handle == nullptr)
  {
    return nullptr;
  }

  std::string symName(__name);

  if (symName == "creator")
  {
    using createFuncType = std::shared_ptr<cccm::di::ModelLibInterface> (*)();
    createFuncType symbol = (createFuncType)&dummy_creator;
    return (void*)symbol;
  }
}

void* dlopen(char const* __file, int __mode)
{
  int* ptr = nullptr;
  if (strlen(__file) > 10)  // Emulate the error scenario when lib name size is less than 11 characters
  {
    ptr = new int();  // Todo to delete
  }
  return ptr;
}
// const char* dlerror (void)
// {
//   std::string str = "Error";
//   return str.c_str();
// }
int dlclose(void* __handle)
{
  return 0;
}
