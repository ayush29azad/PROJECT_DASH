#include "ModelLauncher.h"

#ifdef COMFORT_WRITER
#include <ComfortWriter.h>
#endif

#include <ModelLauncherDltHelper.h>
#include <iostream>

namespace cccm::di::launcher
{
#ifdef COMFORT_WRITER

  void ModelLauncher::init_comfort_writer(bool const enable_comfort_writer)
  {
    if (!enable_comfort_writer)
    {
      ML_LOG_MCTX_INFO << "ComfortWriter disabled via command line.";
      return;
    }

    ML_LOG_MCTX_INFO << "Initializing ComfortWriter component.";

    // 1. Creation and Dependency Injection (Composition Pattern)
    // Pass the required dependencies: ddsFactory, workExecutor, and the SHARED MUTEX.
    try
    {
      mComfortWriter =
          std::make_unique<ComfortWriter>(mContext->ddsFactory, mContext->workExecutor, mContext->dltApplication.first);
    }
    catch (std::exception const& e)
    {
      ML_LOG_MCTX_ERROR << "Failed to create ComfortWriter: " << e.what();
      return;
    }
    catch (...)
    {
      ML_LOG_MCTX_ERROR << "Failed to create ComfortWriter: unknown exception";
      return;
    }
    // 2. Initialization and Subscription
    // This call registers the callback with the DdsCommunicationHandler and starts listening.
    if (!mComfortWriter->initialize())
    {
      ML_LOG_MCTX_ERROR << "ComfortWriter initialization failed. Deleting instance.";
      // Clean up the object if initialization failed.
      mComfortWriter.reset();
    }

    // NOTE: start_applications() is called later in the main flow to activate DDS.
  }

  // File: ModelLauncher.cpp

  void ModelLauncher::terminate_comfort_writer()
  {
    if (mComfortWriter != nullptr)
    {
      ML_LOG_MCTX_INFO << "Terminating ComfortWriter component.";

      // Explicitly calling deinitialize() ensures the DdsCommunicationHandler
      // cleans up its DataReader/Topic entities before the object is destroyed.
      // Although the destructor would handle it, an explicit call is good practice.
      mComfortWriter->deinitialize();

      // Destroy the object instance.
      mComfortWriter.reset();
    }
  }

#endif

  void ModelLauncher::init_applications()
  {
    for (std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>::iterator it =
             this->mContext->someipApp_map.begin();
         it != this->mContext->someipApp_map.end();
         ++it)
    {
      std::shared_ptr<vsomeip::application> const app = it->second;
      if (app != nullptr)
      {
        app->init();
      }
    }
  }
  /// @brief
  /// @satisfy{Requirement01445545}
  void ModelLauncher::start_applications()
  {
    std::vector<std::thread> vsomeipApp_threads;
    vsomeipApp_threads.reserve(this->mContext->someipApp_map.size());
    for (std::unordered_map<std::string, std::shared_ptr<vsomeip::application>>::iterator it =
             this->mContext->someipApp_map.begin();
         it != this->mContext->someipApp_map.end();
         ++it)
    {
      std::shared_ptr<vsomeip::application> const app = it->second;
      if (app != nullptr)
      {
        vsomeipApp_threads.emplace_back(
            [app]()
            {
              app->start();
            });
      }
    }
    for (std::thread& t : vsomeipApp_threads)
    {
      if (t.joinable())
      {
        t.join();
      }
    }
  }

  std::shared_ptr<vsomeip::application> const ModelLauncher::get_app(std::string const appName) const
  {
    if (this->mContext->someipApp_map.find(appName) == this->mContext->someipApp_map.end())
    {
      ML_LOG_MCTX_ERROR << "[Error] : Vsomeip application does not exist with vlan id " << appName << std::endl;
      return nullptr;
    }
    return this->mContext->someipApp_map[appName];
  }

  void ModelLauncher::set_context(std::shared_ptr<cccm::di::launcher::LauncherContext> const context)
  {
    this->mContext = context;
  }

  std::shared_ptr<cccm::di::launcher::LauncherContext> const ModelLauncher::get_context() const
  {
    return this->mContext;
  }

  std::vector<std::shared_ptr<cccm::di::ModelLibInterface>> const ModelLauncher::get_models() const
  {
    return this->mModels;
  }

  std::vector<std::shared_ptr<cccm::di::dlopener::DLOpenInterface<cccm::di::ModelLibInterface>>> const
  ModelLauncher::get_loaders() const
  {
    return this->mLoaders;
  }

  uint32_t ModelLauncher::load_all_models(std::vector<std::string> const modelLibs)
  {
    uint32_t loadedLibrary = 0;

    for (std::string const& model : modelLibs)
    {

      std::string libName = "lib" + model + ".so";

      /// Create model loader object with the allocator and deallocator symbol names
      std::shared_ptr<cccm::di::dlopener::DLOpenInterface<cccm::di::ModelLibInterface>> dlopener =
          std::make_shared<cccm::di::dlopener::ModelLoader<cccm::di::ModelLibInterface>>(libName, "creator");

      if (dlopener != nullptr)
      {
        mLoaders.push_back(dlopener);
        bool opened = dlopener->dl_open();

        if (opened)
        {
          /// Getting ModelWrapper object
          std::shared_ptr<cccm::di::ModelLibInterface> ptr = dlopener->get_object();

          if (ptr != nullptr)
          {
            mModels.push_back(ptr);
            loadedLibrary++;
          }
          else
          {
            ML_LOG_MCTX_ERROR << "[Error] : Unable to find creater and deleter functions" << std::endl;
          }
        }
      }
      else
      {
        ML_LOG_MCTX_ERROR << "[Error] : dl_open() failed" << std::endl;
      }
    }

    for (auto ptr : mModels)
    {
      ptr->init(mContext);
    }

    return loadedLibrary;
  }

  void ModelLauncher::stop_applications() const
  {
    for (std::pair<std::string const, std::shared_ptr<vsomeip::application>> const& pair :
         this->mContext->someipApp_map)
    {
      if (pair.second != nullptr)
      {
        pair.second->stop();
      }
    }
  }

  void ModelLauncher::terminate()
  {
    // Along with calling model->terminate() we also need to remove the
    // shared pointer from the vector to make sure that the model wrapper
    // object is destroyed here only and doesn't last till the end of the
    // main() function
    while (mModels.empty() == false)
    {
      auto ptr = mModels.back();
      ptr->terminate();
      mModels.pop_back();
    }
  }

  uint32_t ModelLauncher::dlCloseAll() const
  {
    uint32_t dlcloseCount = 0;
    for (auto ptr : mLoaders)
    {
      bool res = ptr->dl_close();
      if (res == true)
      {
        dlcloseCount++;
      }
      ML_LOG_MCTX_INFO << "dl_close() status : " << res << std::endl;
    }
    return dlcloseCount;
  }
}  // namespace cccm::di::launcher

// File: ModelLauncher.cpp
