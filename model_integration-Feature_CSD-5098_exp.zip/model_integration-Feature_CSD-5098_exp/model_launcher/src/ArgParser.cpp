#include <string>
#include <iostream>
#include <boost/program_options.hpp>

#include "ArgParser.h"
#include "ModelLauncherDltHelper.h"

namespace po = boost::program_options;
namespace cccm::di::launcher
{
  std::string const ArgParser::OPT_DLT_ID = "dlt_id";
  std::string const ArgParser::OPT_MODELS = "models";
  std::string const ArgParser::OPT_VID = "vid";
  std::string const ArgParser::DEFAULT_DLT_ID = "MD00";

  ArgParser::ArgParser()
  {
  }
  /// @satisfy{Requirement01403295}
  /// @satisfy{Requirement01165039}
  /// @satisfy{Requirement01165040}
  /// @satisfy{Requirement01165042}
  /// @satisfy{Requirement01445518}
  /// @satisfy{Requirement01445546}
  /// @satisfy{Requirement01165194}
  bool ArgParser::parse_args(int32_t const argc, char const* const* argv)
  {
    try
    {
      po::options_description desc("Allowed options");
      desc.add_options()("dlt_id", po::value<std::string>(), "Set DLT application ID")(
          "models",
          po::value<std::vector<std::string>>()->multitoken(),
          "List of models. The application will dlopen the lib - lib + <model> + .so")(
          "vid", po::value<std::vector<std::string>>()->multitoken(), "List of vids")(
          "cwriter", po::bool_switch()->default_value(false), "Enables COMFORT Writer feature");

      po::variables_map vm;
      po::store(po::command_line_parser(argc, argv).options(desc).run(), vm);
      po::notify(vm);

      if (vm.count(std::string(OPT_DLT_ID)) != NO_OPTION)
      {
        this->mDltAppId = vm[std::string(OPT_DLT_ID)].as<std::string>();
      }
      else
      {
        this->mDltAppId = std::string(DEFAULT_DLT_ID);
        ML_LOG_MCTX_INFO << "DLT application ID not provided. Using default ID" << std::endl;
      }

      if (vm.count(std::string(OPT_MODELS)) != NO_OPTION)
      {
        this->mModelLibs = vm[std::string(OPT_MODELS)].as<std::vector<std::string>>();
      }
      else
      {
        ML_LOG_MCTX_ERROR << "No models provided" << std::endl;
        return false;
      }
      if (vm.count(std::string(OPT_VID)) != NO_OPTION)
      {
        this->vid = vm[std::string(OPT_VID)].as<std::vector<std::string>>();
      }
      else
      {
        ML_LOG_MCTX_ERROR << "No vid provided" << std::endl;
        return false;
      }

      if (vm["cwriter"].as<bool>())
      {
        this->mEnableComfortWriter = true;
        ML_LOG_MCTX_INFO << "Instance acting as Comfort Writer" << std::endl;
      }
      else
      {
        this->mEnableComfortWriter = false;
        ML_LOG_MCTX_INFO << "Instance not acting as Comfort Writer" << std::endl;
      }
    }
    catch (po::error const& ex)
    {
      ML_LOG_MCTX_ERROR << "Error: " << ex.what() << std::endl;
      return false;
    }
    catch (...)
    {
      ML_LOG_MCTX_ERROR << "Unknown Error while parsing options " << std::endl;
      return false;
    }

    return true;
  }

  std::string const ArgParser::get_dlt_id() const
  {
    return this->mDltAppId;
  }

  std::vector<std::string> const ArgParser::get_model_libs() const
  {
    return this->mModelLibs;
  }
  std::vector<std::string> const ArgParser::getvIds() const
  {
    return this->vid;
  }

  bool ArgParser::get_comfort_writer() const
  {
    return this->mEnableComfortWriter;
  }

  ArgParser::~ArgParser()
  {
  }
}  // namespace cccm::di::launcher
