#include "ProxySomeipApplication.hpp"

using namespace vsomeip_v3_proxy;

ProxyApplication::ProxyApplication(std::shared_ptr<vsomeip_v3::application> delegate)
    : delegate_(delegate)
    , availibility_handlers_()
    , availibility_handlers_count()
    , message_handlers_()
    , message_handlers_count()
{
}

ProxyApplication::~ProxyApplication()
{
  delegate_.reset();
}

// Multi client implementation
void ProxyApplication::register_availability_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
    vsomeip_v3::availability_handler_t const& _handler, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  {
    availibility_handler_key_t key = std::make_tuple(_service, _instance, _major, _minor);
    std::vector<vsomeip_v3::availability_handler_t>& handler_list = availibility_handlers_[key];
    std::lock_guard<std::mutex> const lock(mMutex);
    handler_list.push_back(_handler);
    availibility_handlers_count[key]++;
  }
}

void ProxyApplication::unregister_availability_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  availibility_handler_key_t key = std::make_tuple(_service, _instance, _major, _minor);
  {
    {
      std::lock_guard<std::mutex> const lock(mMutex);
      availibility_handlers_count[key]--;
    }
    if (availibility_handlers_count[key] == 0)
    {
      delegate_->unregister_availability_handler(_service, _instance, _major, _minor);
    }
  }
}

void ProxyApplication::register_message_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method,
    vsomeip_v3::message_handler_t const& _handler)
{
  {
    message_handler_key_t key = std::make_tuple(_service, _instance, _method);
    std::vector<vsomeip_v3::message_handler_t>& handler_list = message_handlers_[key];
    std::lock_guard<std::mutex> const lock(mMutex);
    handler_list.push_back(_handler);
    message_handlers_count[key]++;
  }
}

void ProxyApplication::register_message_handler_ext(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method,
    vsomeip_v3::message_handler_t const& _handler, vsomeip_v3::handler_registration_type_e _type)
{

  {
    message_handler_key_t key = std::make_tuple(_service, _instance, _method);
    std::lock_guard<std::mutex> lock(mMutex);
    auto& handler_list = message_handlers_[key];

    switch (_type)
    {
      case vsomeip_v3::handler_registration_type_e::HRT_APPEND:
        handler_list.push_back(_handler);
        break;

      case vsomeip_v3::handler_registration_type_e::HRT_PREPEND:
        handler_list.insert(handler_list.begin(), _handler);
        break;

      case vsomeip_v3::handler_registration_type_e::HRT_REPLACE:
        handler_list.clear();
        handler_list.push_back(_handler);
        break;

      case vsomeip_v3::handler_registration_type_e::HRT_UNKNOWN:
      default:
        return;
    }

    message_handlers_count[key] = handler_list.size();
  }
}

void ProxyApplication::unregister_message_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::method_t _method)
{
  message_handler_key_t key = std::make_tuple(_service, _instance, _method);
  {
    {
      std::lock_guard<std::mutex> const lock(mMutex);
      message_handlers_count[key]--;
    }
    if (message_handlers_count[key] == 0)
    {
      delegate_->unregister_message_handler(_service, _instance, _method);
    }
  }
}

void ProxyApplication::start()
{
  // Handle availibility handler
  for (std::pair<availibility_handler_key_t const, std::vector<vsomeip_v3::availability_handler_t>>& handler :
       availibility_handlers_)
  {
    vsomeip_v3::service_t _service = std::get<0>(handler.first);
    vsomeip_v3::instance_t _instance = std::get<1>(handler.first);

    delegate_->register_availability_handler(
        _service,
        _instance,
        [this, handler = handler](
            vsomeip_v3::service_t const _service_id,
            vsomeip_v3::instance_t const _instance_id,
            bool const _is_available)
        {
          for (vsomeip_v3::availability_handler_t const& func : handler.second)
          {
            func(_service_id, _instance_id, _is_available);
          }
        });
  }

  // Handle message handlers
  for (std::pair<message_handler_key_t const, std::vector<vsomeip_v3::message_handler_t>>& handler : message_handlers_)
  {
    vsomeip_v3::service_t _service = std::get<0>(handler.first);
    vsomeip_v3::instance_t _instance = std::get<1>(handler.first);
    vsomeip_v3::method_t _method = std::get<2>(handler.first);

    delegate_->register_message_handler(
        _service,
        _instance,
        _method,
        [this, handler = handler](std::shared_ptr<vsomeip::message> const& response_message)
        {
          for (vsomeip_v3::message_handler_t const& func : handler.second)
          {
            func(response_message);
          }
        });
  }

  delegate_->start();
}

// Simple forwarded calls
std::string const& ProxyApplication::get_name() const
{
  return delegate_->get_name();
}

vsomeip_v3::client_t ProxyApplication::get_client() const
{
  return delegate_->get_client();
}

vsomeip_v3::diagnosis_t ProxyApplication::get_diagnosis() const
{
  return delegate_->get_diagnosis();
}

bool ProxyApplication::init()
{
  return delegate_->init();
}

void ProxyApplication::stop()
{
  delegate_->stop();
}

void ProxyApplication::process(int32_t _number)
{
  delegate_->process(_number);
}

vsomeip_v3::security_mode_e ProxyApplication::get_security_mode() const
{
  return delegate_->get_security_mode();
}

void ProxyApplication::offer_service(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  delegate_->offer_service(_service, _instance, _major, _minor);
}

void ProxyApplication::stop_offer_service(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  delegate_->stop_offer_service(_service, _instance, _major, _minor);
}

void ProxyApplication::offer_event(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _notifier,
    std::set<eventgroup_t> const& _eventgroups, vsomeip_v3::event_type_e _type, std::chrono::milliseconds _cycle,
    bool _change_resets_cycle, bool _update_on_change, epsilon_change_func_t const& _epsilon_change_func,
    vsomeip_v3::reliability_type_e _reliability)
{
  delegate_->offer_event(
      _service,
      _instance,
      _notifier,
      _eventgroups,
      _type,
      _cycle,
      _change_resets_cycle,
      _update_on_change,
      _epsilon_change_func,
      _reliability);
}

void ProxyApplication::stop_offer_event(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event)
{
  delegate_->stop_offer_event(_service, _instance, _event);
}

void ProxyApplication::request_service(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  delegate_->request_service(_service, _instance, _major, _minor);
}

void ProxyApplication::release_service(vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance)
{
  delegate_->release_service(_service, _instance);
}

void ProxyApplication::request_event(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
    std::set<vsomeip_v3::eventgroup_t> const& _eventgroups, vsomeip_v3::event_type_e _type,
    vsomeip_v3::reliability_type_e _reliability)
{
  delegate_->request_event(_service, _instance, _event, _eventgroups, _type, _reliability);
}

void ProxyApplication::release_event(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event)
{
  delegate_->release_event(_service, _instance, _event);
}

void ProxyApplication::subscribe(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::major_version_t _major, vsomeip_v3::event_t _event)
{
  delegate_->subscribe(_service, _instance, _eventgroup, _major, _event);
}

void ProxyApplication::unsubscribe(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup)
{
  delegate_->unsubscribe(_service, _instance, _eventgroup);
}

bool ProxyApplication::is_available(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor) const
{
  return delegate_->is_available(_service, _instance, _major, _minor);
}

bool ProxyApplication::are_available(
    types::available_t& _available, vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
    vsomeip_v3::major_version_t _major, vsomeip_v3::minor_version_t _minor) const
{
  return delegate_->are_available(_available, _service, _instance, _major, _minor);
}

void ProxyApplication::send(std::shared_ptr<message> _message)
{
  delegate_->send(_message);
}

void ProxyApplication::notify(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
    std::shared_ptr<payload> _payload, bool _force) const
{
  delegate_->notify(_service, _instance, _event, _payload, _force);
}

void ProxyApplication::notify_one(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::event_t _event,
    std::shared_ptr<payload> _payload, vsomeip_v3::client_t _client, bool _force) const
{
  delegate_->notify_one(_service, _instance, _event, _payload, _client, _force);
}

void ProxyApplication::register_state_handler(vsomeip_v3::state_handler_t const& _handler)
{
  delegate_->register_state_handler(_handler);
}

void ProxyApplication::unregister_state_handler()
{
  delegate_->unregister_state_handler();
}

VSOMEIP_DEPRECATED_UID_GID void ProxyApplication::register_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    subscription_handler_t const& _handler)
{
  // delegate_->register_subscription_handler(_service, _instance, _eventgroup, _handler);
  (void)_service;
  (void)_instance;
  (void)_eventgroup;
  (void)_handler;
}

VSOMEIP_DEPRECATED_UID_GID void ProxyApplication::register_async_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    async_subscription_handler_t const& _handler)
{
  // delegate_->register_async_subscription_handler(_service, _instance, _eventgroup, _handler);
  (void)_service;
  (void)_instance;
  (void)_eventgroup;
  (void)_handler;
}

void ProxyApplication::unregister_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup)
{
  delegate_->unregister_subscription_handler(_service, _instance, _eventgroup);
}

void ProxyApplication::clear_all_handler()
{
  delegate_->clear_all_handler();
}

bool ProxyApplication::is_routing() const
{
  return delegate_->is_routing();
}

void ProxyApplication::set_routing_state(vsomeip_v3::routing_state_e _routing_state)
{
  delegate_->set_routing_state(_routing_state);
}

void ProxyApplication::unsubscribe(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::event_t _event)
{
  delegate_->unsubscribe(_service, _instance, _eventgroup, _event);
}

void ProxyApplication::register_subscription_status_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::event_t _event, vsomeip_v3::subscription_status_handler_t _handler, bool _is_selective)
{
  delegate_->register_subscription_status_handler(_service, _instance, _eventgroup, _event, _handler, _is_selective);
}

void ProxyApplication::unregister_subscription_status_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::event_t _event)
{
  delegate_->unregister_subscription_status_handler(_service, _instance, _eventgroup, _event);
}

void ProxyApplication::get_offered_services_async(
    vsomeip_v3::offer_type_e _offer_type, vsomeip_v3::offered_services_handler_t const& _handler)
{
  delegate_->get_offered_services_async(_offer_type, _handler);
}

void ProxyApplication::set_watchdog_handler(
    vsomeip_v3::watchdog_handler_t const& _handler, std::chrono::seconds _interval)
{
  delegate_->set_watchdog_handler(_handler, _interval);
}

void ProxyApplication::set_sd_acceptance_required(remote_info_t const& _remote, std::string const& _path, bool _enable)
{
  delegate_->set_sd_acceptance_required(_remote, _path, _enable);
}

void ProxyApplication::set_sd_acceptance_required(types::sd_acceptance_map_type_t const& _remotes, bool _enable)
{
  delegate_->set_sd_acceptance_required(_remotes, _enable);
}

types::sd_acceptance_map_type_t ProxyApplication::get_sd_acceptance_required()
{
  return delegate_->get_sd_acceptance_required();
}

void ProxyApplication::register_sd_acceptance_handler(vsomeip_v3::sd_acceptance_handler_t const& _handler)
{
  delegate_->register_sd_acceptance_handler(_handler);
}

void ProxyApplication::register_reboot_notification_handler(vsomeip_v3::reboot_notification_handler_t const& _handler)
{
  delegate_->register_reboot_notification_handler(_handler);
}

void ProxyApplication::register_routing_ready_handler(vsomeip_v3::routing_ready_handler_t const& _handler)
{
  delegate_->register_routing_ready_handler(_handler);
}

void ProxyApplication::register_routing_state_handler(vsomeip_v3::routing_state_handler_t const& _handler)
{
  delegate_->register_routing_state_handler(_handler);
}

bool ProxyApplication::update_service_configuration(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, std::uint16_t _port, bool _reliable,
    bool _magic_cookies_enabled, bool _offer)
{
  return delegate_->update_service_configuration(_service, _instance, _port, _reliable, _magic_cookies_enabled, _offer);
}

void ProxyApplication::update_security_policy_configuration(
    uint32_t _uid, uint32_t _gid, std::shared_ptr<policy> _policy, std::shared_ptr<payload> _payload,
    vsomeip_v3::security_update_handler_t const& _handler)
{
  delegate_->update_security_policy_configuration(_uid, _gid, _policy, _payload, _handler);
}

void ProxyApplication::remove_security_policy_configuration(
    uint32_t _uid, uint32_t _gid, vsomeip_v3::security_update_handler_t const& _handler)
{
  delegate_->remove_security_policy_configuration(_uid, _gid, _handler);
}

VSOMEIP_DEPRECATED_UID_GID void ProxyApplication::register_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    subscription_handler_ext_t const& _handler)
{
  // delegate_->register_subscription_handler(_service, _instance, _eventgroup, _handler);
  (void)_service;
  (void)_instance;
  (void)_eventgroup;
  (void)_handler;
}

VSOMEIP_DEPRECATED_UID_GID void ProxyApplication::register_async_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    async_subscription_handler_ext_t const& _handler)
{
  // delegate_->register_async_subscription_handler(_service, _instance, _eventgroup, _handler);
  (void)_service;
  (void)_instance;
  (void)_eventgroup;
  (void)_handler;
}

void ProxyApplication::subscribe_with_debounce(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::major_version_t _major, vsomeip_v3::event_t _event, vsomeip_v3::debounce_filter_t const& _filter)
{
  delegate_->subscribe_with_debounce(_service, _instance, _eventgroup, _major, _event, _filter);
}

void ProxyApplication::register_message_acceptance_handler(vsomeip_v3::message_acceptance_handler_t const& _handler)
{
  delegate_->register_message_acceptance_handler(_handler);
}

std::map<std::string, std::string> ProxyApplication::get_additional_data(std::string const& _plugin_name)
{
  return delegate_->get_additional_data(_plugin_name);
}

void ProxyApplication::register_availability_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance,
    vsomeip_v3::availability_state_handler_t const& _handler, vsomeip_v3::major_version_t _major,
    vsomeip_v3::minor_version_t _minor)
{
  delegate_->register_availability_handler(_service, _instance, _handler, _major, _minor);
}

void ProxyApplication::register_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::subscription_handler_sec_t const& _handler)
{
  delegate_->register_subscription_handler(_service, _instance, _eventgroup, _handler);
}

void ProxyApplication::register_async_subscription_handler(
    vsomeip_v3::service_t _service, vsomeip_v3::instance_t _instance, vsomeip_v3::eventgroup_t _eventgroup,
    vsomeip_v3::async_subscription_handler_sec_t _handler)
{
  delegate_->register_async_subscription_handler(_service, _instance, _eventgroup, _handler);
}
