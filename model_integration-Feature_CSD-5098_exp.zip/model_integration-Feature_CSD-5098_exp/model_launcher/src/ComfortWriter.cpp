// File: ComfortWriter.cpp

#include "ComfortWriter.h"
#include "CombinedTopics.h"
#include <ModelLauncherDltHelper.h>
#include <CombinedTopicsPubSubTypes.h>
#include <unistd.h>  // For sync()

#if defined(__QNX__)
#include <boot_marker.h>
#endif

// Assuming this header defines all necessary DDS types, including dds_ipc::VehicleLifecycle,
// logging macros (ML_LOG_MCTX_INFO, etc.), and other dependencies.

// --- External Helper Function (Inferred) ---
// This function must be accessible to ComfortWriter::init() to get the type description
// required by the DdsCommunicationHandler.

namespace cccm
{
  namespace di
  {
    namespace launcher
    {
      // --- Constructor (Main Thread) ---
      char const* const ComfortWriter::COMFORT_TOPIC_NAME = "dds_ipc::vehicleLifecycle";
      char const* const ComfortWriter::COMFORT_FILE_PATH = "/dev/shmem/VehicleStateComfort.txt";
      ComfortWriter::ComfortWriter(
          std::shared_ptr<DDSEntityFactoryInterface> const ddsFactory, std::shared_ptr<WorkExecutor> const workExecutor,
          std::string const& comfortWriterDlt)
          : mWorkExecutor(workExecutor)
      {
        // Initialize the DdsCommunicationHandler (Composition).
        // It receives the necessary dependencies for its internal DDS setup and thread safety.
        mDdsHandler = std::make_unique<jlr::cccm::di::ComfortDdsCommunicationHandler>(ddsFactory, comfortWriterDlt);
        ML_LOG_MCTX_INFO << "ComfortWriter object created with ComfortDdsCommunicationHandler." << std::endl;
      }

      // --- Initialization (Main Thread) ---
      bool ComfortWriter::initialize()
      {
        // 1. Configure Thread Offloading: Tell the handler to use our WorkExecutor.
        // This is CRITICAL for offloading the subscription callback logic.
        mDdsHandler->set_work_executor(mWorkExecutor);

        // 2. Define Callback: Create the required std::function<void(void)> bound to our method.
        auto const callback = [this]()
        {
          this->on_comfort_data_available();
        };
        // 3. Register Subscription: Call the standardized API (DdsCommunicationHandler::topic_in).

        std::unique_ptr<TopicDataType> vehicleLifecycleTypePtr =
            std::make_unique<dds_ipc::vehicleLifecyclePubSubType>();
        // The handler creates the DataReader/Topic and attaches its internal listener.
        bool const result = mDdsHandler->topic_in(COMFORT_TOPIC_NAME, vehicleLifecycleTypePtr.release(), callback);

        if (result)
        {
          ML_LOG_MCTX_INFO << "ComfortWriter successfully subscribed to " << COMFORT_TOPIC_NAME << std::endl;
        }
        else
        {
          ML_LOG_MCTX_INFO << "Failed to subscribe via ComfortDdsCommunicationHandler." << std::endl;
        }

        return result;
      }

      // This method is the registered callback. It executes on the Worker Thread.
      void ComfortWriter::on_comfort_data_available()
      {

        dds_ipc::vehicleLifecycle msg;

        // 1. EXPLICIT READ: Pull the data from the internal DDS buffer using the handler's API.
        if (mDdsHandler->recv(&msg, COMFORT_TOPIC_NAME))
        {
          // 2. DECISION POINT:
          if (msg.eVehicle_State() == dds_ipc::enmVehicleState::ENUM_STATE_COMFORT)
          {
            ML_LOG_MCTX_INFO << "The vehicle state is :" << msg.eVehicle_State() << std::endl;
            execute_comfort_logic_and_cleanup();
          }
          else
          {
            ML_LOG_MCTX_DEBUG << "State received, but not COMFORT. Continuing." << std::endl;
            // 2. HOT FIX: State is NOT COMFORT.
            // Check if we previously achieved COMFORT (mIsComfortReached was true).
            // We use exchange(false) to check the value and reset it in one atomic step.
            if (mIsComfortReached.exchange(false) == true)
            {
              ML_LOG_MCTX_INFO << "State changed away from COMFORT. Deleting file and cleaning up." << std::endl;

              // Delete the marker file
              constexpr std::int32_t UNLINK_SUCCESS = 0;
              if (unlink(COMFORT_FILE_PATH) == UNLINK_SUCCESS)
              {
                ML_LOG_MCTX_INFO << "File deleted successfully: " << COMFORT_FILE_PATH << std::endl;

                // Perform File Sync
                sync();
                ML_LOG_MCTX_DEBUG << "Filesystem sync performed." << std::endl;
                // Now we can safely deinitialize since the "undo" logic is complete
                deinitialize();
                ML_LOG_MCTX_INFO << "ComfortWriter file deleted as other VLC state recived " << std::endl;
              }
              else
              {
                // Check errno to see if the file actually existed
                ML_LOG_MCTX_ERROR << "Delete ComfortFile.txt failed " << std::endl;
              }
            }
          }
        }
        else
        {
          ML_LOG_MCTX_ERROR << "Failed to receive data from DDS buffer via handler." << std::endl;
        }
      }

      void ComfortWriter::execute_comfort_logic_and_cleanup()
      {
        // This entire method runs on the Work Executor thread, making file I/O safe.

        // 3. ATOMIC CHECK (Thread Safety: Ensure logic runs only once)
        // Corrected line 93:
        if (mIsComfortReached.exchange(true) == true)
        {
          ML_LOG_MCTX_WARN << "Logic already executed. Aborting second execution." << std::endl;
          return;
        }

        // 4. FILE I/O
        std::ofstream comfort_file(COMFORT_FILE_PATH);
        if (comfort_file.is_open())
        {
          comfort_file.close();
#if defined(__QNX__)
          QNX_TIME_STAMP(0, EXYNOSAUTO_TIMELINE_QNX_BASE, 0xE2503);
#endif
          ML_LOG_MCTX_INFO << "SUCCESS: vehicle state file created: " << COMFORT_FILE_PATH << std::endl;
        }
        else
        {
          ML_LOG_MCTX_ERROR << "FAILURE: Could not create file " << COMFORT_FILE_PATH << " Check permissions."
                            << std::endl;
        }
      }

      // --- Shutdown/Cleanup (Runs on Worker Thread or Main Thread) ---
      void ComfortWriter::deinitialize()
      {
        // The DdsCommunicationHandler is an std::unique_ptr, so calling reset()
        // explicitly calls its destructor, cleaning up its managed DDS entities (DataReader, Topic).
        mDdsHandler.reset();
        ML_LOG_MCTX_INFO << "ComfortDdsCommunicationHandler instance has been reset, releasing DDS resources."
                         << std::endl;
      }

    }  // namespace launcher
  }  // namespace di
}  // namespace cccm
