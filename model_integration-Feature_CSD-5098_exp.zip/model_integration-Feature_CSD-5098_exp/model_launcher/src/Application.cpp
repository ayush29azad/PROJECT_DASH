#include <ModelLauncherDltHelper.h>
#include "Application.h"

using ArgParser = cccm::di::launcher::ArgParser;

int main(int32_t const argc, char const* const* argv)
{
  ArgParser argParser;
  bool const parsed = argParser.parse_args(argc, argv);

  if (parsed == false)
  {
    ML_LOG_MCTX_ERROR << "Couldn't parse arguments, exiting" << std::endl;
    return 0;
  }

  std::unique_ptr<cccm::di::launcher::ModelContextFactoryInterface> contextFactory =
      std::make_unique<cccm::di::launcher::ModelContextFactory>(argParser);

  model_launcher_main::model_launcher_main(std::move(contextFactory));
  return 0;
}
