#include <iostream>
#include <random>
#include <type_traits>
#include <CombinedTopicsPubSubTypes.h>

// ----- Generic Random Generator -----
class RandomDataGenerator
{
private:
  std::mt19937 gen;

public:
  RandomDataGenerator(uint_fast32_t seed)
      : gen(seed)
  {
  }

  // For integrals (except bool)
  template <typename T>
  std::enable_if_t<std::is_integral_v<T> && !std::is_same_v<bool, T>, T> random_value(
      T min = std::numeric_limits<T>::min(), T max = std::numeric_limits<T>::max())
  {
    std::uniform_int_distribution<T> dist(min, max);
    return dist(gen);
  }

  // For bool
  // Specify p value (probability of generating true) for bernoulli_distribution
  template <typename T>
  std::enable_if_t<std::is_same_v<T, bool>, T> random_value(float p = 0.5)
  {
    std::bernoulli_distribution dist(p);
    return dist(gen);
  }

  // For enums
  // Specify a range from which enum values will be generated. (default max = 1, min = 0)
  template <typename T>
  std::enable_if_t<std::is_enum_v<T>, T> random_value(
      std::underlying_type_t<T> min = 0, std::underlying_type_t<T> max = 1)
  {
    std::uniform_int_distribution<std::underlying_type_t<T>> dist(min, max);
    return static_cast<T>(dist(gen));
  }

  // For dds_str_uint8
  // Specify the length of the payload (str) to be generated. Default = 50, max_allowed = 500
  // If length > 500, then we'll use 500 only
  template <typename T>
  std::enable_if_t<std::is_same_v<T, dds_ipc::dds_str_uint8>, T> random_value(uint32_t length = 100)
  {
    length = std::min(length, (uint32_t)500);

    dds_ipc::dds_str_uint8 val;
    val.payload_length(length);

    std::array<uint8_t, 500> payload = val.payload();
    std::uniform_int_distribution<uint8_t> dist(
        std::numeric_limits<uint8_t>::min(), std::numeric_limits<uint8_t>::max());
    for (size_t i = 0; i < length; i++)
    {
      payload[i] = dist(gen);
    }

    return val;
  }
};
