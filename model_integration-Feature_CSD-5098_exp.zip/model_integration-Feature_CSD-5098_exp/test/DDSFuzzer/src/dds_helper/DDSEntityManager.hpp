#ifndef DDS_ENTITY_MANAGER_HPP
#define DDS_ENTITY_MANAGER_HPP

#include <fastdds/dds/domain/DomainParticipant.hpp>
#include <fastdds/dds/domain/DomainParticipantListener.hpp>
#include <fastdds/dds/domain/DomainParticipantFactory.hpp>
#include <fastdds/dds/publisher/DataWriter.hpp>
#include <fastdds/dds/publisher/DataWriterListener.hpp>
#include <fastdds/dds/publisher/qos/DataWriterQos.hpp>
#include <fastdds/dds/publisher/Publisher.hpp>
#include <fastdds/dds/topic/TypeSupport.hpp>
#include <fastdds/rtps/transport/shared_mem/SharedMemTransportDescriptor.h>
#include <fastdds/dds/subscriber/DataReader.hpp>
#include <fastdds/dds/subscriber/DataReaderListener.hpp>
#include <fastdds/dds/subscriber/qos/DataReaderQos.hpp>
#include <fastdds/dds/subscriber/SampleInfo.hpp>
#include <fastdds/dds/subscriber/Subscriber.hpp>

#include "DataReceivers.hpp"

using namespace eprosima::fastdds::dds;
using namespace eprosima::fastdds::rtps;

class DDSEntityManager
{
private:
  DomainParticipant* participant = nullptr;
  Publisher* publisher = nullptr;
  Subscriber* subscriber = nullptr;
  DDSGenericDataReceiver data_receiver;

public:
  DDSEntityManager()
  {
    DomainParticipantQos dpQos = DomainParticipantFactory::get_instance()->get_default_participant_qos();
    participant = DomainParticipantFactory::get_instance()->create_participant(0, dpQos);
  }

  DataWriter* create_writer(TypeSupport type_, std::string const& topic_name)
  {
    // register the type with participant
    ReturnCode_t retcode = type_.register_type(participant);
    if (retcode != ReturnCode_t::RETCODE_OK)
    {
      return nullptr;
    }

    // create topic
    Topic* topic = participant->create_topic(topic_name, type_.get_type_name(), participant->get_default_topic_qos());
    if (topic == nullptr)
    {
      return nullptr;
    }

    if (publisher == nullptr)
    {
      publisher = participant->create_publisher(participant->get_default_publisher_qos());
    }

    // create writer
    DataWriter* writer = publisher->create_datawriter(topic, publisher->get_default_datawriter_qos(), nullptr);
    if (writer == nullptr)
    {
      return nullptr;
    }

    return writer;
  }

  DataWriter* create_writer(TypeSupport type_)
  {
    return create_writer(type_, type_.get_type_name());
  }

  bool delete_writer(DataWriter* writer)
  {
    ReturnCode_t retcode;
    retcode = publisher->delete_datawriter(writer);
    if (retcode != ReturnCode_t::RETCODE_OK)
    {
      return false;
    }
    return true;
  }

  DataReader* create_reader(TypeSupport type_, std::string const& topic_name)
  {
    // register the type with participant
    ReturnCode_t retcode = type_.register_type(participant);
    if (retcode != ReturnCode_t::RETCODE_OK)
    {
      return nullptr;
    }

    // create topic
    Topic* topic = participant->create_topic(topic_name, type_.get_type_name(), participant->get_default_topic_qos());
    if (topic == nullptr)
    {
      return nullptr;
    }

    if (subscriber == nullptr)
    {
      subscriber = participant->create_subscriber(participant->get_default_subscriber_qos());
    }

    // create reader
    DataReader* reader = subscriber->create_datareader(topic, subscriber->get_default_datareader_qos(), nullptr);
    if (reader == nullptr)
    {
      return nullptr;
    }

    return reader;
  }

  DataReader* create_reader(TypeSupport type_)
  {
    return create_reader(type_, type_.get_type_name());
  }

  bool delete_reader(DataReader* reader)
  {
    ReturnCode_t retcode;
    retcode = subscriber->delete_datareader(reader);
    if (retcode != ReturnCode_t::RETCODE_OK)
    {
      return false;
    }
    return true;
  }

  DDSGenericDataReceiver* get_generic_receiver()
  {
    return &this->data_receiver;
  }

  ~DDSEntityManager()
  {
    if (publisher != nullptr)
    {
      publisher->delete_contained_entities();
      participant->delete_publisher(publisher);
    }
    if (subscriber != nullptr)
    {
      subscriber->delete_contained_entities();
      participant->delete_subscriber(subscriber);
    }
    if (participant != nullptr)
    {
      participant->delete_contained_entities();
      DomainParticipantFactory::get_instance()->delete_participant(participant);
    }
  }
};

#endif
