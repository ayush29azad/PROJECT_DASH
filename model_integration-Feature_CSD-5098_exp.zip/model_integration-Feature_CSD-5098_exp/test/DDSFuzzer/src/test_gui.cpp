#include <iostream>
#include <chrono>
#include <thread>
#include <typeinfo>
#include <cxxabi.h>

#include <fastdds/dds/core/condition/WaitSet.hpp>
#include <fastdds/dds/core/condition/Condition.hpp>

#include <boost/program_options.hpp>
namespace po = boost::program_options;

#ifndef CUSTOM_DDS_MANAGER
#include <DDSEntityFactory.hpp>
#endif

#include "GUI.generated.hpp"

int main(int argc, char** argv)
{
  bool use_waitset = false;

  po::options_description desc("Allowed options");
  desc.add_options()("help,h", "produce this help message")
#ifdef CUSTOM_DDS_MANAGER
      ("waitset,w",
       po::bool_switch(&use_waitset),
       "Set this flag to use waitsets for reading data instead of listener callbacks");
#else
      ;
#endif
  po::variables_map vm;
  po::store(po::command_line_parser(argc, argv).options(desc).run(), vm);
  po::notify(vm);

  if (vm.count("help"))
  {
    std::cout << desc << "\n";
    return 1;
  }

  std::cout << "Starting subscriber\n" << (use_waitset ? "Using waitset" : "Using Listeners") << std::endl;

  // set info log level for debugging puposes
  eprosima::fastdds::dds::Log::SetVerbosity(eprosima::fastdds::dds::Log::Kind::Info);

#ifdef CUSTOM_DDS_MANAGER
  DDSEntityManager manager;
#else
  using namespace jlr::cccm::di::dds;
  DDSEntityFactoryInterface* factory = new DDSEntityFactory(DEFAULT_TRANSPORT);
  TopicDataReceiver* receiver = new TopicDataReceiver();
  DDSManagerInterface* manager = factory->create_manager(receiver, "TestGUI");
#endif

  AllGUI gui;

#ifdef CUSTOM_DDS_MANAGER
  gui.init_all(&manager, !use_waitset);

  if (!use_waitset)
  {
    std::cout << "Attached listeners for the data readers....\n";
    std::cout << "Press any key to stop...." << std::endl;
    std::cin.get();
  }
  else
  {
    DDSGenericDataReceiver* receiver = manager.get_generic_receiver();

    std::cout << "Stopping if no signal received within 5 seconds...." << std::endl;
    receiver->main_loop(Duration_t(5));
  }

#else
  gui.init_all(manager, receiver);
  std::cout << "Press any key to stop...." << std::endl;
  std::cin.get();

  delete manager;
  manager = nullptr;

  delete factory;
  factory = nullptr;
#endif

  gui.print_stats_all();
  return 0;
}
