import json
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

import argparse 
parser = argparse.ArgumentParser(
    description='''
    Generate model and GUI DDS Fuzzer topic data code'''
)
parser.add_argument("-j", "--mapping-json",
                    type=Path,
                    required=True,
                    help="Path to DI_ALL_topics_mapping.json file")
parser.add_argument("-x", "--dsdirect-xml",
                    type=Path,
                    required=True,
                    help="Path to ds_direct.xml file")

args = parser.parse_args()

# Paths to config files
json_path = args.mapping_json   # "DI_ALL_topics_mapping.json"
xml_path = args.dsdirect_xml    # "ds_direct.xml" 

model_output_path = "src/Models.generated.hpp"
gui_output_path = "src/GUI.generated.hpp"
topic_info_json_path = "utils/topic_info.json"

# Load JSON mapping
with open(json_path) as f:
    mapping = json.load(f)

# Parse XML for enum value counts and min/max for numerics
tree = ET.parse(xml_path)
root = tree.getroot()

# Build a dict: topic -> member -> xml element
xml_members = defaultdict(dict)
for elem in root:
    topic = elem.attrib.get("topic")
    name = elem.tag
    xml_members[topic][name] = elem

# Build a dict: enum_name -> number of values
enum_value_counts = {}
for elem in root:
    for child in elem:
        if child.attrib.get("type") == "list":
            enum_name = child.tag
            enum_value_counts[enum_name] = len(child.findall("*"))

def get_enum_count(enum_name):
    # Try XML first, fallback to 1
    return enum_value_counts.get(enum_name, 1)

def get_numeric_range(elem: ET.Element):
    try:
        min_val = int(elem.attrib.get("min", ""))
        if min_val == "": 
            min_val = 0
        max_val = int(elem.attrib.get("max", ""))
        if max_val == "": 
            max_val = 255
        return min_val, max_val
    except Exception:
        return 0, 255

def get_random_value_call(dtype, enum_name=None, xml_elem=None):
    if dtype in ("boolean", "bool"):
        return "gen.random_value<bool>()"
    elif dtype in ("uint8_T", "uint8", "uint16_T", "uint16", "uint32_T", "uint32", "int", "int32_T", "int32", "int16_T"):
        # Optionally, use min/max from XML
        if xml_elem is not None:
            min_val, max_val = get_numeric_range(xml_elem)
            return f"gen.random_value<{dtype.replace('_T','') + '_t'}>({min_val}, {max_val})"
        else:
            return f"gen.random_value<{dtype.replace('_T','') + '_t'}>()"
    elif dtype.startswith("enm") or dtype.startswith("enum"):
        # Enum: use enum_name and count
        count = get_enum_count(enum_name or dtype)
        return f"gen.random_value<dds_ipc::{enum_name or dtype}>(0, {count-1})"
    else:
        return f"gen.random_value<dds_ipc::{dtype}>()"

def get_pubsub_type(topic):
    # Heuristic: topic name + 'PubSubType'
    return f"{topic}PubSubType"

# Generate code
lines = []
lines.append("// This file is auto-generated. Do not edit manually.\n")
lines.append('#include "Models.hpp"\n')

for msg in mapping["messages"]:
    topic = msg["topic"]
    pubsub_type = get_pubsub_type(topic)
    lines.append(f"template<>")
    lines.append(f"void TestModel<dds_ipc::{pubsub_type}>::update_data(RandomDataGenerator& gen)")
    lines.append("{")
    
    if isinstance(msg['members'], dict):
      msg['members'] = [msg['members']]

    for member in msg["members"]:
        member_name = member["model_member_name"]
        dtype = member["model_dtype"]
        xml_elem = xml_members[topic].get(member_name)
        enum_name = dtype if dtype.startswith("enm") or dtype.startswith("enum") else None
        # If enum, try to get the enum name from mapping["enums"]
        if enum_name is None and "enum" in dtype:
            for enum in mapping.get("enums", []):
                if enum["model_enum_name"] == dtype:
                    enum_name = enum["enum_name"]
        value_call = get_random_value_call(dtype, enum_name, xml_elem)
        lines.append(f"    data_.{member_name}({value_call});")
    lines.append("}\n")

lines.append("struct AllModels {")
lines.append("\tstd::vector<std::string> active_models;")
lines.append("\tstd::unordered_map<std::string, ITestModel*> model_map;")
lines.append("")

for msg in mapping["messages"]:
    topic = msg["topic"]
    pubsub_type = get_pubsub_type(topic)
    var_name = topic + "_model"
    lines.append(f"\tTestModel<dds_ipc::{pubsub_type}> {var_name};")
lines.append("")

lines.append("""
    AllModels(std::vector<std::string> &models)
    {
        active_models = models;
        model_map = {
""")
for msg in mapping["messages"]:
    topic = msg["topic"]
    pubsub_type = get_pubsub_type(topic)
    var_name = topic + "_model"
    lines.append("\t\t\t{")
    lines.append(f'\t\t\t\t"{topic}", &{var_name}')
    lines.append("\t\t\t},")
lines.append("\t\t};")
lines.append("\t};")

lines.append("""
#ifdef CUSTOM_DDS_MANAGER
    void init_all(DDSEntityManager* manager)
#else
    void init_all(DDSManagerInterface* manager)
#endif
    {
        for(std::string &model_name : active_models)
        {
            ITestModel* model = model_map[model_name];
            model->init(manager);
        }
    }
    
    void update_and_send_all(RandomDataGenerator& generator)
    {
        for(std::string &model_name : active_models)
        {
            ITestModel* model = model_map[model_name];
            model->update_data(generator); 
            model->sendSignal();
        }
    }
""")

lines.append("};")

# Write to output file
with open(model_output_path, "w") as f:
    f.write("\n".join(lines))

print(f"Generated {model_output_path}")


## Generate GUI file

lines = []
lines.append("// This file is auto-generated. Do not edit manually.\n")
lines.append("#include \"GUI.hpp\"\n")

lines.append("struct AllGUI {")

for msg in mapping["messages"]:
    topic = msg["topic"]
    pubsub_type = get_pubsub_type(topic)
    var_name = topic + "_gui"
    lines.append(f"\tTestGUI<dds_ipc::{pubsub_type}> {var_name};")
lines.append("")

lines.append("#ifdef CUSTOM_DDS_MANAGER")
lines.append("\tvoid init_all(DDSEntityManager* manager, bool arg2)")
lines.append("#else")
lines.append("\tvoid init_all(DDSManagerInterface* manager, TopicDataReceiver* arg2)")
lines.append("#endif")
lines.append("\t{")
for msg in mapping["messages"]:
    topic = msg["topic"]
    var_name = topic + "_gui"
    lines.append(f"\t\t{var_name}.init(manager, arg2);")
lines.append("\t}")
lines.append("")

lines.append("\tvoid print_stats_all()")
lines.append("{")
for msg in mapping["messages"]:
    topic = msg["topic"]
    var_name = topic + "_gui"
    lines.append("\t\tstd::cout << '\\n';")
    lines.append(f"\t\tstd::cout << \"{var_name} stats...\"<< '\\n';")
    lines.append(f"\t\tstd::cout << \"Total Packets received: \" << {var_name}.num_samples << '\\n';")
    lines.append("")
lines.append("\t}")

lines.append("};")

# Write to output file
with open(gui_output_path, "w") as f:
    f.write("\n".join(lines))

print(f"Generated {gui_output_path}")

# check if there are some topics that are removed /modified or added
old_topic_data = None
with open(topic_info_json_path, "r") as f:
    old_topic_data = json.load(f)

old_ignored_topics:list[str] = old_topic_data["ignored"]
old_allowed_topics:list[str] = old_topic_data["allowed"]
old_unidentified_topics:list[str] = old_topic_data["unidentified"]

new_topics_data = {}
new_ignored_topics:list[str] = []
new_allowed_topics:list[str] = []
new_unidentified_topics:list[str] = []

for msg in mapping["messages"]:
    topic = msg["topic"]
    if old_ignored_topics.count(topic) > 0:
        new_ignored_topics.append(topic)
    elif old_allowed_topics.count(topic) > 0:
        new_allowed_topics.append(topic)
    else:
        new_unidentified_topics.append(topic)

new_topics_data['ignored'] = new_ignored_topics
new_topics_data['allowed'] = new_allowed_topics
new_topics_data['unidentified'] = new_unidentified_topics
new_topics_data['activate'] = old_topic_data['activate']

with open(topic_info_json_path, "w") as f:
    json.dump(new_topics_data, f, indent=4)
    f.write('\n')
