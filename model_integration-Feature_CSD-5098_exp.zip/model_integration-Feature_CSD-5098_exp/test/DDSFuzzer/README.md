# DDS Fuzzer
Application to send (randomly generated data) or receive data over dds.

## Features
* Control the fuzzed topics from a list in dynamic json 
* Configurable publish rates and number of samples
* Two variants:
    * DDSPubFuzzer / DDSSubFuzzer apps (uses native fastdds implementation)
        * Supports using waitsets using a runtime flag
    * TestModel / TestGUI apps (uses jlrdds backend)
* Dynamic profile support using DEFAULT_FASTRTPS_PROFILES.xml
    * DDS Pub/Sub Fuzzer will use the defaults specified in the profile.xml 
    * Note: This does not override the configurations set in jlrdds
* Use --help to check usage and get a brief description of supported options
* Can replace Models / HMI app to check the working of dds comms

## Usage
* All the topics listed in the "activate" section of the topic_info.json 
