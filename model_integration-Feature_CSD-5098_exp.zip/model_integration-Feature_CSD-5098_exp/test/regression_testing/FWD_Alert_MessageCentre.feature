Feature: FWD_Alert
    Scenario: Start server/clients
        When Start client for vehiclemessaging_service
        And Start server for vehicle_maintenance_service
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_FWD_ALERT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
    
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_FWD_ALERT'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
