Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for steering_wheel_switch_service
        And Start client for vehiclemessaging_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for navigation_service
        And Start server for energymanagement_service
        And Start server for charging_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    ##### Dark Theme
    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When Send notify NotifyCurrentSystemTheme
    
    ##### featureconfig -> DI_INT.gaugeSpeedometerInt.eUnit = 'MPH'   
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466},]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1} ]
        When Send response GetParamResponse
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_INITIALISATION'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RECALCULATING'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_ERROR'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_NO_CHANGE'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:        
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1000
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 700
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 350
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 0
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1023
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1024
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.DS_AEB_ACTIVATED
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    
    ##### featureconfig -> DI_INT.gaugeSpeedometerInt.eUnit = 'KMH'
    Scenario: 
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}]
        When Send response GetParamResponse

    Scenario:        
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

        Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1000
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 700
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.DS_AEB_ACTIVATED
    
    ##### Going to Navigation Mode
    Scenario: Go to Navigation mode
        When NotifyFeatureMode.feature_mode = 'ENUM_FEATURE_MODE_CLUSTER'
        And NotifyFeatureMode.status = 'ENUM_STATUS_OK'
        And NotifyFeatureMode is sent
        When NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        And wait for 200ms
        And NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        And wait for 200ms
        And NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        Then HMI shows: DI_GUI.messageCentre.DS_AEB_ACTIVATED_Navigation_MODE

    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 350
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 0
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    ##### Going to DSA Mode
    Scenario: Go to Navigation mode
        When NotifyFeatureMode.feature_mode = 'ENUM_FEATURE_MODE_CLUSTER'
        And NotifyFeatureMode.status = 'ENUM_STATUS_OK'
        And NotifyFeatureMode is sent
        When NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        And wait for 200ms
        And NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        And wait for 200ms
        And NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        Then HMI shows: DSA_MODE
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1023
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1024
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 92
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 92
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    ##### Going to Default Mode
    Scenario: Go to Navigation mode
        When NotifyFeatureMode.feature_mode = 'ENUM_FEATURE_MODE_CLUSTER'
        And NotifyFeatureMode.status = 'ENUM_STATUS_OK'
        And NotifyFeatureMode is sent
        When NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        And wait for 200ms
        And NotifyClusterControlLeftState.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyClusterControlLeftState.status = 'ENUM_STATUS_OK'
        And NotifyClusterControlLeftState is sent
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        And wait for 200ms
        And NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        And NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        And NotifyJoypadOkButtonStatus is sent
        Then HMI shows: Default_Mode

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_INITIALISATION'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RECALCULATING'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_ERROR'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_NO_CHANGE'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    

    ##### changing Theme to light
    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme
    
    ##### featureconfig -> DI_INT.gaugeSpeedometerInt.eUnit = 'MPH' 
    Scenario: 
        When restart featureconfig_cccmuserapps_service  

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466},]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1} ]
        When Send response GetParamResponse
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_INITIALISATION'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RECALCULATING'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_ERROR'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_NO_CHANGE'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:        
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1000
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 700
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 350
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 0
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1023
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1024
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.DS_AEB_ACTIVATED
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    
    ##### featureconfig -> DI_INT.gaugeSpeedometerInt.eUnit = 'KMH'
    Scenario: 
        When restart featureconfig_cccmuserapps_service

    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28466}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}]
        When Send response GetParamResponse

    Scenario:        
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 1
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

        Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1000
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 700
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 350
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 0
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1023
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1024
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent

    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI shows: DI_GUI.messageCentre.DS_AEB_ACTIVATED
    
    Scenario: 
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_AEB_ACTIVATED'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent


    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 92
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 92
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOWN'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    
    Scenario:
        When NotifyRangeOnRouteOperational.status = 'ENUM_STATUS_OK'
        When NotifyRangeOnRouteOperational.range_on_route_operational = 0
        When Send notify NotifyRangeOnRouteOperational
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_UNSPECIFIED'
        When NotifyEVRange.ev_range_kms = 500
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_UNSPECIFIED'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_INITIALISATION'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RECALCULATING'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    Scenario:
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_ERROR'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario:
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_NO_CHANGE'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 

    Scenario:
        When NotifyEVRange.status = 'ENUM_STATUS_OK'
        When NotifyEVRange.ev_range_status = 'ENUM_EV_RANGE_STATUS_RANGE_OK'
        When NotifyEVRange.ev_range_kms = 1023
        When NotifyEVRange.ev_range_trend = 'ENUM_EV_RANGE_TREND_DOUBLE_UP'
        When Send notify NotifyEVRange
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_OK'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_OK'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    #### Duty Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 
    
     Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_OK'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_OK'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''

    
