Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service
        And Start server for cockpit_settings_service
        And Start server for featureconfig_cccmuserapps_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When Send notify NotifyCurrentSystemTheme
    
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 32903}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 32903, "value" : 2}] 
        When Send response GetParamResponse

    Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 40
        When Send Request SetTSRSpeedLimitRequest
        Then HMI shows: DI_GUI.
    
    Scenario: 
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 50
        When Send Request SetTSRUpComingSpeedLimitRequest
        Then HMI shows: DI_GUI.iTSR_UpComingSignSpeedLimit
    
    Scenario: 
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send Request SetTSROverSpeedWarningRequest
        Then HMI shows: DI_GUI.bTSROverSpeedWarningStatus = FALSE
    
    Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 140
        When Send Request SetTSRSpeedLimitRequest
        Then HMI shows: DI_GUI.
    
    Scenario: 
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 100
        When Send Request SetTSRUpComingSpeedLimitRequest
        Then HMI shows: DI_GUI.iTSR_UpComingSignSpeedLimit
    
    Scenario: 
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_ON'
        When Send Request SetTSROverSpeedWarningRequest
        Then HMI shows: DI_GUI.bTSROverSpeedWarningStatus = TRUE

    #TSR Speed Limit Request
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 5
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_OFF'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit
    ## For Vienna Sign Convention
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 191
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 195
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 197
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_NONE'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA

    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 220
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 199
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 201
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_VIENNA
    
    ## For US Sign Convention
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 191
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 195
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 197
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_NONE'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US

    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 220
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 199
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 201
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_US
    

    ## For CANADA Sign Convention
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 191
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 195
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 197
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_NONE'
        When SetTSRSpeedLimitRequest.sign_speed = 200
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA

    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 220
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 199
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 201
        When SetTSRSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_SignTypeUnits.iTSR_CurrentSpeedLimit_CANADA

    #OverSpeed Limit Sign Convention(VIENNA/US/CANADA)
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == FALSE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 191
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == FALSE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 192
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == FALSE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 193
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == FALSE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 194
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == TRUE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 195
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == TRUE
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 196
        When SetTSROverSpeedWarningRequest.overspeed_warning_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRSpeedLimitRequest is sent
        When SetTSROverSpeedWarningRequest is sent
        Then HMI shows: DI_GUI.telltaleService.bTSROverSpeedWarningStatus == TRUE
    
    #TSR Upcoming Speed Limit

    ## TSR Upcoming Speed For VIENNA
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 4
        When SetTSRSpeedLimitRequest is sent
		When SetTSRUpComingSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 250
		When SetTSRUpComingSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
        
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 5
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 192
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 300
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 193
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 180
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 194
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 200
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 195
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 100
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 196
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 80
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 197
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 110
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 198
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_VIENNA
    
    ## For US Upcoming Speed
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 250
		When SetTSRUpComingSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
        
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 5
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 192
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 300
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 193
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 180
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 194
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 200
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 195
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 100
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 196
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 80
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 197
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 110
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 198
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_US

    
    ## For CANADA Upcoming Speed
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 190
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 250
		When SetTSRUpComingSpeedLimitRequest is sent
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
        
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 5
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 192
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 300
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_UNSPECIFIED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 193
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 180
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 194
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 200
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 195
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 100
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 196
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 80
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 197
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA
    
    Scenario:
        When SetTSRUpComingSpeedLimitRequest.upcoming_speed_limit_state = 'ENUM_INDICATOR_STATE_ON'
        When SetTSRUpComingSpeedLimitRequest.upcoming_sign_speed = 110
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 198
		When SetTSRUpComingSpeedLimitRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.eTSR_UpComingSign.iTSR_UpComingSignSpeedLimit_CANADA

    
    #TSR Upcoming Additional Sign

    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 20
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_UNSPECIFIED'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_UNSPECIFIED SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 30
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_OFF'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_OFF SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 40
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_TOWING'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_TOWING SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_MPH'
        When SetTSRSpeedLimitRequest.sign_speed = 50
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_DISTANCE_MILES'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_DISTANCE_MILES SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 60
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_DISTANCE_KILOMETERS'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_DISTANCE_KILOMETERS SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 70
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SEASON'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_DISTANCE_SEASON SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 80
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_TIME'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_TIME SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 90
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SNOW_ICE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SNOW_ICE SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 100
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_RAIN'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SNOW_RAIN SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 110
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_VISIBILITY'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SNOW_VISIBLITY SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.speed_limits_units = 'ENUM_TSRSPEEDLIMITUNITS_KMPH'
        When SetTSRSpeedLimitRequest.sign_speed = 120
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_LANE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SNOW_LANE SignConv_VIENNA Signtype_NUMERIC
    
        
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 130
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_LEFT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SLIP_ROAD_LEFT SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 140
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_RIGHT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_SLIP_ROAD_RIGHT SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 150
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_PROMPT SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 160
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT_ACCEPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_PROMPT_ACCEPT SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 170
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_UNMUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_UNMUTE SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 180
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_VIENNA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_VIENNA Signtype_DERESTRICTED
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.sign_speed = 200
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT_ACCEPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_PROMPT_ACCEPT SignConv_VIENNA Signtype_DERESTRICTED
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.sign_speed = 210
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_PROMPT SignConv_VIENNA Signtype_DERESTRICTED
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_OFF'
        When SetTSRSpeedLimitRequest.sign_speed = 215
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_PROMPT SignConv_VIENNA Signtype_OFF 
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_VIENNA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.sign_speed = 220
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming Additional_Sign_PROMPT SignConv_VIENNA Signtype_DASHED 
    
    Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_TOWING"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_LEFT'
        And Send request SetTSRAdditionalSignInfoRequest 

Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_TOWING"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_TOWING'
        And Send request SetTSRAdditionalSignInfoRequest 

Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_SLIP_ROAD_LEFT"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_LEFT'
        And Send request SetTSRAdditionalSignInfoRequest 
 
 
Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_SNOW_ICE"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_RIGHT'
        And Send request SetTSRAdditionalSignInfoRequest 

Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_SNOW_ICE"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SNOW_ICE'
        And Send request SetTSRAdditionalSignInfoRequest 

Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_VIENNA"
        And SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        And SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        And SetTSRSpeedLimitRequest.sign_speed = 56
        And Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_SLIP_ROAD_RIGHT"
        When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_SLIP_ROAD_RIGHT'
        And Send request SetTSRAdditionalSignInfoRequest 
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.sign_speed = 180
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming Additional_Sign_PROMPT SignConv_CANADA Signtype_DASHED 
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 170
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_UNMUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_UNMUTE SignConv_CANADA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 180
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_CANADA Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_CANADA'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_CANADA Signtype_DERESTRICTED
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DASHED'
        When SetTSRSpeedLimitRequest.sign_speed = 195
		When SetTSRAdditionalSignInfoRequest.upcoming_additional_signs = 'ENUM_TSRADDITIONALSIGN_PROMPT'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming Additional_Sign_PROMPT SignConv_US Signtype_DASHED 
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 170
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_UNMUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_UNMUTE SignConv_US Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_NUMERIC'
        When SetTSRSpeedLimitRequest.sign_speed = 180
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_US Signtype_NUMERIC
    
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = 'ENUM_TSRSIGNCONVENTION_US'
        When SetTSRSpeedLimitRequest.sign_type = 'ENUM_TSRSIGNTYPE_DERESTRICTED'
        When SetTSRSpeedLimitRequest.sign_speed = 190
		When SetTSRAdditionalSignInfoRequest.mute_unmute = 'ENUM_TSRADDITIONALSIGN_MUTE'
        When SetTSRAdditionalSignInfoRequest is sent
        When SetTSRSpeedLimitRequest is sent 
        Then HMI shows: DI_GUI.telltaleService.Upcoming_Additional_Sign_MUTE SignConv_US Signtype_DERESTRICTED
    
    Scenario: 
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_US"
        When SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        When SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        When SetTSRSpeedLimitRequest.sign_speed = 50
        When Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_MUTE"
        When Send request SetTSRAdditionalSignInfoRequest 
 
    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_US"
        When SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        When SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        When SetTSRSpeedLimitRequest.sign_speed = 60
        When Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_UNMUTE"
        And Send request SetTSRAdditionalSignInfoRequest 

    Scenario:
        When SetTSRSpeedLimitRequest.sign_convention = "ENUM_TSRSIGNCONVENTION_US"
        When SetTSRSpeedLimitRequest.sign_type = "ENUM_TSRSIGNTYPE_NUMERIC"
        When SetTSRSpeedLimitRequest.speed_limits_units = "ENUM_TSRSPEEDLIMITUNITS_UNSPECIFIED"
        When SetTSRSpeedLimitRequest.sign_speed = 60
        When Send request SetTSRSpeedLimitRequest
        When SetTSRAdditionalSignInfoRequest.current_additional_signs = "ENUM_TSRADDITIONALSIGN_SCHOOL"
        And Send request SetTSRAdditionalSignInfoRequest

    

    
    
    

    
    
    
    
    


    



    

    

    
    
    

    

    
    
