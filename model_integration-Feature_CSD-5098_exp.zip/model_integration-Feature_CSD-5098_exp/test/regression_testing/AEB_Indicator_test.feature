Feature: AEBIndicator
    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for pps_climate_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
        
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 33107}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33107, "value" : 2}]
        When Send response GetParamResponse

    Scenario:
        When NotifyVehiclePreconditionState.precondition_indicator_state = 'ENUM_PRECON_INDICATOR_STATE_ACTIVE_CABIN_VENTING'
        When NotifyVehiclePreconditionState.status = 'ENUM_STATUS_OK'
        When Send notify NotifyVehiclePreconditionState
        

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_FAULT OFF'
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.telltaleService.eAEBIndicator == 'INDICATOR_AEB_FAULT ON'

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_FAULT OFF'
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_RED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_ACTIVE OFF'

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_RED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.telltaleService.eAEBIndicator == 'INDICATOR_AEB_ACTIVE ON'
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_RED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_ACTIVE OFF'
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_GREY'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.telltaleService.eAEBIndicator == 'INDICATOR_AEB_OFF ON'

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_GREY'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_OFF OFF'
    
    Scenario:
        When NotifyVehiclePreconditionState.precondition_indicator_state = 'ENUM_PRECON_INDICATOR_STATE_INACTIVE'
        When NotifyVehiclePreconditionState.status = 'ENUM_STATUS_OK'
        When Send notify NotifyVehiclePreconditionState
        

    
    
    
        
   
