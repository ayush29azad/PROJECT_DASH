Feature: LKA Indicator

    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
        
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 33111}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 33111, "value" : 2}]
        When Send response GetParamResponse
        

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_AEB_YELLOW'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send request SetIndicatorRequest
        Then HMI shows: DI_GUI.indFlashing.eAEBIndicator == 'INDICATOR_AEB_FAULT OFF'
    
    Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_YELLOW_FAULT"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_OFF"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA

   Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_GREY_OFF"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_OFF"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA
    

   Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_RED_INTERVENING"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_ON"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA


   Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_GREY_OFF"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_ON"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA
  
  Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_YELLOW_FAULT"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_ON"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA

  Scenario: 
      When SetIndicatorRequest.indicator_type = "ENUM_INDICATOR_TYPE_LKA_YELLOW_FAULT"
      And SetIndicatorRequest.indicator_state = "ENUM_INDICATOR_STATE_OFF"
      And Send request SetIndicatorRequest
      Then HMI shows: DI_GUI.LKA
