Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for charging_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
    
    Scenario: Charging State
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 

    
    Scenario: Charging State
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    #### Duty Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
    
    Scenario: Charging State
        When NotifyChargeState.status = 'ENUM_STATUS_OK'
        When NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
