Feature: DSC Indicator

    Scenario: Start server/clients
        When Start client for telltale_service
        And Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service
    
    Scenario: Initial Values 				
        When SetDSCIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetDSCIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_UNSPECIFIED'
        When SetDSCIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bDSCInterveningInd == FALSE
    
    Scenario:Check DSC Indicator is OFF state  
        When SetDSCIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetDSCIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_ON'
        When SetDSCIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bDSCInterveningInd == FALSE
    
    
    Scenario: Check DSC Indicator is OFF state  
        When SetDSCIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDSCIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_OFF'
        When SetDSCIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bDSCInterveningInd == TRUE
    
    Scenario: Check INDICATOR DSC FLASH ON State		
        When SetDSCIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDSCIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_ON'
        When SetDSCIndicatorRequest is sent 
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bDSCInterveningInd == TRUE
    
    Scenario: Check DSC Indicator flashing is OFF state  
        When SetDSCIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetDSCIndicatorRequest.flashing_status = 'ENUM_FLASHING_STATE_UNSPECIFIED'
        When SetDSCIndicatorRequest is sent
        Then HMI Shows: DI_GUI.genericTelltalesFlash.bDSCInterveningInd == FALSE
