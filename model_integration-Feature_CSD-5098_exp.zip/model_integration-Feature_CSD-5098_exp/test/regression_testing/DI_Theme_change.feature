Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for cockpit_settings_service 
        And Start server for hmi_control_service

    Scenario:
        When NotifyHmiVisibilityStatus.status = 'ENUM_STATUS_OK'
        When NotifyHmiVisibilityStatus.hmis_visibility_status = [{'display_type' :'ENUM_DISPLAY_FDD','hmi_application': 'ENUM_HMI_APPLICATION_ANDROID_HMI','hmi_visibility_status' : 'ENUM_HMI_VISIBILITY_STATUS_VISIBLE'}]
        When NotifyHmiVisibilityStatus is sent

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme == 'LIGHT'

    Scenario:
        When NotifyHmiVisibilityStatus.status = 'ENUM_STATUS_OK'
        When NotifyHmiVisibilityStatus.hmis_visibility_status = [{'display_type' :'ENUM_DISPLAY_FDD','hmi_application': 'ENUM_HMI_APPLICATION_ANDROID_HMI','hmi_visibility_status' : 'ENUM_HMI_VISIBILITY_STATUS_VISIBLE'}]
        When NotifyHmiVisibilityStatus is sent

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme == 'DARK'

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.

    Scenario:
        When NotifyHmiVisibilityStatus.status = 'ENUM_STATUS_OK'
        When NotifyHmiVisibilityStatus.hmis_visibility_status = [{'display_type' :'ENUM_DISPLAY_FDD','hmi_application': 'ENUM_HMI_APPLICATION_ANDROID_HMI','hmi_visibility_status' : 'ENUM_HMI_VISIBILITY_STATUS_VISIBLE'}]
        When NotifyHmiVisibilityStatus is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme == 'LIGHT'

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme


    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_ERROR_INVALID_INPUT_FIELD'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyHmiVisibilityStatus.status = 'ENUM_STATUS_OK'
        When NotifyHmiVisibilityStatus.hmis_visibility_status = [{'display_type' :'ENUM_DISPLAY_FDD','hmi_application': 'ENUM_HMI_APPLICATION_ANDROID_HMI','hmi_visibility_status' : 'ENUM_HMI_VISIBILITY_STATUS_VISIBLE'}]
        When NotifyHmiVisibilityStatus is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_DARK'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme == 'DARK'
    
    Scenario:
        When NotifyHmiVisibilityStatus.status = 'ENUM_STATUS_OK'
        When NotifyHmiVisibilityStatus.hmis_visibility_status = [{'display_type' :'ENUM_DISPLAY_FDD','hmi_application': 'ENUM_HMI_APPLICATION_ANDROID_HMI','hmi_visibility_status' : 'ENUM_HMI_VISIBILITY_STATUS_VISIBLE'}]
        When NotifyHmiVisibilityStatus is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme

    Scenario:
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When NotifyCurrentSystemTheme is sent
        Then HMI shows: DI_GUI.vehicleLifecycle.eDisplayMode_Theme == 'LIGHT'
