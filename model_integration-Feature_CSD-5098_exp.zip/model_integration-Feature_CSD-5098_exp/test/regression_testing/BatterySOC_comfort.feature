Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for energymanagement_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for charging_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse

    Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_OK'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_IN_PROGRESS'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: Initial Value
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 0% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 1% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 1
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 1

    Scenario: Check 25% value and Yellow colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_1'
        When NotifyBatteryCharge.battery_state_of_charge = 25
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_YELLOW' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 25

    Scenario: Check 50% value and Colour colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 75% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 75
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 75

    Scenario: Check 99% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 99
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 99

    Scenario: Check 100% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 100
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% value and Colour colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 0% value and Red colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 110% value and Unspecified colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 110
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
       
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'        
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_NOT_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
    
     #### Duty Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_DUTY'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 
    
    
    Scenario: Check 0% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 1% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 1
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 1

    Scenario: Check 25% value and Yellow colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_1'
        When NotifyBatteryCharge.battery_state_of_charge = 25
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_YELLOW' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 25

    Scenario: Check 50% value and Colour colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 75% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 75
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 75

    Scenario: Check 99% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 99
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 99

    Scenario: Check 100% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 100
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% value and Colour colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 0% value and Red colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 110% value and Unspecified colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 110
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
       
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'        
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_NOT_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
    
    #### Comfort Mode
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When NotifyVLCAState.vehicle_state = 'ENUM_VEHICLE_STATE_COMFORT'
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 
    
    
    Scenario: Check 0% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 1% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 1
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 1

    Scenario: Check 25% value and Yellow colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_1'
        When NotifyBatteryCharge.battery_state_of_charge = 25
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_YELLOW' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 25

    Scenario: Check 50% value and Colour colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 75% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 75
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 75

    Scenario: Check 99% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 99
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 99

    Scenario: Check 100% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 100
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% value and Colour colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 0% value and Red colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 110% value and Unspecified colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 110
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
       
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'        
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_NOT_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
    
    Scenario: Charging State
        When charging_service.NotifyChargeState.status = 'ENUM_STATUS_'
        When charging_service.NotifyChargeState.charging_status = 'ENUM_CHARGE_STATE_CHARGE_COMPLETE'
        When charging_service.NotifyChargeState.charge_error_state = 'ENUM_CHARGE_ERROR_MODE_NO_ERROR'
        When charging_service.NotifyChargeState.charging_inlet_state = 'ENUM_CHARGING_INLET_STATE_PLUGGED'
        When Send notify charging_service.NotifyChargeState
        Then HMI shows: DI_GUI.displayOdometerTripComputer== ''
    
    Scenario: Check 0% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 1% value and Red colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 1
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 1

    Scenario: Check 25% value and Yellow colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_1'
        When NotifyBatteryCharge.battery_state_of_charge = 25
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_YELLOW' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 25

    Scenario: Check 50% value and Colour colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 75% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 75
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 75

    Scenario: Check 99% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 99
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 99

    Scenario: Check 100% value and Transparent Colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_TRANSPARENT'
        When NotifyBatteryCharge.battery_state_of_charge = 100
        When NotifyBatteryCharge is sent
        

    Scenario: Check 50% value and Colour colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_3'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_COLOUR' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 50

    Scenario: Check 0% value and Red colour again
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_RED' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check 110% value and Unspecified colour
        When NotifyBatteryCharge.status = 'ENUM_STATUS_OK'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 110
        When NotifyBatteryCharge is sent
        Then HMI shows: DI_GUI.batteryStateOfChargeDisp.eBatteryStateOfCharge_Colour == 'BATTERY_SOC_COLOUR_NORMAL' DI_GUI.batteryStateOfChargeDisp.iBatteryStateOfCharge_Value == 0

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_UNSPECIFIED'
        When NotifyBatteryCharge.battery_state_of_charge = 0
        When NotifyBatteryCharge is sent

    Scenario: Check 50% and Red colour request ignored, no change so no topic received
        When NotifyBatteryCharge.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

    Scenario: Check status change
        When NotifyBatteryCharge.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyBatteryCharge.batt_level_colour = 'ENUM_BATT_LEVEL_COLOUR_2'
        When NotifyBatteryCharge.battery_state_of_charge = 50
        When NotifyBatteryCharge is sent

  
    
    

        
