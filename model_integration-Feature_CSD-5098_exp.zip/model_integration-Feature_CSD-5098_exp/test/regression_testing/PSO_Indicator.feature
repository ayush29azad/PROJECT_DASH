Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start client for telltale_service
    
    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_UNSPECIFIED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetIndicatorRequest is sent
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_RIGHT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_RIGHT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_LEFT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_CURVE_LEFT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TJUNCTION_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TJUNCTION_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TJUNCTION_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TJUNCTION_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_XJUNCTION_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_XJUNCTION_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_XJUNCTION_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_XJUNCTION_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_ROUNDABOUT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_RIGHT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_RIGHT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO

    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_LEFT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_LEFT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_TURN_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_LEFT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_AVAILABLE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_EXIT_RIGHT_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_HILLS_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_HILLS_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_GENERAL_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_GENERAL_ACTIVE'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_GENERAL_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_GENERAL_SUSPENDED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_FAULT'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO
    
    Scenario: 
        When SetIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_PSO_UNSUPPORTED'
        When SetIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When SetIndicatorRequest is sent
        Then HMI shows: DI_GUI.PSO

    
