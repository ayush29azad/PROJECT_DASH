Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_service
        And Start client for telltale_service

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING' 
    
    Scenario: combinedADASIndicatorStatic.eL2Feedback_ODD_Indicators
        When SetCombinedIndicatorRequest.acc_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.acc_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.acc_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_UNSPECIFIED'   
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_UNSPECIFIED'   
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_UNSPECIFIED'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.default_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_UNSPECIFIED'
        When SetCombinedIndicatorRequest.lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest.lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_UNSPECIFIED'
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode
        When Send NotifyHDCMode 
        Then HMI shows: DI_INT.indATPCInt

    Scenario:DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_OFF'
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_OFF'  																				   																																				   
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_L2'																							 																							   																									  																					 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'  																								  													
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:(DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_L2' & lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF')
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_OFF'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_OFF'
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 0
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_CANCALLED'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_DCR'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_DCR'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_ACTIVE_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_NOTFLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 998
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_ACTIVE_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_STANDBY'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_SEARCH_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LANE_CROSS'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LANE_CROSS'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_SEARCH_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 0
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_CANCALLED'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 998
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_ACTIVE_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_ACTIVE_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_SEARCH_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_SEARCH_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_OFF'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
