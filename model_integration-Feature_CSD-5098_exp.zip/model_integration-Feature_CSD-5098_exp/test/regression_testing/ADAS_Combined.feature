Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_service
        And Start client for telltale_service

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING'

        
    Scenario:
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode
        When Send NotifyHDCMode 
        Then HMI shows: DI_INT.indATPCInt

    Scenario:DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_OFF'
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_OFF' 
        When SetCombinedIndicatorRequest.set_speed_value = 999 																				   																																				   
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_HFE'																							 																							   																									  																					 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.set_speed_value = 999  																								  													
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:																							 																							   																									  																					 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_OFF'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF' 	
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 999 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario: (DEFL_MODE_INDICATOR = 'ENUM_MODE_TYPE_HFE' & DEFL_DCR_ON = 'ENUM_INDICATOR_STATE_ON' & lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF')																						 																							   																									  																					 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_OFF' 	
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_OFF'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 999 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 20
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 990
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'  					
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'     
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 1001
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic


#L2 Mode
 Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_NOTFLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 0
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_CANCALLED'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_DCR'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_DCR'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_ACTIVE_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_NOTFLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 998
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_ACTIVE_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_STANDBY'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_SEARCH_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LANE_CROSS'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LANE_CROSS'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_SEARCH_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 0
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_CANCALLED'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 998
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_ACTIVE_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_ACTIVE_HW1'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 999
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_ACTIVE_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic
    
    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_SEARCH_BLINK_STATE1'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW3'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_RIGHT_SEARCH_BLINK_STATE2'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_NOTDETECTED_STANDBY_HW2'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ELKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY'
        When SetCombinedIndicatorRequest.set_speed_value = 1000
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

    Scenario:
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_LKA'
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'
        When SetCombinedIndicatorRequest.set_speed_value = 50
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.combinedADASIndicatorStatic

##LIM Cruise Indicator
 Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test11'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test12'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test13'
    

        Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test111'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test112'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test113'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test21'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test22'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test23'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_CRUISE)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_CRUISE'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test1'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_FAULT_CRUISE)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_FAULT_CRUISE'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test2'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test3'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_FAULT_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_FAULT_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test4'


    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 600 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_CENTRE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 700 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_CENTRE_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 800 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 900 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 50 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 51 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
