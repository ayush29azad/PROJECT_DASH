Feature:
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for energymanagement_service
        And Start server for motion_service
        And Start client for telltale_service
        And Start server for cockpit_settings_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
        When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
        When Send response GetVLCAStateResponse

    Scenario: 
        When NotifyCurrentSystemTheme.status = 'ENUM_STATUS_OK'
        When NotifyCurrentSystemTheme.current_system_theme = 'ENUM_CURRENT_THEME_LIGHT'
        When Send notify NotifyCurrentSystemTheme

    Scenario:
        When NotifyPowertrainReadyStatus.powertrain_ready_status = 'ENUM_PTSTATUS_READY_TO_DRIVE'
        When NotifyPowertrainReadyStatus.status = 'ENUM_STATUS_OK'
        When Send Notify NotifyPowertrainReadyStatus
        Then HMI shows: DI_GUI. READY indicator

    Scenario:
        When NotifyAutoHoldFunctionActive.vehicle_hold_status = 'ENUM_VEHICLE_HOLD_STATUS_AUTOHOLD_ACTIVE'
        When NotifyAutoHoldFunctionActive.status = 'ENUM_STATUS_OK'
        When Send Notify NotifyAutoHoldFunctionActive
        Then HMI shows: DI_GUI. READY indicator and HOLD indicator

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI. READY indicator, HOLD indicator, and show no Eco Driving telltale 

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI. READY indicator, HOLD indicator, and show no Eco Driving telltale 

    Scenario:
        When NotifyAutoHoldFunctionActive.vehicle_hold_status = 'ENUM_VEHICLE_HOLD_STATUS_AUTOHOLD_INACTIVE'
        When NotifyAutoHoldFunctionActive.status = 'ENUM_STATUS_OK'
        When Send Notify NotifyAutoHoldFunctionActive
        Then HMI shows: DI_GUI. HOLD indicator 

    Scenario:
        When NotifyPowertrainReadyStatus.powertrain_ready_status = 'ENUM_PTSTATUS_PT_NOT_READY'
        When NotifyPowertrainReadyStatus.status = 'ENUM_STATUS_OK'
        When Send Notify NotifyPowertrainReadyStatus
        Then HMI shows: DI_GUI. READY indicator 

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_GRADIENT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI. Lift off not pressed telltale with driving scenario gradient 

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_GRADIENT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI. Lift off not pressed telltale with driving scenario gradient 

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI. Lift off pressed telltale with driving scenario gradient 

    Scenario:
        When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
        When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
        When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF'
        When Send Request SetEcoDrivingCoachIndicatorRequest
        Then HMI shows: DI_GUI.Lift off pressed telltale with driving scenario gradient 
