Feature: pt_runDry_xHEV_userWarning

	Scenario: Start server/clients
		When Start server for lifecycle_cccmuserapps_vlca_service
		And Start server for xhev_range_service
		And start client for vehiclemessaging_service
		And Start server for featureconfig_cccmuserapps_service

	Scenario: 
		Given Receive request GetParamRequest
		And GetParamRequest.params == [{"mdf_id" : 28466}]
		When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}]
		When Send response GetParamResponse
	
	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service
	
	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 0}
		When Send response GetRangeInfoResponse

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service

	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2047}
		When Send response GetRangeInfoResponse
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2047

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service
	
	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2048}
		When Send response GetRangeInfoResponse

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service
	
	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 100}
		When Send response GetRangeInfoResponse
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 100


	Scenario:
		When restart featureconfig_cccmuserapps_service
	
	Scenario:
		Given Receive request GetParamRequest
		And GetParamRequest.params == [{"mdf_id" : 28466},]
		When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1} ]
		When Send response GetParamResponse

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service

	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 1609}
		When Send response GetRangeInfoResponse
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined == [1609, 1000]

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service
	
	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 1609}
		When Send response GetRangeInfoResponse
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 1609

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When restart xhev_range_service
	
	Scenario:
		Given Receive request GetRangeInfoRequest
		When GetRangeInfoResponse.status = "ENUM_STATUS_OK"
		When GetRangeInfoResponse.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2000}
		When Send response GetRangeInfoResponse
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2000

	Scenario:
		When restart featureconfig_cccmuserapps_service

	Scenario:
		Given Receive request GetParamRequest
		And GetParamRequest.params == [{"mdf_id" : 28466}]
		When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}]
		When send response GetParamResponse
	
	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2047}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2047

	Scenario:
		When restart featureconfig_cccmuserapps_service
	
	Scenario:
		Given Receive request GetParamRequest
		And GetParamRequest.params == [{"mdf_id" : 28466}]
		When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 2}]
		When send response GetParamResponse

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 100}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 100

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2000}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2000

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2047}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2047

	Scenario:
		When restart featureconfig_cccmuserapps_service
	
	Scenario:
		Given Receive request GetParamRequest
		And GetParamRequest.params == [{"mdf_id" : 28466}]
		When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28466, "value" : 1}]
		When send response GetParamResponse

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 1609}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined == [1609, 1000]

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 100}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 100

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2000}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2000

	Scenario:
		When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_BATTERY_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
		Then HMI Shows: Warning message (New state)
	
	Scenario:
		When NotifyRangeInfo.status = "ENUM_STATUS_OK"
		When NotifyRangeInfo.batt_fuel_range_info = {"status": "ENUM_STATUS_OK", "battery_fuel_range_status": "ENUM_RANGE_STATUS_OK", "battery_fuel_range_kms": 2047}
		When Send notify NotifyRangeInfo
		Then HMI shows: DI_GUI.messageCentreData.iRangeCombined = 2047
