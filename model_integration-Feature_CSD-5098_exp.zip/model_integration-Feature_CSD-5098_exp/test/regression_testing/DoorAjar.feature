Feature:
    Scenario: Start server/clients
        When start server for pps_apertures_service
        When start server for steering_wheel_switch_service
        When start client for vehiclemessaging_service
        When start server for featureconfig_cccmuserapps_service

    Scenario: 
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 551}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 551, "value" : 1} ]
        When GetParamResponse is sent

     Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_DOORS_OPEN_MAJOR'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When Send request SetWarnMsgRequest
        Then HMI shows: screenshot
   
    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.driver_door_status = 'ENUM_DRIVER_DOOR_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot

    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.passenger_door_status = 'ENUM_PASSENGER_DOOR_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot

    
    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.driver_rear_door_status = 'ENUM_DRIVER_REAR_DOOR_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot

    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.passenger_rear_door_status = 'ENUM_PASSENGER_REAR_DOOR_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot

    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.tailgate_status = 'ENUM_TAILGATE_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot
    
    Scenario:
        When NotifyDoorOpenCloseStatus.status = 'ENUM_STATUS_OK'
        When NotifyDoorOpenCloseStatus.bonnet_status = 'ENUM_BONNET_STATUS_OPEN'
        When NotifyDoorOpenCloseStatus is sent
        Then HMI shows: screenshot
    
    Scenario:
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_DOORS_OPEN_MAJOR'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When Send request SetWarnMsgRequest
        Then HMI shows: screenshot

    Scenario:
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_PRESSED'
        When NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        When NotifyJoypadOkButtonStatus is sent
        Then HMI shows: screenshot

    Scenario:
        When NotifyJoypadOkButtonStatus.button_state = 'ENUM_JOYPAD_STATUS_RELEASED'
        When NotifyJoypadOkButtonStatus.status = 'ENUM_STATUS_OK'
        When NotifyJoypadOkButtonStatus is sent
        Then HMI shows: screenshot
