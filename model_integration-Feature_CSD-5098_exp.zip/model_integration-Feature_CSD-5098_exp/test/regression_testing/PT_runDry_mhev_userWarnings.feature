Feature:

    Scenario: Start server/clients
        When Start server for propulsion_service
        And Start client for vehiclemessaging_service



    Scenario: Warning Message is in NEW state
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_ON'
        When SetWarnMsgRequest is sent
        Then HMI Shows: Warning message (New state)

    Scenario: Check NotifyFuelRangeInfo
        When NotifyFuelRangeInfo.fuel_range_status = 'ENUM_FUEL_RANGE_STATUS_OK'
        When NotifyFuelRangeInfo.fuel_range_kms = 0
        When NotifyFuelRangeInfo.status = 'ENUM_STATUS_OK'
        When Send notify NotifyFuelRangeInfo
        Then HMI shows: screenshot 1

    Scenario: Check NotifyFuelRangeInfo
        When NotifyFuelRangeInfo.fuel_range_status = 'ENUM_FUEL_RANGE_STATUS_OK'
        When NotifyFuelRangeInfo.fuel_range_kms = 1022
        When NotifyFuelRangeInfo.status = 'ENUM_STATUS_OK'
        When Send notify NotifyFuelRangeInfo
        Then HMI shows: screenshot 2

    Scenario: Check NotifyFuelRangeInfo
        When NotifyFuelRangeInfo.fuel_range_status = 'ENUM_FUEL_RANGE_STATUS_OK'
        When NotifyFuelRangeInfo.fuel_range_kms = 1025
        When NotifyFuelRangeInfo.status = 'ENUM_STATUS_OK'
        When Send notify NotifyFuelRangeInfo
        Then HMI shows: screenshot 3
    
    Scenario: Check NotifyFuelRangeInfo
        When NotifyFuelRangeInfo.fuel_range_status = 'ENUM_FUEL_RANGE_STATUS_OK'
        When NotifyFuelRangeInfo.fuel_range_kms = 1022
        When NotifyFuelRangeInfo.status = 'ENUM_STATUS_OK'
        When Send notify NotifyFuelRangeInfo
        Then HMI shows: screenshot 4 

    Scenario: Warning Message is in NEW state
        When SetWarnMsgRequest.msg_id = 'ENUM_MSG_HYBRID_FUEL_LOW_MID'
        When SetWarnMsgRequest.request = 'ENUM_REQUEST_OFF'
        When SetWarnMsgRequest is sent
        Then HMI Shows: Warning message (New state)
