Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_setting_service
        And Start server for steering_wheel_switch_service
        And Start server for cockpit_settings_service
        And Start server for propulsion_service
	    

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_CUSTOM_ACTIVE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_CUSTOM_AVAILABLE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE
    
    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_ENHANCED_ACTIVE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_ENHANCED_AVAILABLE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_COMFORT'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_COMFORT"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_COMFORT' 

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_CUSTOM_ACTIVE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_CUSTOM_AVAILABLE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE
    
    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_ENHANCED_ACTIVE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_ENHANCED_AVAILABLE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == TRUE
    
    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_STATE_DUTY'
        When NotifyVLCAState.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When NotifyVLCAState.vehicle_state = "ENUM_VEHICLE_STATE_DUTY"
        When Send notify NotifyVLCAState
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_STATE_DUTY' 

    Scenario: 
        When NotifyDriverAssistanceModeConfiguratorStatus.status = 'ENUM_STATUS_OK'
        When NotifyDriverAssistanceModeConfiguratorStatus.dam_configurator_mode_state = 'ENUM_DAM_CONFIGURATOR_STATE_ENHANCED_AVAILABLE'
        When Send notify NotifyDriverAssistanceModeConfiguratorStatus
        Then HMI shows: DI_GUI.transDriverAssistanceMode.vTransDriverAssistanceMode == FALSE
    

    
