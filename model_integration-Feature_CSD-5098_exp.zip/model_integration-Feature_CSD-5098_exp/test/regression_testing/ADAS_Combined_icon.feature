Feature:

    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for motion_service
        And Start client for telltale_service

    Scenario: Set Vehicle_State = 'ENUM_VEHICLE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_VEHICLE_RUNNING'

    Scenario: Cruise Icon Blinking (ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_ACC'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON' 
        When SetCombinedIndicatorRequest.acc_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_ACTIVE'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.acc_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.acc_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_value = 100  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_active_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE' 
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 200 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_active_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 300 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_active_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE' 
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_FLASHING'  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 400 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_active_overspeed == 'SET_SPEED_ACTIVE_STATE1'
    

    Scenario: Cruise Icon Blinking (ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY_OVERSPEED)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_ACC' 
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON' 
        When SetCombinedIndicatorRequest.acc_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_ACTIVE'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.acc_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.acc_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_value = 100  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY_OVERSPEED'
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_standby_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON' 
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 200 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_standby_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_L2' 
        When SetCombinedIndicatorRequest.l2_feedback_state_ind = 'ENUM_L2_FEEDBACK_ACTIVE_LEFT_FAULT'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_STANDBY_FLASHING'
        When SetCombinedIndicatorRequest.hfe_l2_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW4'
        When SetCombinedIndicatorRequest.l2_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.l2_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'  
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 300 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_standby_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: 
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_HFE'  
        When SetCombinedIndicatorRequest.dcr_ind = 'ENUM_INDICATOR_STATE_ON'
        When SetCombinedIndicatorRequest.hfe_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.hfe_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.hfe_hands_on_off_state_ind = 'ENUM_HFE_INDICATOR_HANDS_ON_LEFT_FAULT'
        When SetCombinedIndicatorRequest.acc_headway_ind = 'ENUM_HEADWAY_INDICATOR_TYPE_DETECTED_ACTIVE_HW3'
        When SetCombinedIndicatorRequest.alc_odd_ind = 'ENUM_ALC_STATE_OD_INDICATOR_ACTIVE_FLASHING' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_STANDBY_OVERSPEED'
        When SetCombinedIndicatorRequest.set_speed_value = 400 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eSetSpeed_standby_overspeed == 'SET_SPEED_ACTIVE_STATE1'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test11'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_2'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_2'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test12'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_FULL_FUNCTION_COLOUR_3'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test13'
    

        Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test111'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_2'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_2'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test112'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_ATPC_DESCENT_CONTROL_COLOUR_3'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test113'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_1'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_1'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test21'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_2'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_2'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test22'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_OFF'
        When SetCombinedIndicatorRequest.set_speed_value = 500
        When NotifyATPCMode.status = 'ENUM_STATUS_OK'
        When NotifyATPCMode.atpc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        When NotifyATPCMode.atpc_set_speed_value = 31
        When NotifyHDCMode.status = 'ENUM_STATUS_OK'
        When NotifyHDCMode.hdc_indicate_colour = 'ENUM_OFFROAD_DRIVERASSISTANCE_INDICATION_HDC_COLOUR_3'
        When NotifyHDCMode.hdc_set_speed_value = 31
        When Send NotifyATPCMode 
        When Send NotifyHDCMode 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test23'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_CRUISE)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_CRUISE'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test1'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_FAULT_CRUISE)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_FAULT_CRUISE'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test2'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test3'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_FAULT_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_FAULT_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'Test4'


    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 500 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_RIGHT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 600 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_CENTRE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 700 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_CENTRE_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 800 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'

    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 900 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
    
    Scenario: Cruise Icon Blinking (ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM)
        When SetCombinedIndicatorRequest.mode = 'ENUM_MODE_TYPE_LIM_CRUISE'
        When SetCombinedIndicatorRequest.cruise_ego_vehicle_ind = 'ENUM_EGO_VEHICLE_STATE_INDICATOR_LEFT_INACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_left_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE'
        When SetCombinedIndicatorRequest.cruise_lss_right_lane_ind = 'ENUM_LINE_INDICATOR_TYPE_ACTIVE' 
        When SetCombinedIndicatorRequest.set_speed_state_ind = 'ENUM_SET_SPEED_STATE_TYPE_INDICATOR_ACTIVE_OVERSPEED'  
        When SetCombinedIndicatorRequest.cruise_icons_ind = 'ENUM_CRUISE_STATUS_INDICATOR_ACTIVE_OVER_SPEED_LIM'
        When SetCombinedIndicatorRequest.set_speed_value = 901 
        When SetCombinedIndicatorRequest is sent
        Then HMI shows: DI_GUI.genericTelltalesFlash.eLimiter_IND == 'LIMITER_IND_STATE1'
