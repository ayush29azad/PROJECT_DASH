Feature:

Scenario: Start server/clients
When Start server for lifecycle_cccmuserapps_vlca_service
And Start client for telltale_service

Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
Given Receive request GetVLCAStateRequest
When GetVLCAStateResponse.vlca_state = 'ENUM_VLCA_STATE_UNSPECIFIED'
When GetVLCAStateResponse.vehicle_mode = 'ENUM_VEHICLE_MODE_UNSPECIFIED'
When GetVLCAStateResponse.vehicle_state = 'ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL'
When Send response GetVLCAStateResponse

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_UNSPECIFIED'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_UNSPECIFIED'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_OFF'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_LEFT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_RIGHT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_ROUNDABOUT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_JUNCTION'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_CAR_AHEAD'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_GRADIENT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_UNSPECIFIED'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_OFF'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_OFF'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService


Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_SPEED_LIMIT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_LEFT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_LEFT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_RIGHT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_RIGHT_CORNER'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_ROUNDABOUT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_ROUNDABOUT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_JUNCTION'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_JUNCTION'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_CAR_AHEAD'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_OFF' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_CAR_AHEAD'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON'
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_GRADIENT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService

Scenario:
When SetEcoDrivingCoachIndicatorRequest.indicator_type = 'ENUM_INDICATOR_TYPE_ECO_DRIVING_LIFT_OFF_NOT_PRESSED'
When SetEcoDrivingCoachIndicatorRequest.indicator_state = 'ENUM_INDICATOR_STATE_ON' 
When SetEcoDrivingCoachIndicatorRequest.eco_driving_scenario = 'ENUM_ECO_DRIVING_SCENARIO_GRADIENT'
When SetEcoDrivingCoachIndicatorRequest is sent
Then HMI shows: DI_GUI.telltaleService
