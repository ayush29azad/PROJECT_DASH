Feature: RWS Indicator
    Scenario: Start server/clients
        When Start server for lifecycle_cccmuserapps_vlca_service
        And Start server for featureconfig_cccmuserapps_service
        And Start server for steering_service

    Scenario: Set Vehicle_State = 'ENUM_STATE_RUNNING'
        Given Receive request GetVLCAStateRequest
        When GetVLCAStateResponse.vlca_state = "ENUM_VLCA_STATE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_mode = "ENUM_VEHICLE_MODE_UNSPECIFIED"
        When GetVLCAStateResponse.vehicle_state = "ENUM_VEHICLE_STATE_RUNNING_FULL_INSTALL"
        When Send response GetVLCAStateResponse
        Then HMI Shows: DI_GUI.vehicleLifecycleInt.eVehicle_State = 'ENUM_STATE_RUNNING' 
        
    Scenario:
        Given Receive request GetParamRequest
        And GetParamRequest.params == [{"mdf_id" : 28791}]
        When GetParamResponse.params = [ {"mdf_status" : "ENUM_STATUS_MDFID_OK", "mdf" : 28791, "value" : 2}]
        When Send response GetParamResponse
     
    Scenario: indicator ENUM_RWS_STATUS_STUCK_AT_ANGLE
        When NotifyRWSStatus.status = 'ENUM_STATUS_OK'
        When NotifyRWSStatus.rear_wheel_status = 'ENUM_RWS_STATUS_STUCK_AT_ANGLE'
        When NotifyRWSStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bEpasIndMajor_IsOn == TRUE_DI_GUI.miscTelltales.bEpasIndMinor_IsOn == FALSE


    Scenario: indicator ENUM_RWS_STATUS_STUCK_AT_ZERO
        When NotifyRWSStatus.status = 'ENUM_STATUS_OK'
        When NotifyRWSStatus.rear_wheel_status = 'ENUM_RWS_STATUS_STUCK_AT_ZERO'
        When NotifyRWSStatus is sent
        Then HMI Shows: DI_GUI.miscTelltales.bEpasIndMajor_IsOn == FALSE_DI_GUI.miscTelltales.bEpasIndMinor_IsOn == TRUE

    Scenario: indicator ENUM_RWS_STATUS_ERROR
        When NotifyRWSStatus.rear_wheel_status = 'ENUM_RWS_STATUS_ERROR'
        When NotifyRWSStatus is sent
        Then HMI Shows: topic DI_GUI.miscTelltales is received 1 times since it was last checked
        Then HMI Shows: DI_GUI.miscTelltales.bEpasIndMajor_IsOn == FALSE_DI_GUI.miscTelltales.bEpasIndMinor_IsOn == FALSE

    Scenario: status change
        When NotifyRWSStatus.status = 'ENUM_STATUS_DATA_UNRELIABLE'
        When NotifyRWSStatus is sent         

    Scenario: indicator ENUM_STATUS_UNSPECIFIED
        When NotifyRWSStatus.status = 'ENUM_STATUS_UNSPECIFIED'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_DATA_DEGRADED
        When NotifyRWSStatus.status = 'ENUM_STATUS_DATA_DEGRADED'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_DATA_UNAVAILABLE
        When NotifyRWSStatus.status = 'ENUM_STATUS_DATA_UNAVAILABLE'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_ERROR_INVALID_SERVICE_STATE
        When NotifyRWSStatus.status = 'ENUM_STATUS_ERROR_INVALID_SERVICE_STATE'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE
        When NotifyRWSStatus.status = 'ENUM_STATUS_ERROR_INVALID_VEHICLE_STATE'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION
        When NotifyRWSStatus.status = 'ENUM_STATUS_ERROR_INVALID_CAR_CONFIGURATION'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_ERROR_MISSING_INPUT_FIELD
        When NotifyRWSStatus.status = 'ENUM_STATUS_ERROR_MISSING_INPUT_FIELD'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_ERROR_INVALID_INPUT_FIELD
        When NotifyRWSStatus.status = 'ENUM_STATUS_ERROR_INVALID_INPUT_FIELD'
        When NotifyRWSStatus is sent

    Scenario: indicator ENUM_STATUS_NOT_OK
        When NotifyRWSStatus.status = 'ENUM_STATUS_NOT_OK'
        When NotifyRWSStatus is sent
    
