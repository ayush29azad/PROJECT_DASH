#include "PyWrapper.hpp"

// todo : error handling

void di::mockval::PyWrapper::set_python_path(std::string path)
{
  std::wstring wpath = std::wstring(path.begin(), path.end());
  wchar_t const* path_ = wpath.c_str();
  PySys_SetPath(path_);
}

PyObject* di::mockval::PyWrapper::import_module(std::string module)
{
  if (this->modules.find(module) != this->modules.end())
    return modules[module];

  PyObject* moduleString = PyUnicode_FromString(module.c_str());
  PyObject* moduleObject = PyImport_Import(moduleString);

  return modules[module] = moduleObject;
}

PyObject* di::mockval::PyWrapper::get_function(std::string function, PyObject* module)
{
  if (this->functions.find(function) != functions.end())
    return functions[function];

  PyObject* functionObject = PyObject_GetAttrString(module, (char*)"main");
  return functions[function] = functionObject;
}

PyObject* di::mockval::PyWrapper::get_args(std::string args)
{
  PyObject* argObject = PyTuple_Pack(1, PyUnicode_FromString(args.c_str()));
  return argObject;
}

PyObject* di::mockval::PyWrapper::call_function1(PyObject* function, PyObject* args)
{
  PyObject* result = PyObject_CallObject(function, args);
  return result;
}

std::string di::mockval::PyWrapper::call_function1_from_module(
    std::string module, std::string function_name, std::string arg)
{

  PyObject* moduleObject = this->import_module(module);
  PyObject* functionObject = this->get_function(function_name, moduleObject);
  PyObject* argObject = this->get_args(arg);
  PyObject* responseObject = this->call_function1(functionObject, argObject);

  std::string responseString = PyUnicode_AsUTF8(responseObject);

  return responseString;
}

void di::mockval::PyWrapper::destroy()
{
  Py_Finalize();
}
