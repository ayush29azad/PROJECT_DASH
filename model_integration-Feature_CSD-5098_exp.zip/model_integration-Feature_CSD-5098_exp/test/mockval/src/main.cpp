#include <iostream>
#include <someip.hpp>
#include <GlobalFunctors.hpp>
#include <ServiceInitializer.hpp>
#include <ServiceDefinitionParser.hpp>
#include <InputJsonParser.hpp>
#include <SupportedEvents.hpp>
#include <PyWrapper.hpp>

bool isJsonFile(std::string filepath)
{
  return filepath.substr(filepath.find_last_of(".") + 1) == "json";
}

int main(int argc, char* argv[])
{

  // Argument parsing
  if (argc != 3 && argc != 4)
  {
    std::cout << "[Error]: Invalid number of argumets provided" << std::endl;
    return 0;
  }

  std::string serviceDefFilepath = argv[1];
  std::cout << "[Info]: Service definition file provided : " << serviceDefFilepath << std::endl;

  std::string inputDataFilepath = argv[2];
  std::cout << "[Info]: Input data file provided : " << inputDataFilepath << std::endl;

  if (!isJsonFile(serviceDefFilepath))
  {
    std::cout << "[Error]: Incorrect filetype - service definition json" << std::endl;
    return 0;
  }

  if (!isJsonFile(inputDataFilepath))
  {
    std::cout << "[Error]: Incorrect filetype - input data json" << std::endl;
    return 0;
  }

  if (argc == 4)
  {

    std::string full_path(argv[3]);
    std::string directory;
    std::string logic_filename;

    size_t const last_slash_idx = full_path.rfind('/');
    if (std::string::npos != last_slash_idx)
    {
      directory = full_path.substr(0, last_slash_idx);
      logic_filename = full_path.substr(last_slash_idx + 1, full_path.size());
    }
    else
    {
      directory = ".";
      logic_filename = full_path;
    }

    std::cout << "[Info]: using python logic directory : " << directory << std::endl;
    std::cout << "[Info]: using python logic filename : " << logic_filename << std::endl;

    di::mockval::PyWrapper::get_instance().set_python_path(directory);
    std::cout << "[Info]: using python path : " << directory << std::endl;

    std::string module_name = "";
    size_t const last_dot_idx = logic_filename.rfind('.');
    if (std::string::npos != last_dot_idx)
    {
      module_name = logic_filename.substr(0, last_dot_idx);
    }
    else
    {
      std::cout << "[Error]: Inappropriate python logic file" << std::endl;
    }

    di::mockval::data::GlobalTables::get_instance().response_module_path = module_name;
  }

  // Initialization for supported events
  di::mockval::data::init();

  // Input value json parsing
  di::mockval::InputJsonParser inputParser(inputDataFilepath);

  auto initialData = inputParser.get_initial_data();
  auto inputList = inputParser.get_input_data();
  auto mappingList = inputParser.get_mapping_data();

  // Request-Response pair storage
  for (auto& el : mappingList)
  {

    std::string requestEvent = el.requestData.messageName;
    std::string requestValue = el.requestData.messageDict;

    std::string responseEvent = el.responseData.messageName;
    std::string responseValue = el.responseData.messageDict;

    std::string requestProtoString =
        di::mockval::data::GlobalTables::get_instance().mJsonToPbMapping[requestEvent](requestValue);
    std::string responseProtoString =
        di::mockval::data::GlobalTables::get_instance().mJsonToPbMapping[responseEvent](responseValue);

    di::mockval::data::GlobalTables::get_instance().mRequestResponseMapping[requestProtoString] = responseProtoString;
  }

  // Initial data Storage
  for (auto& el : initialData)
  {

    if (di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs.find(el.messageName) !=
        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs.end())
    {
      auto msg = di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[el.messageName];

      di::mockval::data::GlobalTables::get_instance().error_msg = "";
      pbjson::json2pb(el.messageDict, msg.get(), di::mockval::data::GlobalTables::get_instance().error_msg);
      if (di::mockval::data::GlobalTables::get_instance().error_msg.size() > 0)
      {
        std::cout << "[Error]: Error converting initial value from json to pb - " << el.messageName << std::endl;
      }

      di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[el.messageName] = msg;
    }
    else
    {
      std::cout << "[Error]: Initial object for the event not found - " << el.messageName << std::endl;
    }
  }

  std::cout << "[Info]: Setting initial values succeded" << std::endl;

  // Service definition json parsing
  di::mockval::ServiceDefinitionParser defParser(serviceDefFilepath);
  auto services = defParser.get_services();

  // Initializing services and start vsomeip app
  auto app = std::make_shared<JLR::someip::Application>(serviceDefFilepath);
  app->init();

  for (auto& service : services)
  {
    di::mockval::ServiceInitializer::init(service, app);
  }

  app->start();

  // {
  //     sws_service::NotifyClusterControlLeftState n;
  //     n.set_status(sws_service::EnumStatus::ENUM_STATUS_ERROR_INVALID_SERVICE_STATE);
  //     google::protobuf::Message* m = &n;
  //     std::cout << "=================" <<std::endl;
  //     std::cout  << m->DebugString() << std::endl;
  //     std::cout << "=================" <<std::endl;
  // }

  // The flow control
  while (1)
  {

    int inputList_size = inputList.size();
    if (!inputList_size)
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(1000));
      continue;
    }

    for (auto& el : inputList)
    {

      bool isTobeSent = di::mockval::data::GlobalTables::get_instance().mIsToBeSentMap[el.messageName];

      std::string str_data =
          di::mockval::data::GlobalTables::get_instance().mJsonToPbMapping[el.messageName](el.messageDict);
      di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[el.messageName]->ParseFromString(str_data);

      if (!isTobeSent)
      {
        continue;
      }

      di::mockval::data::GlobalTables::get_instance().mSendFunctors[el.messageName](str_data);

      std::cout << "[Info]: Sent message : " << el.messageName << std::endl;
      std::cout << el.messageDict << std::endl;
      std::cout << "[Info]: wait period : " << el.timePeriod << std::endl << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(el.timePeriod));
    }
  }
}
