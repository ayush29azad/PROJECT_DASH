#include <iostream>
#include <rapidjson/document.h>
#include <rapidjson/filereadstream.h>
#include <rapidjson/stringbuffer.h>
#include <pbjson/pbjson.hpp>
#include <google/protobuf/message.h>
#include <vehiclespeed_service.pb.h>
#include <map>

using namespace vehiclespeed_service;

int main()
{

  std::map<std::string, google::protobuf::Message*> mpp;

  NotifyVehicleSpeed data;
  data.set_vehicle_speed_raw(10);
  data.set_vehicle_speed_tyre_size_corr(1);
  data.set_vehicle_speed_market_bias_corr(1);
  data.set_status(ENUM_STATUS_OK);

  std::string strJson;
  mpp["NotifyVehicleSpeed"] = &data;

  pbjson::pb2json(mpp["NotifyVehicleSpeed"], strJson);

  std::cout << strJson << std::endl;
  return 0;
}
