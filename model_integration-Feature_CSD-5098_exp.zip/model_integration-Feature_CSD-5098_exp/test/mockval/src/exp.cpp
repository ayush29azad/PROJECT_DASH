#include <iostream>
#include <rapidjson/document.h>
#include <rapidjson/filereadstream.h>
#include <rapidjson/stringbuffer.h>
#include <pbjson/pbjson.hpp>
#include <vehiclespeed_service.pb.h>

using namespace vehiclespeed_service;

int main()
{

  std::string filename = "/home/ravi/workspace/someip_boilerplate/exp/model_integration/mockval/tests/test.json";

  char readBuffer[65536];
  rapidjson::Document mDocument;

  FILE* fp = fopen(filename.c_str(), "rb");

  if (!fp)
  {
    std::cerr << "[Error]: unable to open file" << std::endl;
  }

  rapidjson::FileReadStream fileReadStream(fp, readBuffer, sizeof(readBuffer));
  mDocument.ParseStream(fileReadStream);

  if (mDocument.HasParseError())
  {
    std::cerr << "[Error]: failed to parse ServiceJson document" << std::endl;
  }

  fclose(fp);

  std::cout << "[Info]: Successfully parsed ServiceJson document" << std::endl;

  NotifyVehicleSpeed data, data2;
  std::string err_msg;

  rapidjson::Value const& initial = mDocument["initial"];
  for (rapidjson::SizeType i = 0; i < initial.Size(); i++)
  {

    std::cout << initial[i]["eventname"].GetString() << std::endl;

    rapidjson::Value const& val = initial[i]["data"].GetObject();
    pbjson::jsonobject2pb(&val, &data, err_msg);

    std::cout << data.DebugString() << std::endl;
  }
}
