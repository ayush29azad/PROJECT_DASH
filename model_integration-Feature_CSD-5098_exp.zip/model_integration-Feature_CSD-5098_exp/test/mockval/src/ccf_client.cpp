#include <memory>

#include "someip.hpp"
#include "receiver.hpp"

int main()
{
  auto app = std::make_shared<JLR::someip::Application>("ccf-client");

  app->init();
  app->request_service(0x000B, 0x0001);

  app->register_message_handler("GetParamRequest", 0x7001, 0x000B, 0x0001, &Receiver::GetParamResponse);

  app->start();

  // Continuosly send requests
  int ctr = 1;
  while (1)
  {
    featureconfig_userapps_service::GetParamRequest request;
    for (int i = 0; i < 5; i++)
    {
      auto* el = request.add_params();
      el->set_mdf_id(20 * ctr + i + 1);
    }
    std::string msg;
    request.SerializeToString(&msg);
    vsomeip::byte_t* payload_data_to_be_sent = reinterpret_cast<vsomeip::byte_t*>(&msg[0]);
    int n = msg.size();

    app->send_request(0x000B, 0x0001, 0x7001, payload_data_to_be_sent, n);

    std::cout << "[Info] : Request Sent " << std::endl << request.DebugString() << std::endl;
    ctr++;

    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
  }
}
