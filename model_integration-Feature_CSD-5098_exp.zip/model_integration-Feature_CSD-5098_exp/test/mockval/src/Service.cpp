#include <Service.hpp>

using namespace di::mockval;

Service::Service()
{
}

void Service::set_name(std::string const& serviceName)
{
  this->mName = serviceName;
}

std::string Service::get_name() const
{
  return this->mName;
}

void Service::set_service_id(int const serviceId)
{
  this->mServiceId = serviceId;
}

int Service::get_service_id() const
{
  return this->mServiceId;
}

void Service::set_instance_id(int const instanceId)
{
  this->mInstanceId = instanceId;
}

int Service::get_instance_id() const
{
  return this->mInstanceId;
}

void Service::set_offers(bool const offers)
{
  this->mOffers = offers;
}

bool Service::get_offers() const
{
  return this->mOffers;
}

void Service::set_period(int const period)
{
  this->mPeriod = period;
}

int Service::get_period() const
{
  return mPeriod;
}

void Service::add_event(Event const& event)
{
  mEvents.push_back(event);
}

std::vector<Event> Service::get_events() const
{
  return this->mEvents;
}

void Service::add_eventgrp(EventGroup const& eventgrp)
{
  mEventGrps.push_back(eventgrp);
}

std::vector<EventGroup> Service::get_eventgrps() const
{
  return this->mEventGrps;
}

void Service::add_method(Method const& method)
{
  mMethods.push_back(method);
}

std::vector<Method> Service::get_methods() const
{
  return this->mMethods;
}
