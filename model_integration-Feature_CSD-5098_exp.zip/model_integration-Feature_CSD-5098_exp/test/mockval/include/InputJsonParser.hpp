#ifndef _DI_MOCKVAL_INPUT_JSON_PARSER_
#define _DI_MOCKVAL_INPUT_JSON_PARSER_

#include <vector>
#include <rapidjson/filereadstream.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <rapidjson/document.h>
#include <pbjson/pbjson.hpp>
#include <Service.hpp>
#include <mockval_types.h>

namespace di
{

  namespace mockval
  {

    constexpr int MAX_FILESIZE_INPUT = 65536;

    class InputJsonParser
    {

    private:
      char readBuffer[MAX_FILESIZE_INPUT];
      rapidjson::Document mDocument;

      std::vector<InputData> initialEvents;
      std::vector<InputDataTimer> dataList;
      std::vector<RequestResponseMapping> mappingList;

    public:
      InputJsonParser(std::string const filename);

      void add_input_data(InputDataTimer const inputData);

      void add_initial_data(InputData const inputData);

      void add_mapping_data(RequestResponseMapping const& mappingData);

      std::vector<InputDataTimer> get_input_data() const;

      std::vector<InputData> get_initial_data() const;

      std::vector<RequestResponseMapping> get_mapping_data() const;

      void populate_input_data();

      void populate_initial_events();

      void populate_mapping_data();

      InputData jsonvalue_to_input_data(rapidjson::Value const& value);

      InputDataTimer jsonvalue_to_input_data_timer(rapidjson::Value const& value);

      RequestResponseMapping jsonvalue_to_mapping_data(rapidjson::Value const& value);

      std::string get_message_name(rapidjson::Value const& value);

      std::string get_message_data(rapidjson::Value const& value);

      int get_time_period(rapidjson::Value const& value);
    };

  }  // namespace mockval

}  // namespace di

#endif
