#ifndef _DI_MOCKVAL_DATA_HANDLER_
#define _DI_MOCKVAL_DATA_HANDLER_

#include <iostream>
#include <map>
#include <functional>
#include <memory>
#include <pbjson/pbjson.hpp>
#include <rapidjson/document.h>
#include <GlobalFunctors.hpp>
#include <SupportedEvents.hpp>
#include <PyWrapper.hpp>

namespace di
{

  namespace mockval
  {

    class FunctorsHandler
    {

    public:
      FunctorsHandler() = delete;
      FunctorsHandler(FunctorsHandler const&) = delete;
      FunctorsHandler(FunctorsHandler const&&) = delete;

      template <typename DataType>
      static void add_json_to_proto_functor(std::string eventname)
      {

        // std::function <string(string&)>
        // Takes json object serialized to string
        // Return proto msg obj serialized to string
        // TODO : check error_msg for errors and handle
        auto functor = [](std::string& value)
        {
          DataType data;
          std::string strData;

          pbjson::json2pb(value, &data, di::mockval::data::GlobalTables::get_instance().error_msg);
          data.SerializeToString(&strData);

          return strData;
        };

        di::mockval::data::GlobalTables::get_instance().mJsonToPbMapping[eventname] = functor;
      }

      template <typename DataType>
      static void add_printer_client(std::string eventname)
      {

        // std::function <string(string&)>
        // Takes json object serialized to string
        // Return proto msg obj serialized to string
        // TODO : check error_msg for errors and handle
        auto functor = [](std::string data)
        {
          DataType protoData;

          protoData.ParseFromString(data);

          std::cout << "[Info] : " << protoData.DebugString() << std::endl;
        };

        di::mockval::data::GlobalTables::get_instance().mNotifyResponseRecvFunctors[eventname] = functor;
      }

      template <typename RequestType, typename ResponseType>
      static void add_request_recv_functor(std::string requestName, std::string responseName)
      {

        auto functor = [requestName, responseName](std::string dataReceived)
        {
          RequestType request;
          request.ParseFromString(dataReceived);

          std::cout << "[Info]: Request received : " << requestName << " : " << request.DebugString() << std::endl;

          if (di::mockval::data::GlobalTables::get_instance().mRequestResponseMapping.find(dataReceived) !=
              di::mockval::data::GlobalTables::get_instance().mRequestResponseMapping.end())
          {
            // Request found in request-response mapping - reply with corresponding response

            std::string responseProtoString =
                di::mockval::data::GlobalTables::get_instance().mRequestResponseMapping[dataReceived];
            di::mockval::data::GlobalTables::get_instance().mSendResponseFunctors[responseName](responseProtoString);

            // Logging
            ResponseType responseProto;
            responseProto.ParseFromString(responseProtoString);

            std::cout << "[Info]: Response Sent : " << responseName << std::endl
                      << responseProto.DebugString() << std::endl;
          }
          else
          {

            int msg_size = dataReceived.size();

            if (msg_size)
            {
              // Non-empty request - use python logic

              std::string py_module_name = di::mockval::data::GlobalTables::get_instance().response_module_path;
              int module_name_len = py_module_name.size();

              if (module_name_len != 0)
              {
                std::string jsonResponse;
                pbjson::pb2json(&request, jsonResponse);
                std::string responseString = di::mockval::PyWrapper::get_instance().call_function1_from_module(
                    py_module_name, "main", jsonResponse);

                std::string responseProtoString =
                    di::mockval::data::GlobalTables::get_instance().mJsonToPbMapping[responseName](responseString);

                di::mockval::data::GlobalTables::get_instance().mSendResponseFunctors[responseName](
                    responseProtoString);

                // Logging
                ResponseType responseProto;
                responseProto.ParseFromString(responseProtoString);

                std::cout << "[Info]: Response Sent : " << responseName << std::endl
                          << responseProto.DebugString() << std::endl;
              }
              else
              {
                std::cout << "[info]: Python logic module can't be loaded ... skipping vsomeip request" << std::endl;
              }
            }
            else
            {
              // Request was empty case
              std::string responseProtoString;

              // Whatever is the data in mMessageObjectPtrs[responseName], will be serialized
              di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[responseName]->SerializeToString(
                  &responseProtoString);
              di::mockval::data::GlobalTables::get_instance().mSendResponseFunctors[responseName](responseProtoString);

              // Logging
              ResponseType responseProto;
              responseProto.ParseFromString(responseProtoString);
              std::cout << "[Info]: Response Sent : " << responseName << std::endl
                        << responseProto.DebugString() << std::endl;
            }
          }
        };

        di::mockval::data::GlobalTables::get_instance().mRequestRecvFunctors[requestName] = functor;
      }

      template <typename NotifyType>
      static void add_support(std::string eventName)
      {

        std::shared_ptr<google::protobuf::Message> message = std::make_shared<NotifyType>();
        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[eventName] = message;

        add_json_to_proto_functor<NotifyType>(eventName);

        di::mockval::data::GlobalTables::get_instance().mIsToBeSentMap[eventName] = true;
      }

      template <typename NotifyType>
      static void add_support_client(std::string eventName)
      {

        std::shared_ptr<google::protobuf::Message> message = std::make_shared<NotifyType>();
        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[eventName] = message;

        add_printer_client<NotifyType>(eventName);
      }

      template <typename GetRequestType, typename GetResponseType>
      static void add_support(std::string requestName, std::string responseName)
      {

        std::shared_ptr<google::protobuf::Message> request_message = std::make_shared<GetRequestType>();
        std::shared_ptr<google::protobuf::Message> response_message = std::make_shared<GetResponseType>();

        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[requestName] = request_message;
        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[responseName] = response_message;

        add_json_to_proto_functor<GetRequestType>(requestName);
        add_json_to_proto_functor<GetResponseType>(responseName);

        add_request_recv_functor<GetRequestType, GetResponseType>(requestName, responseName);
      }

      template <typename GetRequestType, typename GetResponseType>
      static void add_support_client(std::string requestName, std::string responseName)
      {

        std::shared_ptr<google::protobuf::Message> request_message = std::make_shared<GetRequestType>();
        std::shared_ptr<google::protobuf::Message> response_message = std::make_shared<GetResponseType>();

        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[requestName] = request_message;
        di::mockval::data::GlobalTables::get_instance().mMessageObjectPtrs[responseName] = response_message;

        add_json_to_proto_functor<GetRequestType>(requestName);
        add_json_to_proto_functor<GetResponseType>(responseName);

        add_printer_client<GetResponseType>(responseName);
        di::mockval::data::GlobalTables::get_instance().mIsToBeSentMap[requestName] = true;

        // add_request_recv_functor<GetRequestType, GetResponseType>(requestName, responseName);
      }
    };

  }  // namespace mockval

}  // namespace di

#endif
