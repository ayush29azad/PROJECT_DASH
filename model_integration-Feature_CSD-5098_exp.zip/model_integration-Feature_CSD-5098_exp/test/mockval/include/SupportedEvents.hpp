#ifndef _DI_MOCKVAL_SUPPORTED_EVENTS_
#define _DI_MOCKVAL_SUPPORTED_EVENTS_

#include <FunctorsHandler.hpp>
#include <GlobalFunctors.hpp>

#include <occupant_safety_service.pb.h>
#include <charging_service.pb.h>
#include <motion_service.pb.h>
#include <steering_wheel_switch_service.pb.h>
#include <telltale_service.pb.h>
#include <vehiclemessaging_service.pb.h>
#include <pps_climate_service.pb.h>
#include <apertures_service.pb.h>
#include <energymanagement_service.pb.h>
#include <propulsion_service.pb.h>
#include <navigation_service.pb.h>
#include <speedometerunits_service.pb.h>
#include <cockpit_settings_service.pb.h>
#include <ivi_messaging_service.pb.h>

namespace di::mockval::data
{

  void init()
  {

    // // vehiclespeed_service events ----------------------------------------------------
    // di::mockval::FunctorsHandler::add_support<vehiclespeed_service::NotifyVehicleSpeed>("NotifyVehicleSpeed");

    // di::mockval::FunctorsHandler::add_support<vehiclespeed_service::GetVehicleSpeedRequest,vehiclespeed_service::GetVehicleSpeedResponse>
    // ("GetVehicleSpeedRequest", "GetVehicleSpeedResponse");

    // // featureconfig_userapps_service ----------------------------------------------------
    // di::mockval::FunctorsHandler::add_support<featureconfig_userapps_service::GetParamRequest,featureconfig_userapps_service::GetParamResponse>
    // ("GetParamRequest", "GetParamResponse");

    // // sws_service ----------------------------------------------------
    // di::mockval::FunctorsHandler::add_support<sws_service::NotifyClusterControlLeftState>("NotifyClusterControlLeftState");
    // di::mockval::FunctorsHandler::add_support<sws_service::NotifyClusterControlRightState>("NotifyClusterControlRightState");

    // di::mockval::FunctorsHandler::add_support_client<sws_service::NotifyClusterControlLeftState>("NotifyClusterControlLeftState");
    // di::mockval::FunctorsHandler::add_support_client<sws_service::NotifyClusterControlRightState>("NotifyClusterControlRightState");

    // occupant_safety_service events ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<occupant_safety_service::NotifySeatbeltBuckleStatus>(
        "NotifySeatbeltBuckleStatus");

    di::mockval::FunctorsHandler::add_support<
        occupant_safety_service::GetSeatbeltBuckleStatusRequest,
        occupant_safety_service::GetSeatbeltBuckleStatusResponse>(
        "GetSeatbeltBuckleStatusRequest", "GetSeatbeltBuckleStatusResponse");

    // charging_service events ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<charging_service::NotifyChargeState>("NotifyChargeState");
    di::mockval::FunctorsHandler::add_support<charging_service::NotifyChargeSettings>("NotifyChargeSettings");

    di::mockval::FunctorsHandler::
        add_support<charging_service::GetChargeStateRequest, charging_service::GetChargeStateResponse>(
            "GetChargeStateRequest", "GetChargeStateResponse");
    di::mockval::FunctorsHandler::
        add_support<charging_service::GetChargeSettingsRequest, charging_service::GetChargeSettingsResponse>(
            "GetChargeSettingsRequest", "GetChargeSettingsResponse");

    // motion_service events ----------------------------------------------------
    //  Hold Feature
    di::mockval::FunctorsHandler::add_support<motion_service::NotifyAutoHoldFunctionActive>(
        "NotifyAutoHoldFunctionActive");

    di::mockval::FunctorsHandler::add_support<
        motion_service::GetAutoHoldFunctionActiveRequest,
        motion_service::GetAutoHoldFunctionActiveResponse>(
        "GetAutoHoldFunctionActiveRequest", "GetAutoHoldFunctionActiveResponse");

    // BrakePadWear feature
    di::mockval::FunctorsHandler::add_support<motion_service::NotifyBrakePadWearStatus>("NotifyBrakePadWearStatus");

    di::mockval::FunctorsHandler::
        add_support<motion_service::GetBrakePadWearStatusRequest, motion_service::GetBrakePadWearStatusResponse>(
            "GetBrakePadWearStatusRequest", "GetBrakePadWearStatusResponse");

    // ATPC & HDC indicator
    di::mockval::FunctorsHandler::add_support<motion_service::NotifyATPCMode>("NotifyATPCMode");
    di::mockval::FunctorsHandler::add_support<motion_service::NotifyHDCMode>("NotifyHDCMode");

    di::mockval::FunctorsHandler::add_support<motion_service::GetATPCModeRequest, motion_service::GetATPCModeResponse>(
        "GetATPCModeRequest", "GetATPCModeResponse");
    di::mockval::FunctorsHandler::add_support<motion_service::GetHDCModeRequest, motion_service::GetHDCModeResponse>(
        "GetHDCModeRequest", "GetHDCModeResponse");

    // TPMS Vehicle imagery display
    di::mockval::FunctorsHandler::add_support<motion_service::NotifyTyrePressureInfo>("NotifyTyrePressureInfo");
    di::mockval::FunctorsHandler::
        add_support<motion_service::GetTyrePressureInfoRequest, motion_service::GetTyrePressureInfoResponse>(
            "GetTyrePressureInfoRequest", "GetTyrePressureInfoResponse");
    // energymanagement_service ((mockval as server)----------------------------------------------------
    //  Ready Feauture
    di::mockval::FunctorsHandler::add_support<energymanagement_service::NotifyPowertrainReadyStatus>(
        "NotifyPowertrainReadyStatus");

    di::mockval::FunctorsHandler::add_support<
        energymanagement_service::GetPowertrainReadyStatusRequest,
        energymanagement_service::GetPowertrainReadyStatusResponse>(
        "GetPowertrainReadyStatusRequest", "GetPowertrainReadyStatusResponse");

    di::mockval::FunctorsHandler::add_support<energymanagement_service::NotifyEcoDrivingCoachPower>(
        "NotifyEcoDrivingCoachPower");

    // telltale_service events (mockval as client) ----------------------------------------------------
    //  TSRUpComingSpeedLimit
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyTSRUpComingSpeedLimitStatus>(
        "NotifyTSRUpComingSpeedLimitStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetTSRUpComingSpeedLimitRequest,
        telltale_service::SetTSRUpComingSpeedLimitResponse>(
        "SetTSRUpComingSpeedLimitRequest", "SetTSRUpComingSpeedLimitResponse");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::GetTSRUpComingSpeedLimitRequest,
        telltale_service::GetTSRUpComingSpeedLimitResponse>(
        "GetTSRUpComingSpeedLimitRequest", "GetTSRUpComingSpeedLimitResponse");

    // TSRSpeedLimit
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyTSRSpeedLimitStatus>(
        "NotifyTSRSpeedLimitStatus");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::SetTSRSpeedLimitRequest, telltale_service::SetTSRSpeedLimitResponse>(
            "SetTSRSpeedLimitRequest", "SetTSRSpeedLimitResponse");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::GetTSRSpeedLimitRequest, telltale_service::GetTSRSpeedLimitResponse>(
            "GetTSRSpeedLimitRequest", "GetTSRSpeedLimitResponse");

    // TSRUpComingOverSpeedWarning
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyTSROverSpeedWarningStatus>(
        "NotifyTSROverSpeedWarningStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetTSROverSpeedWarningRequest,
        telltale_service::SetTSROverSpeedWarningResponse>(
        "SetTSROverSpeedWarningRequest", "SetTSROverSpeedWarningResponse");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::GetTSROverSpeedWarningRequest,
        telltale_service::GetTSROverSpeedWarningResponse>(
        "GetTSROverSpeedWarningRequest", "GetTSROverSpeedWarningResponse");

    // TSRAdditionalSignInfoRequest
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyTSRAdditionalSignInfoStatus>(
        "NotifyTSRAdditionalSignInfoStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetTSRAdditionalSignInfoRequest,
        telltale_service::SetTSRAdditionalSignInfoResponse>(
        "SetTSRAdditionalSignInfoRequest", "SetTSRAdditionalSignInfoResponse");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::GetTSRAdditionalSignInfoRequest,
        telltale_service::GetTSRAdditionalSignInfoResponse>(
        "GetTSRAdditionalSignInfoRequest", "GetTSRAdditionalSignInfoResponse");

    // TSR RoadRulesWarningSign
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyTSRRoadRulesWarningStatus>(
        "NotifyTSRRoadRulesWarningStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetTSRRoadRulesWarningRequest,
        telltale_service::SetTSRRoadRulesWarningResponse>(
        "SetTSRRoadRulesWarningRequest", "SetTSRRoadRulesWarningResponse");

    // Climate Indicator
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyIndicatorStatus>("NotifyIndicatorStatus");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::SetIndicatorRequest, telltale_service::SetIndicatorResponse>(
            "SetIndicatorRequest", "SetIndicatorResponse");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::GetIndicatorRequest, telltale_service::GetIndicatorResponse>(
            "GetIndicatorRequest", "GetIndicatorResponse");

    // ADAS
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyLightbarStatus>("NotifyLightbarStatus");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::SetLightbarRequest, telltale_service::SetLightbarResponse>(
            "SetLightbarRequest", "SetLightbarResponse");

    di::mockval::FunctorsHandler::
        add_support_client<telltale_service::GetLightbarRequest, telltale_service::GetLightbarResponse>(
            "GetLightbarRequest", "GetLightbarResponse");

    // ADAS Combined
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyCombinedIndicatorStatus>(
        "NotifyCombinedIndicatorStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetCombinedIndicatorRequest,
        telltale_service::SetCombinedIndicatorResponse>("SetCombinedIndicatorRequest", "SetCombinedIndicatorResponse");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::GetCombinedIndicatorRequest,
        telltale_service::GetCombinedIndicatorResponse>("GetCombinedIndicatorRequest", "GetCombinedIndicatorResponse");

    // EcoDrivingCoach
    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetEcoDrivingCoachIndicatorRequest,
        telltale_service::SetEcoDrivingCoachIndicatorResponse>(
        "SetEcoDrivingCoachIndicatorRequest", "SetEcoDrivingCoachIndicatorResponse");

    // Seat Belt Indicator
    di::mockval::FunctorsHandler::add_support_client<telltale_service::NotifyDriverSeatbeltIndicatorStatus>(
        "NotifyDriverSeatbeltIndicatorStatus");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::SetDriverSeatbeltIndicatorRequest,
        telltale_service::SetDriverSeatbeltIndicatorResponse>(
        "SetDriverSeatbeltIndicatorRequest", "SetDriverSeatbeltIndicatorResponse");

    di::mockval::FunctorsHandler::add_support_client<
        telltale_service::GetDriverSeatbeltIndicatorRequest,
        telltale_service::GetDriverSeatbeltIndicatorRequest>(
        "GetDriverSeatbeltIndicatorRequest", "GetDriverSeatbeltIndicatorRequest");

    // vehiclemessaging_service events ----------------------------------------------------
    di::mockval::FunctorsHandler::
        add_support_client<vehiclemessaging_service::SetWarnMsgRequest, vehiclemessaging_service::SetWarnMsgResponse>(
            "SetWarnMsgRequest", "SetWarnMsgResponse");
    di::mockval::FunctorsHandler::add_support_client<
        vehiclemessaging_service::SetTempAlertMsgRequest,
        vehiclemessaging_service::SetTempAlertMsgResponse>("SetTempAlertMsgRequest", "SetTempAlertMsgResponse");

    di::mockval::FunctorsHandler::add_support_client<vehiclemessaging_service::NotifyWarnMessageState>(
        "NotifyWarnMessageState");
    di::mockval::FunctorsHandler::add_support_client<
        vehiclemessaging_service::GetWarnMessageStateRequest,
        vehiclemessaging_service::GetWarnMessageStateResponse>(
        "GetWarnMessageStateRequest", "GetWarnMessageStateResponse");

    // pps_climate_service ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<pps_climate_service::NotifyVehiclePreconditionState>(
        "NotifyVehiclePreconditionState");

    di::mockval::FunctorsHandler::add_support<
        pps_climate_service::GetVehiclePreconditionStateRequest,
        pps_climate_service::GetVehiclePreconditionStateResponse>(
        "GetVehiclePreconditionStateRequest", "GetVehiclePreconditionStateResponse");

    // steering_wheel_switch_service ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<sws_service::GetFeatureModeRequest, sws_service::GetFeatureModeResponse>(
        "GetFeatureModeRequest", "GetFeatureModeResponse");

    di::mockval::FunctorsHandler::add_support<sws_service::NotifyFeatureMode>("NotifyFeatureMode");
    di::mockval::FunctorsHandler::add_support<sws_service::NotifyClusterControlLeftState>(
        "NotifyClusterControlLeftState");
    di::mockval::FunctorsHandler::add_support<sws_service::NotifyClusterControlRightState>(
        "NotifyClusterControlRightState");
    di::mockval::FunctorsHandler::add_support<sws_service::NotifyJoypadOkButtonStatus>("NotifyJoypadOkButtonStatus");

    // aperture_service_service ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<apertures_service::NotifyDoorOpenCloseStatus>(
        "NotifyDoorOpenCloseStatus");
    di::mockval::FunctorsHandler::add_support<
        apertures_service::GetDoorOpenCloseStatusRequest,
        apertures_service::GetDoorOpenCloseStatusResponse>(
        "GetDoorOpenCloseStatusRequest", "GetDoorOpenCloseStatusResponse");

    // energymanagement_Service Events(Mockval as server) ----------------------------------------------------
    // EV Range
    di::mockval::FunctorsHandler::add_support<energymanagement_service::NotifyEVRange>("NotifyEVRange");
    di::mockval::FunctorsHandler::
        add_support<energymanagement_service::GetEVRangeRequest, energymanagement_service::GetEVRangeResponse>(
            "GetEVRangeRequest", "GetEVRangeResponse");

    // BatteryCharge
    di::mockval::FunctorsHandler::add_support<energymanagement_service::NotifyBatteryCharge>("NotifyBatteryCharge");
    di::mockval::FunctorsHandler::add_support<
        energymanagement_service::GetBatteryChargeRequest,
        energymanagement_service::GetBatteryChargeResponse>("GetBatteryChargeRequest", "GetBatteryChargeResponse");

    // speedometerunits_service (mockval as server) ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<speedometerunits_service::NotifySpeedometerUnitsNumericStatus>(
        "NotifySpeedometerUnitsNumericStatus");
    di::mockval::FunctorsHandler::add_support<
        speedometerunits_service::GetSpeedometerUnitsNumericRequest,
        speedometerunits_service::GetSpeedometerUnitsNumericResponse>(
        "GetSpeedometerUnitsNumericRequest", "GetSpeedometerUnitsNumericResponse");

    // navigation_service (mockval as server) ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<navigation_service::NotifyRangeOnRouteOperational>(
        "NotifyRangeOnRouteOperational");
    di::mockval::FunctorsHandler::add_support<
        navigation_service::GetRangeOnRouteOperationalRequest,
        navigation_service::GetRangeOnRouteOperationalResponse>(
        "GetRangeOnRouteOperationalRequest", "GetRangeOnRouteOperationalResponse");

    // cockpit_settings_service (mockval as server) ----------------------------------------------------
    di::mockval::FunctorsHandler::add_support<cockpit_settings_service::NotifySystemLanguageStatus>(
        "NotifySystemLanguageStatus");
    di::mockval::FunctorsHandler::add_support<
        cockpit_settings_service::GetSystemLanguageRequest,
        cockpit_settings_service::GetSystemLanguageResponse>("GetSystemLanguageRequest", "GetSystemLanguageResponse");
    // For EMA Display Theme Usecase
    di::mockval::FunctorsHandler::add_support<
        cockpit_settings_service::GetCurrentSystemThemeRequest,
        cockpit_settings_service::GetCurrentSystemThemeResponse>(
        "GetCurrentSystemThemeRequest", "GetCurrentSystemThemeResponse");
    di::mockval::FunctorsHandler::add_support<cockpit_settings_service::NotifyCurrentSystemTheme>(
        "NotifyCurrentSystemTheme");

    // ivi_messaging_service (mockval as server) ----------------------
    di::mockval::FunctorsHandler::add_support<ivi_messaging_service::NotifyStaticIVIMessage>("NotifyStaticIVIMessage");
    di::mockval::FunctorsHandler::add_support<
        ivi_messaging_service::SetStaticIVIMessageRequest,
        ivi_messaging_service::SetStaticIVIMessageResponse>(
        "SetStaticIVIMessageRequest", "SetStaticIVIMessageResponse");

    // propulsion service events
    di::mockval::FunctorsHandler::add_support<propulsion_service::NotifyMaxPowerRegenStatus>(
        "NotifyMaxPowerRegenStatus");
    di::mockval::FunctorsHandler::add_support<propulsion_service::NotifyInstantaneousPowerRegenStatus>(
        "NotifyInstantaneousPowerRegenStatus");
  }

}  // namespace di::mockval::data

#endif
