#ifndef _DI_MOCKVAL_GLOBAL_FUNCTORS_
#define _DI_MOCKVAL_GLOBAL_FUNCTORS_

#include <iostream>
#include <map>
#include <functional>
#include <memory>
#include <google/protobuf/message.h>

#include <mockval_types.h>

namespace di
{

  namespace mockval
  {

    namespace data
    {

      class GlobalTables
      {

      private:
        GlobalTables()
        {
        }

      public:
        GlobalTables(GlobalTables const&) = delete;
        void operator=(GlobalTables const&) = delete;

        static GlobalTables& get_instance()
        {
          static GlobalTables global_tables;
          return global_tables;
        }

        /// @brief  map of eventname, std::function object converting string
        /// json object to string proto message object for that event
        std::map<std::string, std::function<std::string(std::string&)>> mJsonToPbMapping;

        /// @brief  map of eventname, std::function object converting string
        /// proto message object to string json object for that event
        std::map<std::string, std::function<std::string(std::string&)>> mPbToJsonMapping;

        /// @brief map of eventname, std::function object for actually sending the
        /// vsomeip bytes (converted from std::string)
        std::map<std::string, std::function<void(std::string&)>> mSendFunctors;

        /// @brief map of eventname, std::function object for actually send the
        /// vsomeip bytes (converted from std::string)
        std::map<std::string, std::function<void(std::string&)>> mSendResponseFunctors;

        /// @brief map of eventname, std::function object for actually receiving the
        /// vsomeip requests (converted from std::string)
        std::map<std::string, std::function<void(std::string)>> mRequestRecvFunctors;

        std::map<std::string, std::function<void(std::string)>> mNotifyResponseRecvFunctors;

        // std::map <std::string, std::function<void(std::string)>> mSendRequestFunctors;

        /// @brief map for storing the objects for each message type, These objects
        /// shall store the current values for the event/signal whatever
        std::map<std::string, std::shared_ptr<google::protobuf::Message>> mMessageObjectPtrs;

        /// @brief map to store request-response pair, meaning it stores what response server should
        /// send if it receives a request with particular data;
        std::map<std::string, std::string> mRequestResponseMapping;

        /// @brief map to store whether is event is notify event or not
        std::map<std::string, bool> mIsToBeSentMap;

        /// @brief Stores path to the response generator python script
        std::string response_module_path = "";

        /// @brief Stores error msg while using pbjson::json2pb
        std::string error_msg;
      };

    }  // namespace data

  }  // namespace mockval

}  // namespace di

#endif
