import sys

# Takes request as dict and returns response as dict object
# Write the response generation logic here 
def generator(request_json):
    # print(request_json)

    response_json = dict()
    response_json["status"] = "ENUM_STATUS_CCF_OK"
    response_json["params"] = []

    request_params = request_json["params"]
    for param in request_params:
        tmp = dict()
        tmp["mdf_status"] = "ENUM_STATUS_MDFID_OK"
        tmp["mdf"] = param["mdf_id"]
        if param["mdf_id"]%7 == 0 : 
            tmp["value"] = 51

        response_json["params"].append(tmp)

    return response_json


# Do not modify name, return or argument of the below function - cpp code is calling this function
def main(request_str):

    # modify this to "/usr/lib/python3.11" for qnx 
    sys.path.append("/usr/lib/python3.10")
    import json 

    request_json = json.loads(request_str)

    return json.dumps(generator(request_json))
