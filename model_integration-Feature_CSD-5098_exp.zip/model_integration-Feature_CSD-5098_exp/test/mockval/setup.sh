#!/bin/bash

#set -eo pipefail

# shellcheck disable=SC2164

# Setup variables for cloning git repository
GITLAB_PATH="eva3/CCCM/infrastructure/common-ci-scripts.git"
SSH_URL="git@git-gdd.sdo.jlrmotor.com:${GITLAB_PATH}"
HTTPS_URL="https://gitlab-ci-token:${CI_JOB_TOKEN}@git-gdd.sdo.jlrmotor.com/${GITLAB_PATH}"

CHECKOUT_BRANCH="master"
# To-Do: syncup with David & fix the access
# CHECKOUT_SHA="8b6e0c745c45658fcf8b1fd71daf23d3c899fbfd" # This uses access-token (only cccm-bin & cccm-pub-bin & not cccm-mvn-local)
CHECKOUT_SHA="fbaa59bae3f2acfce2eade5d104665413b24dcf1" # This uses ARTIFACTORY-APIKEY

TARGET_FOLDER="ci"

function _setup_git_repo {
    cd "${TARGET_FOLDER}"
    # Check whether the checkout branch exists locally. Use || true to catch exit
    # code when branch does not exist
    branch_exists=$(git rev-parse --verify --quiet "${CHECKOUT_BRANCH}" || true)
    if [ -z "${branch_exists}" ]; then
        git checkout --track "remotes/origin/${CHECKOUT_BRANCH}"
    else
        git checkout "${CHECKOUT_BRANCH}"
        git fetch
    fi

    # Checkout the specified SHA
    git checkout "${CHECKOUT_SHA}"

    cd ..
}


PROJECT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd)

if [ "$0" = "${BASH_SOURCE[0]}" ]; then
    echo "Make sure this script is sourced instead of executed"
    echo "Project dir is detected as ${PROJECT_DIR}"
    exit 1
fi


cd "${PROJECT_DIR}"

if [[ -z ${GITLAB_CI} ]] ; then
    echo "Running locally"
    if [[ -d "${PROJECT_DIR}/${TARGET_FOLDER}" ]]; then
        echo "${TARGET_FOLDER} directory already exists so will execute git pull inside"
    else
        echo "ci directory does not exist so will execute git clone"
        git clone "${SSH_URL}" "${TARGET_FOLDER}"
        cd "${TARGET_FOLDER}"
    fi
else
    if [[ -z ${CI_JOB_TOKEN} ]]; then
        echo "Running locally using gitlab-runner"
        echo "Cloning currently not supported"
    else
        echo "Running in the pipeline"
        git clone "${HTTPS_URL}" "${TARGET_FOLDER}"
    fi
fi

# Now checkout the required SHA
_setup_git_repo
