#include <string>
#include "vehiclespeed_service.pb.h"
#include "featureconfig_userapps_service.pb.h"

#ifndef JLR_RECEIVER_HPP
#define JLR_RECEIVER_HPP
namespace Receiver
{
  // void NotifyVehicleSpeed(std::string& data);
  void GetParamResponse(std::string& data);
}  // namespace Receiver
#endif
