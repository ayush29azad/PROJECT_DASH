import model_wrapper_templates as mwt
import model_json_parser
import filepaths
class _SomeipCreateConsumer:

    def __init__(self, model_object, service_name):

        self.template = mwt.someip_create_consumer
        self.values_dict = {}

        self.values_dict["service_name"] = service_name
        instaceIdName = "".join(word.capitalize() for word in (service_name + "_InstanceId").split("_"))
        self.values_dict["instaceIdName"] = instaceIdName[0].lower() + instaceIdName[1:]
        self.values_dict["service_id"] = model_object.getServiceIDfromServiceName(service_name)
        self.values_dict["instance_id"] = model_object.getInstanceIDforService(service_name)
        serviceIdName = "".join(word.capitalize() for word in (service_name + "_ServiceId").split("_"))
        self.values_dict["serviceIdName"] = serviceIdName[0].lower() + serviceIdName[1:]
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(service_name))
        consumer = "".join(word.capitalize() for word in service_name.split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _SomeipCreateProvider:

    def __init__(self, model_object, service_name):
        self.template = mwt.someip_create_provider
        self.values_dict = {}

        self.values_dict["service_name"] = service_name
        instaceIdName = "".join(word.capitalize() for word in (service_name + "_InstanceId").split("_"))
        self.values_dict["instaceIdName"] = instaceIdName[0].lower() + instaceIdName[1:]
        self.values_dict["service_id"] = model_object.getServiceIDfromServiceName(service_name)
        self.values_dict["instance_id"] = model_object.getInstanceIDforService(service_name)
        serviceIdName = "".join(word.capitalize() for word in (service_name + "_ServiceId").split("_"))
        self.values_dict["serviceIdName"] = serviceIdName[0].lower() + serviceIdName[1:]
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(service_name))
        provider = "".join(word.capitalize() for word in service_name.split("_"))
        self.values_dict["provider"] = provider[0].lower() + provider[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)


# model_method should be vsomeip notify type with model as client
class _SomeipNonEmptyNotifyIn:

    def __init__(self, model_object, model_event):

        self.template = mwt.someip_notify_in
        self.values_dict = {}

        grps = model_event.getAllEventGroupIDs()

        self.values_dict["package_name"] = model_event.getPackageName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["service_name"] = model_event.getServiceName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_event.getMethodName()
        self.values_dict["proto_notify"] = model_event.getMessage()
        self.values_dict["model_notify"] = model_event.getModelStructName()
        eventId = model_event.getMessage()[0].lower() + model_event.getMessage()[1:] + "ID"
        self.values_dict["event_Name"] = eventId
        self.values_dict["grps"] = "{" + ",".join(grps) + "}"
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_event.getServiceName()))
        consumer = "".join(word.capitalize() for word in model_event.getServiceName().split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)
    

class _SomeipEmptyNotifyIn:

    def __init__(self, model_object, model_event):

        self.template = mwt.someip_notify_in_empty
        self.values_dict = {}

        grps = model_event.getAllEventGroupIDs()

        self.values_dict["package_name"] = model_event.getPackageName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["service_name"] = model_event.getServiceName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_event.getMethodName()
        self.values_dict["proto_notify"] = model_event.getMessage()
        self.values_dict["model_notify"] = model_event.getModelStructName()
        eventId = model_event.getMessage()[0].lower() + model_event.getMessage()[1:] + "ID"
        self.values_dict["event_Name"] = eventId
        self.values_dict["grps"] = "{" + ",".join(grps) + "}"
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_event.getServiceName()))
        consumer = "".join(word.capitalize() for word in model_event.getServiceName().split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)

# model_method should be vsomeip response type with model as client 
class _SomeipResponseIn:

    def __init__(self, model_object, model_method):

        self.template = mwt.someip_response_in
        self.values_dict = {}

        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["service_name"] = model_method.getServiceName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_method.getMethodName() 
        self.values_dict["proto_get_request"] = model_object.getCorrespondingRequestForResponse(model_method)
        self.values_dict["proto_get_response"] = model_method.getMessage()
        self.values_dict["model_get_response"] = model_method.getModelStructName()
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        self.values_dict["method_Name"] = methodId
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_method.getServiceName()))
        consumer = "".join(word.capitalize() for word in model_method.getServiceName().split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _SomeipUnpairedResponseIn:

    def __init__(self, model_object, model_method):

        self.template = mwt.someip_unpaired_response_in
        self.values_dict = {}

        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["service_name"] = model_method.getServiceName()
        self.values_dict["proto_get_request"] = model_method.getMessage()
        self.values_dict["proto_get_response"] = model_object.getCorrespondingResponseForRequest(model_method)
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        self.values_dict["method_Name"] = methodId
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_method.getServiceName()))
        consumer = "".join(word.capitalize() for word in model_method.getServiceName().split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]

    def substitute(self):
        return self.template.substitute(self.values_dict)


# model_method should be vsomeip notify type with model as server
class _SomeipNotifyOut:

    def __init__(self, model_object, model_event):

        self.template = mwt.someip_notify_out
        self.values_dict = {}

        grps = model_event.getAllEventGroupIDs()

        self.values_dict["package_name"] = model_event.getPackageName()
        self.values_dict["service_name"] = model_event.getServiceName()
        self.values_dict["proto_notify"] = model_event.getMessage()
        eventId = model_event.getMessage()[0].lower() + model_event.getMessage()[1:] + "ID"
        self.values_dict["event_Name"] = eventId
        self.values_dict["grps"] = "{" + ",".join(grps) + "}"
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_event.getServiceName()))
        provider = "".join(word.capitalize() for word in model_event.getServiceName().split("_"))
        self.values_dict["provider"] = provider[0].lower() + provider[1:]
        
    def substitute(self):
        return self.template.substitute(self.values_dict)


# model_method should be vsomeip request type with model as server 
class _SomeipEmptyRequestIn:

    def __init__(self, model_object, model_method):

        self.template = mwt.someip_request_in_empty
        self.values_dict = {}

        event_name = model_method.getMessage()

        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["service_name"] = model_method.getServiceName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_method.getMethodName()
        self.values_dict["proto_get_request"] = model_method.getMessage() 
        self.values_dict["proto_get_response"] = model_object.getCorrespondingResponseForRequest(model_method)
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        self.values_dict["method_Name"] = methodId
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_method.getServiceName()))
        provider = "".join(word.capitalize() for word in model_method.getServiceName().split("_"))
        self.values_dict["provider"] = provider[0].lower() + provider[1:]
        
    def substitute(self):
        return self.template.substitute(self.values_dict)


# model_method should be vsomeip request type with model as server 
class _SomeipNonEmptyRequestIn:

    def __init__(self, model_object, model_method):

        self.template = mwt.someip_request_in_nonempty
        self.values_dict = {}

        event_name = model_method.getMessage()

        self.values_dict["package_name"] = model_method.getPackageName()
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["service_name"] = model_method.getServiceName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_method.getMethodName()
        self.values_dict["proto_get_request"] = model_method.getMessage()
        self.values_dict["proto_get_response"] = model_object.getCorrespondingResponseForRequest(model_method)
        self.values_dict["model_get_request"] = model_method.getModelStructName()
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        self.values_dict["method_Name"] = methodId
        self.values_dict["vid"] = "Vid" + str(model_object.getvIdFromServiceName(model_method.getServiceName()))
        provider = "".join(word.capitalize() for word in model_method.getServiceName().split("_"))
        self.values_dict["provider"] = provider[0].lower() + provider[1:]
        
    def substitute(self):
        return self.template.substitute(self.values_dict)


class _SomeipOnAvailable:

    def __init__(self, model_object):

        self.template = mwt.on_available_template
        self.values_dict = {}

        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_fun"] = model_object.getModelOnAvailableFunName()

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _SetOnAvailable:

    def __init__(self, service_name, service_definition_file, filepaths_instance):
        
        self.template = mwt.set_on_available
        self.values_dict = {}

        self.values_dict["service_name"] = service_name
        consumer = "".join(word.capitalize() for word in service_name.split("_"))
        self.values_dict["consumer"] = consumer[0].lower() + consumer[1:]
        self.values_dict["vid"] = "Vid" + self.getvId(service_definition_file, filepaths_instance)
    
    def getvId(self, service_definition_file, filepaths_instance):
        if service_definition_file in ("odo_plausibility.json", "central_time_master_service.json", "golden_server_service.json", "golden2_service.json", "golden_client_service.json"):
            return "10"
        return str(model_json_parser.JsonParser.read_json(filepaths_instance.getProtoPath() +"/" +service_definition_file )["service"]["vid"])
    
    def substitute(self):
        return self.template.substitute(self.values_dict)



def _someipInit(model_object):
    res = ""
    ids_declaration = ""
    ids_definition = ""
    model_as_client = model_object.getAllServicesForModelAsClient()
    model_as_server = model_object.getAllServicesForModelAsServer()
    
    for _, services in model_as_server.items():
        for service in services:
            res += _SomeipCreateProvider(model_object, service).substitute()
    for _, services in model_as_client.items():
        for service in services:
            res += _SomeipCreateConsumer(model_object, service).substitute()

    notify_ins = model_object.getAllSomeipNotifyIns()
    for model_event in notify_ins:
        eventId = model_event.getMessage()[0].lower() + model_event.getMessage()[1:] + "ID"
        if model_event.checkIfEventHasArgument():
            ids_declaration += mwt.id_declaration_template.substitute({"idName": eventId})
            ids_definition += mwt.id_definition_template.substitute({"idName": eventId, "id": model_event.getEventID()})
            res += _SomeipNonEmptyNotifyIn(model_object, model_event).substitute()
        else:
            ids_declaration += mwt.id_declaration_template.substitute({"idName": eventId})
            ids_definition += mwt.id_definition_template.substitute({"idName": eventId, "id": model_event.getEventID()})
            res += _SomeipEmptyNotifyIn(model_object, model_event).substitute()

    request_out_msgs = []

    response_ins = model_object.getAllSomeipResponseIns()
    for model_method in response_ins:
        request_msg = model_object.getCorrespondingRequestForResponse(model_method)
        request_out_msgs.append(request_msg)
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        ids_declaration += mwt.id_declaration_template.substitute({"idName": methodId})
        ids_definition += mwt.id_definition_template.substitute({"idName": methodId, "id": model_method.getMethodID()})
        res += _SomeipResponseIn(model_object, model_method).substitute()

    request_outs = model_object.getAllSomeipRequestOuts()
    for vid, model_methods in request_outs.items():
        for model_method in model_methods:
            request_msg = model_method.getMessage()
            if request_msg not in request_out_msgs:
                methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
                ids_declaration += mwt.id_declaration_template.substitute({"idName": methodId})
                ids_definition += mwt.id_definition_template.substitute({"idName": methodId, "id": model_method.getMethodID()})
                res += _SomeipUnpairedResponseIn(model_object, model_method).substitute()

    notify_outs = model_object.getAllSomeipNotifyOuts()
    for vid, model_events in notify_outs.items():
        for model_event in model_events:
            eventId = model_event.getMessage()[0].lower() + model_event.getMessage()[1:] + "ID"
            ids_declaration += mwt.id_declaration_template.substitute({"idName": eventId})
            ids_definition += mwt.id_definition_template.substitute({"idName": eventId, "id": model_event.getEventID()})
            res += _SomeipNotifyOut(model_object, model_event).substitute()
    
    request_ins = model_object.getAllSomeipRequestIns()
    for model_method in request_ins:
        methodId = model_method.getMessage()[0].lower() + model_method.getMessage()[1:] + "ID"
        if model_method.checkIfModelEventHasArgument():
            ids_declaration += mwt.id_declaration_template.substitute({"idName": methodId})
            ids_definition += mwt.id_definition_template.substitute({"idName": methodId, "id": model_method.getMethodID()})
            res += _SomeipNonEmptyRequestIn(model_object, model_method).substitute()
        else:
            ids_declaration += mwt.id_declaration_template.substitute({"idName": methodId})
            ids_definition += mwt.id_definition_template.substitute({"idName": methodId, "id": model_method.getMethodID()})
            res += _SomeipEmptyRequestIn(model_object, model_method).substitute()
    if(len(ids_definition)!=0):
        ids_definition = ids_definition[:-1]
    return res, ids_declaration, ids_definition


class _DdsTopicOut:

    def __init__(self, model_method):
        self.template = mwt.dds_topic_out
        self.values_dict = {}
        self.values_dict["topic_name"] = "dds_ipc::" + model_method.getTopicName()

        self.values_dict["topic_name_small"] = model_method.getTopicName()[0].lower() + model_method.getTopicName()[1:]
        self.values_dict["topic_name_pubsub"] = "dds_ipc::" + model_method.getTopicName() + "PubSubType"

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _DdsTopicIn:

    def __init__(self, model_object, model_method):
        self.template = mwt.dds_topic_in
        self.values_dict = {}
        self.values_dict["topic_name"] = "dds_ipc::" + model_method.getTopicName()
        self.values_dict["topic_name_small"] = model_method.getTopicName()[0].lower() + model_method.getTopicName()[1:]
        self.values_dict["topic_name_pubsub"] = "dds_ipc::" + model_method.getTopicName() + "PubSubType"
        self.values_dict["model_fun"] = model_method.getMethodName()
        self.values_dict["model_struct"] = model_method.getModelStructName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["model_name"] = model_object.getModelName()

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _TimerInit:

    def __init__(self, model_object):

        self.template = mwt.timer_template
        self.values_dict = {}

        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        timer_method = model_object.getTimerMethod()
        self.values_dict["model_timer_fun"] = timer_method.getMethodName()
        self.values_dict["timer_period"] = timer_method.getTimerPeriod()

    def substitute(self):
        return self.template.substitute(self.values_dict)

class _SomeipHandlers:
    
    def __init__(self, key):

        self.template = mwt.someip_handlers
        self.values_dict = {}

        self.values_dict["key"] = "vid" + str(key)
        self.values_dict["vid"] = "Vid" + str(key)
    def substitute(self):
        return self.template.substitute(self.values_dict)

class _ModelWrapperInitGen:
    
    def _OnAvailableInit(self, model_object):
        if model_object.hasOnAvailable():
            return _SomeipOnAvailable(model_object).substitute()
        else:
            return ""
    
    def _getoa(self, model_object, filepaths_instance):
        res = ""
        services = model_object.getAllServicesForModel()
        model_as_client = model_object.getAllServicesForModelAsClient()
        for _, services in model_as_client.items():
            for service_name in services:
                if model_object.hasOnAvailable():
                    res += _SetOnAvailable(service_name, model_object.serviceDefinitionFileNameFromServiceName(service_name), filepaths_instance).substitute()
        
        return res
    
    
    def _ddsInit(self, model_object):
        res = ""

        all_outs = model_object.getAllDdsOuts()
        for model_method in all_outs:
            res += _DdsTopicOut(model_method).substitute()

        all_ins = model_object.getAllDdsIn()
        for model_method in all_ins:
            res += _DdsTopicIn(model_object,model_method).substitute()
        return res

    def _timerInit(self, model_object):
        if model_object.hasTimer():
            return _TimerInit(model_object).substitute()
        else:
            return ""
        
    def _someipHandlers(self, model_object):
        res = ""
        for vid in model_object.getAllvIdsForModel():
            res += _SomeipHandlers(vid).substitute()

        return res
    
    def _getVids(self, model_object):
        res = ""
        vidsList = model_object.getAllvIdsForModel();
        for vid in vidsList:
            res += f'\"vid{vid}\", '
        
        return res[:-2]
    
    def __init__(self, model_object, filepaths_instance):
        self.template = mwt.wrapper_init_template
        self.values_dict = {}
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        self.values_dict["someip_init"], _, _ = _someipInit(model_object)
        self.values_dict["on_available"] = self._OnAvailableInit(model_object)
        self.values_dict["set_oa"] = self._getoa(model_object, filepaths_instance)
        self.values_dict["dds_init"] = self._ddsInit(model_object)
        self.values_dict["timer_init"] = self._timerInit(model_object)
        self.values_dict["someip_handlers"] = self._someipHandlers(model_object)
        self.values_dict["numVIds"] = len(model_object.getAllvIdsForModel())
        self.values_dict["vids"] = self._getVids(model_object)
    
    def substitute(self):
        return self.template.substitute(self.values_dict)


class _ModelWrapperTerminateGen:

    def __init__(self, model_object):
        self.template = mwt.wrapper_terminate_template
        self.values_dict = {}
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_class"] = model_object.getModelClassName()

    def substitute(self):
        return self.template.substitute(self.values_dict)


class _ModelWrapperClassDeclaration:

    def __init__(self, model_object, filepaths_instance):
        self.template = mwt.wrapper_class_declaration_template
        self.values_dict = {}
        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["model_class"] = model_object.getModelClassName()
        _ , self.values_dict["event_method_id_declarations"], self.values_dict["event_method_id_definition"] = _someipInit(model_object)
        self.values_dict["wrapper_init"] = _ModelWrapperInitGen(model_object, filepaths_instance).substitute()
        self.values_dict["wrapper_terminate"] = _ModelWrapperTerminateGen(model_object).substitute()

    def substitute(self):
        return self.template.substitute(self.values_dict)


class ModelWrapperHeaderGen:

    def __init__(self, model_object, filepaths_instance):
        self.template = mwt.wrapper_header
        self.values_dict = {}

        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["wrapper_class_declaration"] = _ModelWrapperClassDeclaration(model_object, filepaths_instance).substitute()

    def substitute(self):
        return self.template.substitute(self.values_dict)
