import os

class Filepaths:

    def __init__(self, args):
        
        # 'required' arguments 
        self.model_name = str(args.modelname)
        self.model_config = str(args.modelconfig)
        self.codegen_dir = str(args.codegendir)
        self.service_mapping = str(args.servicemapping)
        self.servicedef_dir = str(args.servicedefdir)
        self.ipcmapping_dir = str(args.ipcmappingdir)

        # output filenames 
        self.model_converter_filename = "DataConverter" + self.model_name + ".hpp"
        self.model_wrapper_header_filename = "Wrapper" + self.model_name + ".h"
        self.model_init_filename = self.model_name + "_init.cpp"
        self.model_out_filename = self.model_name + "_out.cpp"
        self.model_dltlogger_filename = "dlt_logger.hpp"
        self.model_globalvar_header_filename = self.model_name + "_global_vars.hpp"
        self.model_globalvar_filename = self.model_name + "_global_vars.cpp"
        self.model_protoincludes_filename = "ProtoIncludes" + self.model_name + ".hpp"
        self.model_protodataconverter_filename = "ProtoDataConverter" + self.model_name + ".cpp"
        self.model_playbackdataconverter_filename = "PlaybackDataConverter" + self.model_name + ".hpp"

        self.model_gtest_initmapping_filename = "gtest" + self.model_name + "Init.cpp"
        self.model_gtest_initnomapping_filename = "gtest" + self.model_name + "InitNoMapping.cpp"
        self.model_gtest_out_filename = "gtest" + self.model_name + "Out.cpp"
        self.model_gtest_notify_filename = "gtest" + self.model_name + "NotifyChannel.cpp"
        self.model_gtest_message_filename = "gtest" + self.model_name + "MessageChannel.cpp"
        self.model_gtest_someipprovider_filename = "gtest" + self.model_name + "SomeipServiceProvider.cpp"
        self.model_gtest_init_timer_filename = "gtest" + self.model_name + "InitTimer.cpp"
        self.model_gtest_cmakelist_filename = "CMakeLists.txt"
        

        # output filepaths  
        self.model_converter_filepath = os.path.join(self.codegen_dir, self.model_converter_filename)
        self.model_wrapper_header_filepath = os.path.join(self.codegen_dir, self.model_wrapper_header_filename)
        self.model_init_filepath = os.path.join(self.codegen_dir, self.model_init_filename)
        self.model_out_filepath = os.path.join(self.codegen_dir, self.model_out_filename)
        self.model_dltlogger_filepath = os.path.join(self.codegen_dir, self.model_dltlogger_filename)
        self.model_globalvar_header_filepath = os.path.join(self.codegen_dir, self.model_globalvar_header_filename)
        self.model_globalvar_filepath = os.path.join(self.codegen_dir, self.model_globalvar_filename)
        self.model_protoincludes_filepath = os.path.join(self.codegen_dir, self.model_protoincludes_filename)
        self.model_protodataconverter_filepath = os.path.join(self.codegen_dir, self.model_protodataconverter_filename)
        self.model_playbackdataconverter_filepath = os.path.join(self.codegen_dir, self.model_playbackdataconverter_filename)

        self.model_gtest_initmapping_filepath = os.path.join(self.codegen_dir, self.model_gtest_initmapping_filename)
        self.model_gtest_initnomapping_filepath = os.path.join(self.codegen_dir, self.model_gtest_initnomapping_filename)
        self.model_gtest_out_filepath = os.path.join(self.codegen_dir, self.model_gtest_out_filename)
        self.model_gtest_notify_filepath = os.path.join(self.codegen_dir, self.model_gtest_notify_filename)
        self.model_gtest_message_filepath = os.path.join(self.codegen_dir, self.model_gtest_message_filename)
        self.model_gtest_someipprovider_filepath = os.path.join(self.codegen_dir, self.model_gtest_someipprovider_filename)
        self.model_gtest_init_timer_filepath = os.path.join(self.codegen_dir, self.model_gtest_init_timer_filename)
        self.model_gtest_cmakelist_filepath = os.path.join(self.codegen_dir, self.model_gtest_cmakelist_filename)

    def getModelConfigFilepath(self):
        return self.model_config

    def getProtoIncludesHeaderFilepath(self):
        return self.model_protoincludes_filepath

    def getProtoDataConverterFilepath(self):
        return self.model_protodataconverter_filepath

    def getPlaybackDataConverterFilepath(self):
        return self.model_playbackdataconverter_filepath

    def getModelCodegenDirPath(self):
        return self.codegen_dir

    def getModelDataConverterFilepath(self):
        return self.model_converter_filepath

    def getModelWrapperHeaderFilepath(self):
        return self.model_wrapper_header_filepath

    def getModelInitFilepath(self):
        return self.model_init_filepath

    def getModelGlobalVarHeaderFilepath(self):
        return self.model_globalvar_header_filepath

    def getModelGlobalVarFilepath(self):
        return self.model_globalvar_filepath

    def getModelOutFilepath(self):
        return self.model_out_filepath

    def getModelDltloggerFilepath(self):
        return self.model_dltlogger_filepath

    def getModelGtestInitMappingFilepath(self):
        return self.model_gtest_initmapping_filepath

    def getModelGtestInitNoMappingFilepath(self):
        return self.model_gtest_initnomapping_filepath

    def getModelGtestOutFilepath(self):
        return self.model_gtest_out_filepath

    def getModelGtestNotifyFilepath(self):
        return self.model_gtest_notify_filepath

    def getModelGtestMessageFilepath(self):
        return self.model_gtest_message_filepath

    def getModelGtestSomeipProviderFilepath(self):
        return self.model_gtest_someipprovider_filepath

    def getModelGtestCmakeListFilepath(self):
        return self.model_gtest_cmakelist_filepath

    def getModelGtestInitTimerFilepath(self):
        return self.model_gtest_init_timer_filepath

    def getServiceMappingFilepath(self):
        return self.service_mapping

    def getServiceDefinitionDirPath(self):
        return self.servicedef_dir

    def getIPCMappingDir(self):
        return self.ipcmapping_dir
    
    def getProtoPath(self):
        return self.servicedef_dir
