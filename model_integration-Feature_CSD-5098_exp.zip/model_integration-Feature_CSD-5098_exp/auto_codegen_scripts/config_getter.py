import utils
import global_data

##### helper functions class

class DataConverterHelper:

    #check if the message_name starts with rep_ and not followed by byt_ or str_
    @staticmethod
    def isRepeated(message_name):
        if(message_name[:4] == "rep_" and not (message_name[:8] == "rep_byt_" or message_name[:8] == "rep_str_")):
            return True
        return False

    #check if the message_name starts with rep_ and followed by byt_ or str_( i.e starts with rep_byt_ or rep_str_)
    @staticmethod
    def isRepStrByt(message_name):
        if(message_name[:8] == "rep_byt_" or message_name[:8] == "rep_str_"):
            return True
        return False
    
    #check if the message_name starts with byt_ or str_
    @staticmethod
    def isStrByt(message_name):
        if (message_name[:4] == "str_") or ( message_name[:4] == "byt_"):
            return True
        return False

    @staticmethod
    def isStr(model_dtype):
        return model_dtype[:4]=="str_"
    
    @staticmethod
    def isByt(model_dtype):
        return model_dtype[:4]=="byt_"
    
    # ---------- Optional-type prefix helpers ----------
    @staticmethod
    def isOptional(message_name):
        if not isinstance(message_name, str):
            return False
        return message_name.startswith("opt_")

    @staticmethod
    def isOptByt(message_name):
        if not isinstance(message_name, str):
            return False
        return message_name.startswith("opt_byt_")

    @staticmethod
    def isOptStr(message_name):
        if not isinstance(message_name, str):
            return False
        return message_name.startswith("opt_str_")

    @staticmethod
    def generationNeeded(message):
        if message["model_struct_name"] in global_data.dependentStructsList:
            return True
        return False

    @staticmethod
    def helperDependentStructs(messageName, IPCMappingFileName):
        Flag = True
        if messageName not in global_data.dependentStructsList:
            for message in global_data.ipc_mapping_data[IPCMappingFileName]["messages"]:
                if (message["message"] == messageName) or (message["model_struct_name"] == messageName):
                    Flag = False
                    global_data.dependentStructsList.add(message["model_struct_name"])
                    if isinstance(message["members"],dict):
                        if (utils.Utils.is_enum(message["members"]["model_dtype"]) == False) & (message["members"]["model_dtype"] not in utils.primitive) & (DataConverterHelper.isRepStrByt(message["members"]["model_dtype"]) == False) & (DataConverterHelper.isStrByt(message["members"]["model_dtype"]) == False):
                              DataConverterHelper.helperDependentStructs(message["members"]["model_dtype"], IPCMappingFileName)
                    else:
                      for member in message["members"]:
                          if (utils.Utils.is_enum(member["model_dtype"]) == False) & (member["model_dtype"] not in utils.primitive) & (DataConverterHelper.isRepStrByt(member["model_dtype"]) == False) & (DataConverterHelper.isStrByt(member["model_dtype"]) == False):
                              DataConverterHelper.helperDependentStructs(member["model_dtype"], IPCMappingFileName)
        if Flag:
            if isinstance(global_data.ipc_mapping_data[IPCMappingFileName]["custom_types"], dict):
                custom_type = global_data.ipc_mapping_data[IPCMappingFileName]["custom_types"]
                if messageName == custom_type["model_struct_name"]:
                    global_data.dependentStructsList.add(custom_type["model_struct_name"])
                    for member in custom_type["members"]:
                        if (utils.Utils.is_enum(member["model_dtype"]) == False) & (member["model_dtype"] not in utils.primitive) & (DataConverterHelper.isRepStrByt(member["model_dtype"]) == False) & (DataConverterHelper.isStrByt(member["model_dtype"]) == False):
                            DataConverterHelper.helperDependentStructs(member["model_dtype"], IPCMappingFileName)
            else:
                for custom_type in global_data.ipc_mapping_data[IPCMappingFileName]["custom_types"]:
                    if messageName == custom_type["model_struct_name"]:
                        global_data.dependentStructsList.add(custom_type["model_struct_name"])
                        for member in custom_type["members"]:
                            if (utils.Utils.is_enum(member["model_dtype"]) == False) & (member["model_dtype"] not in utils.primitive) & (DataConverterHelper.isRepStrByt(member["model_dtype"]) == False) & (DataConverterHelper.isStrByt(member["model_dtype"]) == False):
                                DataConverterHelper.helperDependentStructs(member["model_dtype"], IPCMappingFileName)


    @staticmethod
    def findCustomTypeInfo(dtype, ipc_mapping_file):
        if "custom_types" not in global_data.ipc_mapping_data[ipc_mapping_file]:
            #print("[Info]: Custom Types not defined for DDS Topic Mapping")
            return None
        if isinstance(global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"], dict):
            custom_type = global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]
            if custom_type["model_struct_name"] == dtype:
                return custom_type
        else:
            for custom_type in global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]:
                if custom_type["model_struct_name"] == dtype:
                    return custom_type
        print(f"[Warning]: Custom type: {dtype} not found in ipc mapping file: {ipc_mapping_file}")
        return None
    
    @staticmethod
    def findOptionalTypeInfo(dtype, ipc_mapping_file):
        """
        Returns the optional type info dict for 'dtype' or None if not found.
        {
          "has_field": "has_field",
          "field": "field",
          "model_struct_name": "opt_uint32",
          "members": [ ... ]
        }
        """
        data = global_data.ipc_mapping_data.get(ipc_mapping_file, {})
        opt_section = data.get("optional_types")
        if not opt_section:
            # print("[Info]: Optional Types not defined for this mapping")
            return None

        if isinstance(opt_section, dict):
            if opt_section.get("model_struct_name") == dtype:
                return opt_section
        else:
            for opt_type in opt_section:
                if opt_type.get("model_struct_name") == dtype:
                    return opt_type

        print(f"[Warning]: Optional type: {dtype} not found in ipc mapping file: {ipc_mapping_file}")
        return None


    @staticmethod
    def findCustomMember(message_name, ipc_mapping_file):
        if "custom_types" not in global_data.ipc_mapping_data[ipc_mapping_file]:
            #print("[Info]: Custom Types not defined for DDS Topic Mapping")
            return []
        if isinstance(global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"], dict):
            custom_type = global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]
            if custom_type["model_struct_name"] == message_name:
                return custom_type["members"]
        else:
            for custom_type in global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]:
                if custom_type["model_struct_name"] == message_name:
                    return custom_type["members"]
        
        return []

    @staticmethod
    def isACustomTypeFromIPCMappingFile(dtype, ipc_mapping_file):
        
        if "custom_types" not in global_data.ipc_mapping_data[ipc_mapping_file]:
            #print("[Info]: Custom Types not defined for DDS Topic Mapping")
            return False
        if isinstance(global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"], dict):
            if global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]["model_struct_name"] == dtype:
                return True
        else:
            for custom_type in global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]:
                if custom_type["model_struct_name"] == dtype:
                    return True
        
        return False
    
    
    @staticmethod
    def isAOptionalTypeFromIPCMappingFile(dtype, ipc_mapping_file):
        """
        Returns True if 'dtype' is declared under 'optional_types' in the given mapping.
        Works for both list and dict forms.
        """
        data = global_data.ipc_mapping_data.get(ipc_mapping_file, {})
        opt_section = data.get("optional_types")
        if not opt_section:
            return False

        if isinstance(opt_section, dict):
            return opt_section.get("model_struct_name") == dtype

        # Assume iterable/list
        for opt_type in opt_section:
            if opt_type.get("model_struct_name") == dtype:
                return True
        return False


    @staticmethod
    def isAnEnumFromIPCMappingFile(dtype, ipc_mapping_file):
        if isinstance(global_data.ipc_mapping_data[ipc_mapping_file]["enums"], dict):
            if global_data.ipc_mapping_data[ipc_mapping_file]["enums"]["model_enum_name"] == dtype:
                return True
        else:
            for enum in global_data.ipc_mapping_data[ipc_mapping_file]["enums"]:
                if enum["model_enum_name"] == dtype:
                    return True
        
        return False

    @staticmethod
    def isAMessageFromIPCMappingFile(dtype, ipc_mapping_file):
        
        for message in global_data.ipc_mapping_data[ipc_mapping_file]["messages"]:
            if message["model_struct_name"] == dtype:
                return True
        
        return False
    
    @staticmethod
    def GetMessageFromIPCMappingFile(dtype, ipc_mapping_file):
        
        messages = global_data.ipc_mapping_data[ipc_mapping_file]["messages"]
        
        if isinstance(messages, dict):
            messages = [messages]
        
        for message in messages:
            if message["model_struct_name"] == dtype:
                return message
        
        return None
    
    def GetDependentMessageFromIPCMappingFile(dtype, ipc_mapping_file):
        # first check if it is present in messages section
        messages = global_data.ipc_mapping_data[ipc_mapping_file]["messages"]
        
        if isinstance(messages, dict):
            messages = [messages]
        
        for message in messages:
            if message["model_struct_name"] == dtype:
                return message
            
        # check if it is present in custom types section 
        custom_types = global_data.ipc_mapping_data[ipc_mapping_file]["custom_types"]
        
        if isinstance(custom_types, dict):
            custom_types = [custom_types]

        for custom_type in custom_types:
            if custom_type["model_struct_name"]==dtype:
                new_dtype = None
                for member in custom_type["members"]:
                    if member["model_member_name"]=="payload":
                        new_dtype=member["model_dtype"]
                if new_dtype:
                    return DataConverterHelper.GetDependentMessageFromIPCMappingFile(new_dtype,ipc_mapping_file)
                else:
                    return None
        
        return None



    @staticmethod
    def findIPCMembers(message_name , ipc_mapping_file):
    
        for message in global_data.ipc_mapping_data[ipc_mapping_file]["messages"]:
            if message["model_struct_name"] == message_name:
                return message["members"]
        return []
    
    @staticmethod
    def isStringType(model_dtype, ipc_mapping):
        return DataConverterHelper.isACustomTypeFromIPCMappingFile(model_dtype, ipc_mapping) and DataConverterHelper.isStr(model_dtype)

    @staticmethod
    def isBytesType(model_dtype, ipc_mapping):
        return DataConverterHelper.isACustomTypeFromIPCMappingFile(model_dtype, ipc_mapping) and DataConverterHelper.isByt(model_dtype)
