import gtest_model_out_template as gmot
import class_definition

class GtestModelOut:
  gtest = ""
  def __init__(self, model_object):
    self.gtest += self.constructModelInitClass(model_object) + self.constructSomeIpRequestOut(model_object) + self.constructSomeIpNotifyOut(model_object) + self.constructsomeipResponseOut(model_object) + self.constructddsOut(model_object)


  def constructModelInitClass(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    values_dict["ModelWrapperHeader"] = f"Wrapper{modelName}.h"
    fixtureClass = f'Gtest{modelName}Out'
    values_dict["model_name"] = modelName
    values_dict["modelOutClass"] = fixtureClass
    values_dict["model_class"] = model_object.getModelClassName()
    values_dict["model_name"] = model_object.getModelName()
    values_dict["vsomeipApp_declarations"], values_dict["vsomeipApp_definitions"], values_dict["someipApp_map"] = self.constructSomeipApp(model_object)
    values_dict["someipChannel_declarations"], values_dict["someipChannel_definitions"] = self.constructSomeipChannel(model_object)
    return gmot.modelOutClass.substitute(values_dict)
  
  def constructSomeipChannel(self, model_object):
    someipChannel_declarations = ""
    someipChannel_definitions = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      someipChannel_declarations += f'std::shared_ptr<SomeipChannel> mSomeipChannel_vid{str(vid)} = nullptr;\n'
      someipChannel_definitions += f'mSomeipChannel_vid{str(vid)} = std::make_shared<SomeipChannel>(mApp_vid{str(vid)}, 0x001);\n'
    return someipChannel_declarations, someipChannel_definitions
  
  def constructSomeipApp(self, model_object):
    vsomeipApp_declarations = ""
    vsomeipApp_definitions = ""
    someipApp_mapItems = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      vsomeipApp_declarations += f'std::shared_ptr<vsomeip::application> mApp_vid{str(vid)} = nullptr;\n'
      vsomeipApp_definitions += f'mApp_vid{str(vid)} = std::make_shared<vsomeip::application>();\n'
      someipApp_mapItems += f'someipApp_map[\"vid{str(vid)}\"] = mApp_vid{str(vid)};\n'
    return vsomeipApp_declarations, vsomeipApp_definitions, someipApp_mapItems
  
  def constructSomeIpRequestOut(self, model_object):
    someIpRequestOut = ""
    request_outs = model_object.getAllSomeipRequestOuts()
    for vid, modelMethods in request_outs.items():
      for modelMethod in modelMethods:
        values_dict = {}
        modelName = model_object.getModelName()
        fixtureClass = f'Gtest{modelName}Out'
        values_dict["modelOutClass"] = fixtureClass
        isEmpty = modelMethod.checkIfModelEventHasArgument()
        eventName = modelMethod.getMessage()
        if not "persistency" in modelMethod.getMethodName():
          if isEmpty:
              # add test cases for non-empty request.
              values_dict["package_name"] = modelMethod.getPackageName()
              values_dict["funName"] = modelMethod.getMethodName()
              values_dict["proto_request"] = eventName
              values_dict["proto_response"] = model_object.getCorrespondingResponseForRequest(modelMethod)
              values_dict["model_struct"] = modelMethod.getModelStructName()
              values_dict["appName"] = f'mApp_vid{str(vid)}'
              values_dict["vid"] = str(vid)
              someIpRequestOut += gmot.someipRequestOutNonempty.substitute(values_dict)
              # res += SomeipNonEmptyRequestOut(model_data, modelMethod).substitute()
          else:
              eventName = modelMethod.getMessage()
              values_dict["package_name"] = modelMethod.getPackageName()
              values_dict["funName"] = modelMethod.getMethodName()
              values_dict["proto_request"] = eventName
              values_dict["proto_response"] = model_object.getCorrespondingResponseForRequest(modelMethod)
              values_dict["appName"] = f'mApp_vid{str(vid)}'
              values_dict["vid"] = str(vid)
              someIpRequestOut += gmot.someipRequestOutEmpty.substitute(values_dict)

    return someIpRequestOut
  
  def constructSomeIpNotifyOut(self, model_object):
    someipNotifyOut = ""

    values_dict = {}
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}Out'
    values_dict["modelOutClass"] = fixtureClass

    notify_outs = model_object.getAllSomeipNotifyOuts()
    for vid, modelMethods in notify_outs.items():
        for modelMethod in modelMethods:
          eventName = modelMethod.getMessage()
          values_dict["package_name"] = modelMethod.getPackageName()
          values_dict["funName"] = modelMethod.getMethodName()
          values_dict["model_name"] = model_object.getModelName()
          values_dict["model_struct"] = modelMethod.getModelStructName()
          values_dict["proto_notify"] = eventName
          values_dict["appName"] = f'mApp_vid{str(vid)}'
          values_dict["vid"] = str(vid)
          someipNotifyOut += gmot.someipNotifyOut.substitute(values_dict)

    return someipNotifyOut
  
  def constructsomeipResponseOut(self, model_object):
    someipResponseOut = ""

    values_dict = {}
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}Out'
    values_dict["modelOutClass"] = fixtureClass

    response_outs = model_object.getAllSomeipResponseOuts()

    for vid, modelMethods in response_outs.items():
        for modelMethod in modelMethods:
          event_name = modelMethod.getMessage()
          values_dict["package_name"] = modelMethod.getPackageName()
          values_dict["funName"] = modelMethod.getMethodName()
          values_dict["model_name"] = model_object.getModelName()
          values_dict["model_struct"] = modelMethod.getModelStructName()
          values_dict["proto_request"] = model_object.getCorrespondingRequestForResponse(modelMethod)
          values_dict["proto_response"] = event_name
          values_dict["appName"] = f'mApp_vid{str(vid)}'
          values_dict["vid"] = str(vid)
          someipResponseOut += gmot.someipResponseOut.substitute(values_dict)

    return someipResponseOut
  
  def constructddsOut(self, model_object):
    ddsOut = ""

    values_dict = {}
    modelName = model_object.getModelName()
    fixtureClass = f'Gtest{modelName}Out'
    values_dict["modelOutClass"] = fixtureClass

    dds_outs = model_object.getAllDdsOuts()

    for model_method in dds_outs:
      values_dict["model_struct"] = model_method.getModelStructName()
      values_dict["model_class"] = model_object.getModelClassName()
      values_dict["model_name"] = model_object.getModelName()
      values_dict["topic_name"] = model_method.getTopicName()
      values_dict["funName"] = model_method.getMethodName()
      values_dict["method_name"] = model_method.getMethodName()
      values_dict["dataConverter"] = "DataConverter" + model_object.getModelName()
      
      ddsOut += gmot.ddsOutFail.substitute(values_dict)
      ddsOut += gmot.ddsOutSuccess.substitute(values_dict)

    return ddsOut
  
  def substitute(self):
     return self.gtest
