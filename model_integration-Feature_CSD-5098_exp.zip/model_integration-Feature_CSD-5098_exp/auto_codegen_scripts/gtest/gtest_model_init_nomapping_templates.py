from string import Template

offerService = Template('''
  EXPECT_CALL(*${appName}, offer_service(_,_,_)).Times(${offerServices});
''')
requestService = Template('''
  EXPECT_CALL(*${appName}, request_service(_,_)).Times(${requestServies});
''')
registerMessageHanlder = Template('''
  EXPECT_CALL(*${appName}, register_message_handler_fake(_,_,_,_)).Times(${registerMessageHanlder});
''')

registerAvailabilityHanlder = Template('''
  
''')
offerEvent = Template('''
  EXPECT_CALL(*${appName}, offer_event(_,_,_,_,_)).Times(${offerEvent});
''')

modelInitNoMappingClass = Template('''
#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "${ModelWrapperHeader}"
#include <vsomeip/vsomeip.hpp>
#include "WorkExecutor.h"
#include <DDSEntityFactory.hpp>

using ::testing::_;
using ::testing::Eq;
using ::testing::Matcher;
using ::testing::Pointee;
using ::testing::Return;

using DDSEntityFactoryInterface = jlr::cccm::di::dds::DDSEntityFactoryInterface;
using DDSEntityFactory = jlr::cccm::di::dds::DDSEntityFactory;
using DDSManager = jlr::cccm::di::dds::DDSManager;
using DDSManagerInterface = jlr::cccm::di::dds::DDSManagerInterface;
using ModelController = jlr::cccm::di::ModelController<$modelClass>;
class $model_name_init : public ::testing::Test
{
  void SetUp()
  { 
    $vsomeipApp_definitions
                                   
    auto model_ptr = std::make_shared<${modelClass}>();

    context = std::make_shared<cccm::di::launcher::LauncherContext>();

    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
    $someipApp_map
    context->someipApp_map = someipApp_map;
    context->workExecutor = nullptr;
    context->ddsFactory = std::make_shared<DDSEntityFactory>(jlr::cccm::di::dds::SHARED_MEM);
    context->someipMappingFilename = "dummyMapping.json";
  }

  void TearDown()
  {
  }

  public:

    std::string mWorkExecutorName = "workExecutor";

    $vsomeipApp_declarations
    
    std::shared_ptr<${modelClass}> model_ptr
      = std::make_shared<${modelClass}>();

    std::shared_ptr<cccm::di::ModelLibInterface> modelWrapperPtr
      = std::make_shared<
          cccm::di::models::Wrapper${model_name}<${modelClass}>
          >(model_ptr);

    std::shared_ptr<cccm::di::launcher::LauncherContext> context = nullptr;

};

''')

availibilityFuncs = Template('''
  auto availibilityFuncs_${vid} = $appName->availibilityHandler;
  availibilityFuncs_${vid}(1,1,1);
''')

modelInitNoMappingSuccess = Template('''
TEST_F($model_name_init, model_init_Success_1)
{
  // ASSERT_DEATH(model_init(mApp, nullptr), "");
  // jlr::cccm::di::get_model_controller().lock()->init_model_dds();
  // auto dds_handler = jlr::cccm::di::get_model_controller().lock()->get_dds_handler();

  ${offerService}
                            
  ${requestService}
                            
  ${registerAvailabilityHanlder}
                            
  ${registerMessageHanlder}
  
  ${offerEvent}

  // This will set the default return value for any mock function returning bool to true
  // Since the dds_manager is a hidden dependency, there's no way to control the mock.
  // So, below line prevents all the DDSManager api's to return false as default value
  ::testing::DefaultValue<bool>::Set(true);

  modelWrapperPtr->init(context);

  ::testing::DefaultValue<bool>::Clear();

  // Doesn't call with right service ID and instance ID, but makes sure 
  // that the lambda registered works correctly 
  ${availibilityFuncs}

  modelWrapperPtr->terminate();
}
''')

modelNoMappingOnDataAvailable = Template('''
TEST_F($model_name_init, $ddsRxTestName)
{
  ::testing::DefaultValue<bool>::Set(true);
  modelWrapperPtr->init(context);
  ::testing::DefaultValue<bool>::Clear();

  string topic = "$topic_name";
  auto dds_handler = jlr::cccm::di::get_model_controller().lock()->get_dds_handler();
 
  std::shared_ptr<DDSManager> manager = std::dynamic_pointer_cast<DDSManager>(
    dds_handler->get_manager()
  );

  // Creating an actual DataReader object with the given topic, to 
  // simulate on_data_available, because we can't pass Mock DataReader
  // As of now we are using real fastdds objects.
  eprosima::fastdds::dds::DomainParticipant* participant_ = nullptr;
  eprosima::fastdds::dds::Subscriber* subscriber_ = nullptr;
  eprosima::fastdds::dds::Topic* topic_ = nullptr;
  eprosima::fastdds::dds::DataReader* reader_ = nullptr;
  eprosima::fastdds::dds::TypeSupport type_(new $topic_pubsub_type);

  eprosima::fastdds::dds::DomainParticipantQos pqos = eprosima::fastdds::dds::PARTICIPANT_QOS_DEFAULT;
  pqos.name("Participant_sub");
  auto factory = DomainParticipantFactory::get_instance();

  participant_ = factory->create_participant(0, pqos);
  eprosima::fastdds::dds::SubscriberQos sqos = eprosima::fastdds::dds::SUBSCRIBER_QOS_DEFAULT;
  subscriber_ = participant_->create_subscriber(sqos, nullptr);

  type_.register_type(participant_);

  eprosima::fastdds::dds::TopicQos tqos = eprosima::fastdds::dds::TOPIC_QOS_DEFAULT;
  topic_ = participant_->create_topic(topic, topic, tqos);

  eprosima::fastdds::dds::DataReaderQos rqos = eprosima::fastdds::dds::DATAREADER_QOS_DEFAULT;
  reader_ = subscriber_->create_datareader(topic_, rqos);

  dds_handler->on_data_available(reader_);

  modelWrapperPtr->terminate();
}
''')
