import gtest_model_init_timer_templates as gmitt


class GtestModelInitTimer:
  gtest = ""
  
  def __init__(self, model_object):
    self.gtest = (
      self.constructModelInitWithTimerFixture(model_object) +
      self.constructModelInitNoMappingTest(model_object) +
      self.constructModelInitWithMappingTest(model_object) 
    )
  def constructSomeipApp(self, model_object):
    vsomeipApp_declarations = ""
    vsomeipApp_definitions = ""
    someipApp_mapItems = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      vsomeipApp_declarations += f'\t\tstd::shared_ptr<vsomeip::application> mApp_vid{str(vid)} = nullptr;\n'
      vsomeipApp_definitions += f'\t\tmApp_vid{str(vid)} = std::make_shared<vsomeip::application>();\n'
      someipApp_mapItems += f'someipApp_map[\"vid{str(vid)}\"] = mApp_vid{str(vid)};\n'
    return vsomeipApp_declarations, vsomeipApp_definitions, someipApp_mapItems
  # someipApp_map.insert({"vid10", mApp});
  def constructAvailibilityHandlerFuncs(self, model_object):
    res = ""
    all_vids = model_object.getAllvIdsForModel();
    for vid in all_vids:
      values_dict = {}
      values_dict["appName"] = f'mApp_vid{str(vid)}'
      values_dict["vid"] = str(vid)
      res += gmitt.availibilityFuncs.substitute(values_dict)
    return res

  def constructModelInitNoMappingTest(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    model_as_client = model_object.getAllServicesForModelAsClient()
    fixtureClass = f'Gtest{modelName}WithTimer'
    values_dict["TestFixtureName"] = fixtureClass
    values_dict["availibilityFuncs"] = ""
    if len(model_as_client) > 0:
      values_dict["availibilityFuncs"] = self.constructAvailibilityHandlerFuncs(model_object)
    return gmitt.modelInitNoMapping.substitute(values_dict)
  
  def constructModelInitWithMappingTest(self, model_object):
    values_dict = {}
    modelName = model_object.getModelName()
    model_as_client = model_object.getAllServicesForModelAsClient()
    fixtureClass = f'Gtest{modelName}WithTimer'
    values_dict["TestFixtureName"] = fixtureClass
    values_dict["availibilityFuncs"] = ""
    if len(model_as_client) > 0:
      values_dict["availibilityFuncs"] = self.constructAvailibilityHandlerFuncs(model_object)
    return gmitt.modelInitWithMapping.substitute(values_dict)

  
  def constructModelInitWithTimerFixture(self, model_object):
    values_dict = {}
    values_dict["modelClass"] =  model_object.getModelClassName()
    values_dict["dataConverter"] = "DataConverter" + model_object.getModelName()
    values_dict["model_init"] = "model_init_" + model_object.getModelName()
    modelName = model_object.getModelName()
    values_dict["model_name"] = modelName
    values_dict["ModelWrapperHeader"] = f"Wrapper{modelName}.h"
    fixtureClass = f'Gtest{modelName}WithTimer'
    values_dict["TestFixtureName"] = fixtureClass
    
    values_dict["offerService"] = ""
    model_as_server = model_object.getAllServicesForModelAsServer()
    for vid, services in model_as_server.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["offerServices"] = len(services)
      values_dict["offerService"] += gmitt.offerService.substitute(_values_dict)

    values_dict["registerAvailabilityHanlder"] = ""
    values_dict["requestService"] = ""
    model_as_client = model_object.getAllServicesForModelAsClient()
    for vid, services in model_as_client.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["requestServies"] = len(services)
      _values_dict["registerAvailabilityHanlder"] = len(services)

      values_dict["registerAvailabilityHanlder"] += gmitt.registerAvailabilityHanlder.substitute(_values_dict)
      values_dict["requestService"] += gmitt.requestService.substitute(_values_dict)

    values_dict["registerMessageHanlder"] = ""
    allSomeip_ins = model_object.AllModelSomeipIns()
    for vid, model_methods in allSomeip_ins.items():
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["registerMessageHanlder"] = len(model_methods)
      values_dict["registerMessageHanlder"] += gmitt.registerMessageHanlder.substitute(_values_dict)
    
    values_dict["offerEvent"]  = ""
    notify_outs = model_object.getAllSomeipNotifyOuts()
    for vid, notify_out in notify_outs.items():
      offerEvent = 0
      for item in notify_out:
        offerEvent += len(item.getAllEventGroupIDs())  
      _values_dict = {}
      _values_dict["appName"] = "mApp_vid" + str(vid) 
      _values_dict["offerEvent"] = offerEvent
      values_dict["offerEvent"] += gmitt.offerEvent.substitute(_values_dict)

    values_dict["vsomeipApp_declarations"], values_dict["vsomeipApp_definitions"], values_dict["someipApp_map"] = self.constructSomeipApp(model_object)

    return gmitt.modelInitWithTimerFixture.substitute(values_dict)
  
  def substitute(self):
    return self.gtest
