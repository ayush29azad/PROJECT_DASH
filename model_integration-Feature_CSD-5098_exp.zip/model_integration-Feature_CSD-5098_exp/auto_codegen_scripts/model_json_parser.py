import json 
class JsonParser:
    @staticmethod
    def read_json(path):
        with open(path, 'r') as src:
            try:
                data = json.load(src)
            except json.JSONDecodeError as e:
                print(f"Invalid JSON: {path}")
                print(f"[Error]: {e} on line {e.lineno}")  # JSONDecodeError provides lineno
                return False
        return data

    @staticmethod
    def write_json(dict, path):
        try:
            if not isinstance(dict, dict):
                raise TypeError("Input must be a dictionary")
            with open(path, "w") as outfile:
                json.dump(dict, outfile)
        except (IOError, TypeError) as e:
            print(f"Error writing JSON to {path}: {e}")
