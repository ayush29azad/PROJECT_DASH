import config_getter
import proto_includes_template
import utils
import global_data

class ProtoIncludesHeadersGen:

    def __init__(self, model_object):
        self.template = proto_includes_template.proto_includes_template
        self.values_dict = {}

        self.values_dict["MODEL_NAME"] = model_object.getModelName().upper()
        self.values_dict["includes"] = self.construct_includes(model_object)

    def construct_includes(self, model_object):
        res = ""
        proto_includes = model_object.getAllProtoIncludesForModel()

        for include in proto_includes:
            res += f"#include <{include}>\n"

        return res
    
    def substitute(self):
        return self.template.substitute(self.values_dict)
