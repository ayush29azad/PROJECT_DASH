from functools import reduce
import os

primitive = ["uint64_T", "uint32_T", "real32_T", "real32", "single" ,"uint16_T", "uint8_T", "int32_T", "int16_T", "int8_T", "boolean", "uint64", "uint32", "uint16", "uint8", "int32", "int16", "int8"]

class Utils:
    def is_enum(name):
        if "Enum" in str(name) or "enum" in str(name) or "enm" in str(name) or "Enm" in str(name):
            return True
        else :
            return False
        
    def unique(lst):
        res = reduce(lambda re, x: re+[x] if x not in re else re, lst, [])
        return res

    def write_to_file(filename, string_content):
        dirname = os.path.dirname(filename)

        try:
            if not os.path.exists(dirname):
                os.makedirs(dirname)

            with open(filename, "w") as file:
                file.write(string_content)
    
            print(f"[Info]: Generated file :", filename)

        except IOError as e:
            print(f"[Error]: writing to file:", filename)
            print(e)
