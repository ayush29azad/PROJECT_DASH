import unittest
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
autocodegen_dir = os.path.join(current_dir, '..') 

# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)
import input_testing
import model_json_parser
import global_data
import filepaths

class TestArgs:
    def __init__(self):
        self.modelname = None
        self.modelconfig = None
        self.codegendir = None
        self.servicemapping = None
        self.servicedefdir = None
        self.ipcmappingdir = None

test_args = TestArgs()
filepaths_instance = filepaths.Filepaths(test_args)

class TestInputTestingAndCombining(unittest.TestCase):

    # def test_someip_json_mapping_schema(self):
    #     #For valid test case
    #     filepaths_instance.service_mapping = current_dir +  "/SomeipJsonMappingTestCases/valid/config/model_someip_service_config.json"
    #     someip_json_mapping_data = model_json_parser.JsonParser.read_json(filepaths_instance.service_mapping)
    #     result = input_testing.Test.test_common_input_files(filepaths_instance)
    #     result2 = input_testing.Test.json_schema_validator.validate_model_someip_service_config(someip_json_mapping_data)
    #     self.assertEqual(result, result2)
    #     self.assertTrue(result)

    #     #For invalid test case
    #     filepaths_instance.service_mapping = current_dir +  "/SomeipJsonMappingTestCases/invalid/config/model_someip_service_config.json"
    #     someip_json_mapping_data = model_json_parser.JsonParser.read_json(filepaths_instance.service_mapping)
    #     result = input_testing.Test.test_common_input_files(filepaths_instance)
    #     result2 = input_testing.Test.json_schema_validator.validate_model_someip_service_config(someip_json_mapping_data)
    #     self.assertEqual(result, result2)
    #     self.assertFalse(result)

    def test_model_config_schema(self):
        global_data.ipc_mapping_data = {}
        modelconfigdir_path = current_dir + "/modelConfigSchemaTestCases/models/modelConfig"
        filepaths_instance.service_mapping = current_dir + "/modelConfigSchemaTestCases/config/model_someip_service_config.json"
        filepaths_instance.ipcmapping_dir = current_dir + "/modelConfigSchemaTestCases/models/IPCMapping/"
        filepaths_instance.servicedef_dir = current_dir + "/modelConfigSchemaTestCases/proto_files/"

        for i in range(0,49):
            
            with self.subTest(i=i):
                filepaths_instance.model_config =  os.path.join(modelconfigdir_path, f"test_case_{i}.json")
                model_data = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
                result = input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

                result2 = input_testing.Test.json_schema_validator.validate_modelConfig(model_data)
                self.assertEqual(result, result2)
                
                if i==0:
                    self.assertTrue(result)
                else:
                    self.assertFalse(result)
        

    def test_ipc_mapping_schema(self):
        global_data.ipc_mapping_data = {}
        modelconfigdir_path =  current_dir + "/IPCMappingSchemaTestCases/models/modelConfig"
        filepaths_instance.service_mapping = current_dir + "/IPCMappingSchemaTestCases/config/model_someip_service_config.json"
        filepaths_instance.ipcmapping_dir = current_dir + "/IPCMappingSchemaTestCases/models/IPCMapping/"
        filepaths_instance.servicedef_dir = current_dir + "/IPCMappingSchemaTestCases/proto_files/"
        for i in range(0,39):
            
            with self.subTest(i=i):
                filepaths_instance.model_config = os.path.join(modelconfigdir_path, f"test_case_{i}.json")
                model_data = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
                result = input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

                ipc_mapping_data = model_json_parser.JsonParser.read_json(os.path.join(filepaths_instance.ipcmapping_dir, f"test_case_{i}.json"))
                result2 = input_testing.Test.json_schema_validator.validate_ipc_mapping(ipc_mapping_data)
                self.assertEqual(result, result2)

                if i==0:
                    self.assertTrue(result)
                else:
                    self.assertFalse(result)
        

    def test_serviceJson_schema(self):
        global_data.ipc_mapping_data = {}
        modelconfigdir_path = current_dir + "/ServiceJsonSchemaTestCases/models/modelConfig"
        filepaths_instance.service_mapping = current_dir + "/ServiceJsonSchemaTestCases/config/model_someip_service_config.json"
        filepaths_instance.ipcmapping_dir = current_dir + "/ServiceJsonSchemaTestCases/models/IPCMapping/"
        filepaths_instance.servicedef_dir = current_dir + "/ServiceJsonSchemaTestCases/proto_files/"
        for i in range(0,25):
            
            with self.subTest(i=i):
                filepaths_instance.model_config = os.path.join(modelconfigdir_path, f"test_case_{i}.json")
                model_data = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
                result = input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

                service_json_data = model_json_parser.JsonParser.read_json(os.path.join(filepaths_instance.servicedef_dir, f"test_case_{i}.json"))
                result2 = input_testing.Test.json_schema_validator.validate_serviceJson(service_json_data)

                
                if i==0:
                    self.assertTrue(result)
                    self.assertTrue(result2)
                elif i==15:
                    # the someip json file does not have the required method field
                    # so the someip json schema will pass but the test case will fail
                    self.assertFalse(result)
                    self.assertTrue(result2)
                else:
                    self.assertFalse(result)
                    self.assertFalse(result2)
        

    def test_topic_mapping_schema(self):
        global_data.ipc_mapping_data = {}
        modelconfigdir_path = current_dir + "/TopicMappingSchemaTestCases/models/modelConfig"
        filepaths_instance.service_mapping = current_dir + "/TopicMappingSchemaTestCases/config/model_someip_service_config.json"
        filepaths_instance.ipcmapping_dir = current_dir + "/TopicMappingSchemaTestCases/models/IPCMapping/"
        filepaths_instance.servicedef_dir = current_dir + "/TopicMappingSchemaTestCases/proto_files/"
        for i in range(0,25):
            
            with self.subTest(i=i):
                filepaths_instance.model_config = os.path.join(modelconfigdir_path, f"test_case_{i}.json")
                model_data = model_json_parser.JsonParser.read_json(filepaths_instance.model_config)
                result = input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

                ipc_mapping_data = model_json_parser.JsonParser.read_json(os.path.join(filepaths_instance.ipcmapping_dir, f"proto_test_case_{i}.json"))
                result2 = input_testing.Test.json_schema_validator.validate_topicsMapping(ipc_mapping_data)
                self.assertEqual(result, result2)

                if i==0:
                    self.assertTrue(result)
                else:
                    self.assertFalse(result)
        

    def test_json_linking(self):
        global_data.ipc_mapping_data = {}
        modelconfigdir_path = current_dir + "/JsonLinkingTestCases/models/modelConfig"
        filepaths_instance.service_mapping = current_dir + "/JsonLinkingTestCases/config/model_someip_service_config.json"
        filepaths_instance.ipcmapping_dir = current_dir + "/JsonLinkingTestCases/models/IPCMapping/"
        filepaths_instance.servicedef_dir = current_dir + "/JsonLinkingTestCases/proto_files/"
        for i in range(0,10):
            
            with self.subTest(i=i):
                model_data = model_json_parser.JsonParser.read_json(os.path.join(modelconfigdir_path, f"test_case_{i}.json"))
                result = input_testing.Test(model_data, filepaths_instance).validate_and_combine_input_data()

                if i==0:
                    self.assertTrue(result)
                else:
                    self.assertFalse(result)              
        
    
if __name__ == '__main__':
    unittest.main()
