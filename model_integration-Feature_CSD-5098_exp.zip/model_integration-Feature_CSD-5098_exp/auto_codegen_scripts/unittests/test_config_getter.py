import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))    
autocodegen_dir = os.path.join(current_dir, '..') 
# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)  

import unittest
import global_data
import config_getter
import model_json_parser

class TestConfigGetter(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        super().__init__(methodName)
        ipc_mapping_dir = current_dir + "/ConfigGetterTestCases/models/IPCMapping"
        ipc_mapping_files = ["charging_service_mapping.json", "energymanagement_service_mapping.json", "DI_GUI_topics_mapping.json"]
        for ipc_mapping in ipc_mapping_files:
            if ipc_mapping not in global_data.ipc_mapping_data:
                global_data.ipc_mapping_data[ipc_mapping] = model_json_parser.JsonParser.read_json(os.path.join(ipc_mapping_dir, ipc_mapping))

    def test_isRepeated(self):
        valid_test_cases = ["rep_abc", "rep_", "rep_x", "rep_bytabc", "rep_strabc"]
        invalid_test_cases = ["rep_str_", "rep_byt_", "rep_str_x", "rep_byt_y", "abenxmc", "abcEnnm", "repabenxmc"]
        for test_case in valid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isRepeated(test_case)
                self.assertTrue(result)

        for test_case in invalid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isRepeated(test_case)
                self.assertFalse(result)

    def test_isRepStrByt(self):
        valid_test_cases = ["rep_str_", "rep_byt_", "rep_str_x", "rep_byt_y"]
        invalid_test_cases = ["rep_abc", "rep_", "rep_x", "rep_bytabc", "rep_strabc", "repabenxmc", "abenxmc"]
        
        for test_case in valid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isRepStrByt(test_case)
                self.assertTrue(result)

        for test_case in invalid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isRepStrByt(test_case)
                self.assertFalse(result)

    def test_isStrByt(self):
        valid_test_cases = ["str_", "byt_", "str_x", "byt_y"]
        invalid_test_cases = ["rep_str_", "rep_byt_", "rep_abc", "str", "byt", "bytabc", "strabc"]
        
        for test_case in valid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isStrByt(test_case)
                self.assertTrue(result)

        for test_case in invalid_test_cases:
            with self.subTest(test_case=test_case):
                result = config_getter.DataConverterHelper.isStrByt(test_case)
                self.assertFalse(result)
        

    def test_generationNeeded(self):
        global_data.dependentStructsList = set()
        message = {
        "message": "GetBatteryChargeResponse",
        "model_arg_name": "energymanagement_GetBatteryChargeResponse",
        "model_struct_name": "structenergymanagement_GetBatteryChargeResponse",
        "members": [
            {
            "proto_member_name": "batt_level_colour",
            "model_member_name": "batt_level_colour",
            "model_dtype": "energymanagement_EnumBattLevelColour"
            },
            {
            "proto_member_name": "battery_state_of_charge",
            "model_member_name": "battery_state_of_charge",
            "model_dtype": "uint32"
            },
            {
            "proto_member_name": "status",
            "model_member_name": "status",
            "model_dtype": "energymanagement_EnumStatus"
            }
        ]
        }
        result0 = config_getter.DataConverterHelper.generationNeeded(message)
        self.assertFalse(result0)

        global_data.dependentStructsList.add(message["model_struct_name"])

        result1 = config_getter.DataConverterHelper.generationNeeded(message)
        self.assertTrue(result1)

        global_data.dependentStructsList = set()
    
    def test_findCustomTypeInfo(self):
        valid_test_cases = [["rep_charging_PredictedChargeData", "charging_service_mapping.json"], ["str_uint8", "charging_service_mapping.json"], ["rep_energymanagement_PredictedChargeData", "energymanagement_service_mapping.json"]]
        invalid_test_cases = [["a", "charging_service_mapping.json"], ["b", "charging_service_mapping.json"], ["c", "DI_GUI_topics_mapping.json"], ["d", "energymanagement_service_mapping.json"]]
        
        for a, b in valid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.findCustomTypeInfo(a ,b)
                self.assertIsNotNone(result)

        for a, b in invalid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.findCustomTypeInfo(a ,b)
                self.assertIsNone(result)

    def test_findCustomMember(self):
        test_case_0 = ["rep_charging_PredictedChargeData", "charging_service_mapping.json"]
        test_case_1 = ["y", "charging_service_mapping.json"]
        test_case_2 = ["x", "DI_GUI_topics_mapping.json"]
        expected_result0 = [
            {
            "model_member_name": "payload_length",
            "model_dtype": "uint32"
            },
            {
            "model_member_name": "payload",
            "model_dtype": "structcharging_PredictedChargeData"
            }
        ]
        expected_result1 = []
        expected_result2 = []
        result0 = config_getter.DataConverterHelper.findCustomMember(test_case_0[0], test_case_0[1])
        self.assertEqual(result0, expected_result0)

        result1 = config_getter.DataConverterHelper.findCustomMember(test_case_1[0], test_case_1[1])
        self.assertEqual(result1, expected_result1)

        result1 = config_getter.DataConverterHelper.findCustomMember(test_case_2[0], test_case_2[1])
        self.assertEqual(result1, expected_result2)

    def test_isACustomTypeFromIPCMappingFile(self):
        valid_test_cases = [["rep_charging_PredictedChargeData", "charging_service_mapping.json"], ["str_uint8", "charging_service_mapping.json"], ["rep_energymanagement_PredictedChargeData", "energymanagement_service_mapping.json"]]
        invalid_test_cases = [["a", "charging_service_mapping.json"], ["b", "charging_service_mapping.json"], ["c", "DI_GUI_topics_mapping.json"], ["d", "energymanagement_service_mapping.json"]]
        
        for a, b in valid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(a, b)
                self.assertTrue(result)

        for a, b in invalid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(a, b)
                self.assertFalse(result)

    
    def test_isAnEnumFromIPCMappingFile(self):
        valid_test_cases = [["charging_EnumStatus", "charging_service_mapping.json"], ["enumSeatConfigurationVisualSeatbeltMinder", "DI_GUI_topics_mapping.json"], ["energymanagement_EnumPowertrainReadyStatus", "energymanagement_service_mapping.json"]]
        invalid_test_cases = [["EnumStatus", "charging_service_mapping.json"], ["energymanagement_EnumPowertrainReadyStatus", "charging_service_mapping.json"], ["charging_EnumChargeControlOperation", "DI_GUI_topics_mapping.json"], ["EnumPowertrainReadyStatus", "energymanagement_service_mapping.json"]]
        
        for a, b in valid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(a, b)
                self.assertTrue(result)

        for a, b in invalid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(a, b)
                self.assertFalse(result)

    def test_isAMessageFromIPCMappingFile(self):
        valid_test_cases = [["structcharging_PredictedChargeData", "charging_service_mapping.json"], ["structgoldenGUI", "DI_GUI_topics_mapping.json"], ["structenergymanagement_GetBatteryChargeResponse", "energymanagement_service_mapping.json"]]
        invalid_test_cases = [["structgoldenGUI", "charging_service_mapping.json"], ["energymanagement_EnumPowertrainReadyStatus", "charging_service_mapping.json"], ["structcharging_PredictedChargeData", "DI_GUI_topics_mapping.json"], ["EnumPowertrainReadyStatus", "energymanagement_service_mapping.json"]]
        
        for a, b in valid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(a, b)
                self.assertTrue(result)

        for a, b in invalid_test_cases:
            with self.subTest(a=a, b=b):
                result = config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(a, b)
                self.assertFalse(result)


    def test_findIPCMembers(self):
        test_case_0 = ["structenergymanagement_GetBatteryChargeResponse", "energymanagement_service_mapping.json"]
        test_case_1 = ["structgoldenGUI", "charging_service_mapping.json"]
        expected_result0 = [
            {
            "proto_member_name": "batt_level_colour",
            "model_member_name": "batt_level_colour",
            "model_dtype": "energymanagement_EnumBattLevelColour"
            },
            {
            "proto_member_name": "battery_state_of_charge",
            "model_member_name": "battery_state_of_charge",
            "model_dtype": "uint32"
            },
            {
            "proto_member_name": "status",
            "model_member_name": "status",
            "model_dtype": "energymanagement_EnumStatus"
            }
        ]
        expected_result1 = []
        result0 = config_getter.DataConverterHelper.findIPCMembers(test_case_0[0], test_case_0[1])
        self.assertEqual(result0, expected_result0)

        result1 = config_getter.DataConverterHelper.findIPCMembers(test_case_1[0], test_case_1[1])
        self.assertEqual(result1, expected_result1)

        
if __name__ == '__main__':
    unittest.main()
