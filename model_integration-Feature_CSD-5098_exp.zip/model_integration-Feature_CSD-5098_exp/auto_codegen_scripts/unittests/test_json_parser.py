import unittest
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
autocodegen_dir = os.path.join(current_dir, '..') 

# Add autocodegen to the Python path
sys.path.append(autocodegen_dir)

import model_json_parser
import json


class ModelJsonParser(unittest.TestCase):
    def test_read_json(self):
        jsonparser_readtc_path = current_dir + "/JsonParserTestCases/read_tc.json"
        result = model_json_parser.JsonParser.read_json(jsonparser_readtc_path)
        expected_result = {
            "test": {
                "a": "1",
                "b": "2",
                "c": "3"
            }
        }
        self.assertEqual(result, expected_result)

        jsonparser_errorreadtc_path = current_dir + "/JsonParserTestCases/error_read_tc.json"
        result = model_json_parser.JsonParser.read_json(jsonparser_errorreadtc_path)
        self.assertFalse(result)

    def test_write_json(self):
        jsonparser_writetc_path = current_dir + "/JsonParserTestCases/write_tc.json"
        expected_result = {
            "test": {
                "a": "1",
                "b": "2",
                "c": "3"
            }
        }
        
        model_json_parser.JsonParser.write_json(expected_result, jsonparser_writetc_path)
        with open(jsonparser_writetc_path, 'r') as src:
            result = json.load(src)

        self.assertEqual(result, expected_result)

if __name__ == '__main__':
    unittest.main()
