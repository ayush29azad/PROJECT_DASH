import model_global_vars_templates as mgvt

class ModelGlobalVarGen:
    
    def __init__(self, model_object):
        
        self.cpp_template = mgvt.cpp_file
        self.cpp_values_dict = {}
        self.cpp_values_dict["model_name"] = model_object.getModelName()
        
        self.hpp_template = mgvt.hpp_file
        self.hpp_values_dict = {}
        self.hpp_values_dict["MODEL_NAME"] = model_object.getModelName().upper()

    def substitute(self):
        return (
            self.hpp_template.substitute(self.hpp_values_dict),
            self.cpp_template.substitute(self.cpp_values_dict),
        )
