import config_getter
import proto_data_converters_template
import utils
import global_data

from class_definition import VSOMEIP_Event, VSOMEIP_Method, Model

from collections import deque

from typing import Union


class ProtoToModelGen:

    
    def __init__(self, message, package_name, model_name, ipc_mapping):
        self.definition_template = proto_data_converters_template.proto_to_model_definition_template
        self.declaration_template = proto_data_converters_template.proto_to_model_declaration_template
        self.values_dict = {}
        self.values_dict["proto_type"] = f"{package_name}::{message['message']}"
        self.values_dict["model_type"] = f"{message['model_struct_name']}"
        self.values_dict["conversion_statements"] = self.construct_conversion(message, package_name, model_name, ipc_mapping)

    def construct_conversion(self, message, package_name, model_name, ipc_mapping):
        res = ""
        
        # Each message corresponds to a model struct
        #
        # Each message that is passed on to this function is an object that contains the following
        # 
        # {
        #   "message":"Name of message in proto file",
        #   "model_arg_name": "There will be a single function that takes a struct of this type as the only argument??
        #                      The name of the argument used in the protoype",
        #   "model_struct_name": "type name of the struct which corresponds to the protobuf message",
        #   "members": one of the following
        #              1. An object if the model struct contains exactly one member
        #              2. An array if the model struct contains more that one member
        #              3. An empty array of the model struct does not contain any members??????????
        # }
        #
        # Assumptions:
        # 1. A function in Model that deals with IPC only has a single argument

        
        # members hold an array of struct members
        
        if isinstance(message["members"], dict):
          members = [message["members"]]
        else:
          members = message["members"]
        for member in members:
            # A message struct data member has to be one of the following:
            # 1. Another messsage struct
            # 2. An enum type
            # 3. An Array type, which would make it a member of custom_data_type entry in method.getIPCMappingFileName()
            # 4. it can be opt type 
            # 5. None of the above and we will assume that in that case, a normal assignment will work in C++

            model_field = member["model_member_name"]
            proto_field = member["proto_member_name"]
            model_dtype = member["model_dtype"]


            values_dict = {}
            values_dict['proto_field_name'] = proto_field
            values_dict['model_field_name'] = model_field


            if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 1: Another message struct
                # Assumption is that there won't be a circular dependency
                # Assumption is that if the message is in an included proto file, it will be copied over to ipc_mapping_file

                res += proto_data_converters_template.proto_to_model_message_template.substitute(values_dict)
            
            elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 2: An enum type
                #
                # Not gonna use a static cast for now, need to see what will happen
                # should add static cast if necessary

                res += proto_data_converters_template.proto_to_model_enum_template.substitute(values_dict)



            elif config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 3: A data type in CustomDataType section
                # 
                # There are the following possibilities based on language rules of proto files
                # 1. It is a repeated message
                # 2. It is a bytes keyword
                # 3. It is a string keyword
                # 4. It is a repeated bytes
                # 5. It is a repeated string
                # 6. It is a repeated enum
                # 7. It is a repeated primitive (apart from bytes,string, enum)
                #

                # First let us get the info about the custom type
                custom_type_info = config_getter.DataConverterHelper.findCustomTypeInfo(model_dtype,ipc_mapping)

                model_struct_name = custom_type_info["model_struct_name"]
                
                # Assumption: Every custom data type will have the following data
                length_submember_name = custom_type_info["length_attribute"]
                payload_submember_name = custom_type_info["data_attribute"]

                payload_submember_datatype = None
                for submember in custom_type_info["members"]:
                    if submember["model_member_name"]==payload_submember_name:
                        payload_submember_datatype = submember["model_dtype"]

                
                if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(payload_submember_datatype, ipc_mapping) :
                    # Case 1: It is a repeated message

                    res += proto_data_converters_template.proto_to_model_repeated_message_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isByt(model_struct_name):
                    # Case 2: it is a bytes keyword
                    res += proto_data_converters_template.proto_to_model_scalar_bytes_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isStr(model_struct_name):
                    # Case 3: it is a string keyword
                    res += proto_data_converters_template.proto_to_model_scalar_string_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isRepStrByt(model_struct_name) and config_getter.DataConverterHelper.isByt(payload_submember_datatype):
                    # Case 4: it is a repeated bytes
                    res += proto_data_converters_template.proto_to_model_repeated_bytes_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isRepStrByt(model_struct_name) and config_getter.DataConverterHelper.isStr(payload_submember_datatype):
                    # Case 5: it is a repeated string
                    res += proto_data_converters_template.proto_to_model_repeated_string_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(payload_submember_datatype, ipc_mapping):
                    # Case 6: it is a repeated enum
                    res += proto_data_converters_template.proto_to_model_repeated_enum_template.substitute(values_dict)

                else:
                    # Case 7: It is a repeated primitive (apart from bytes,string, enum)
                    # Assumption is that the cases I have enumerated is exhaustive
                    res += proto_data_converters_template.proto_to_model_repeated_scalar_numeric_template.substitute(values_dict)
                    
            elif config_getter.DataConverterHelper.isAOptionalTypeFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 4: A data type in OptionalType section
                # 
                # These are the following possibilities based on language rules of proto files
                # 1. It is an optional bytes
                # 2. It is an optional string
                # 3. It is an optional enum
                # 4. It is an optional message
                # 5. It is an optional primitive (apart from bytes,string, enum)
                #
                # print("it is an optional type data type")
                 # First let us get the info about the optional type
                optional_type_info = config_getter.DataConverterHelper.findOptionalTypeInfo(model_dtype,ipc_mapping)
                
                model_struct_name = optional_type_info["model_struct_name"]
                # # Assumption: Every optional data type will have the following data
                # has_field = optional_type_info["has_field"]
                field_submember_name = optional_type_info["field"]
                
                field_submember_datatype = None
                for submember in optional_type_info["members"]:
                    if submember["model_member_name"]==field_submember_name:
                        field_submember_datatype = submember["model_dtype"]
                        
                # print(f" opt {model_struct_name}")
                if config_getter.DataConverterHelper.isOptByt(model_struct_name):
                    # Case 1: it is an opt bytes keyword
                    res += proto_data_converters_template.proto_to_model_optional_bytes_template.substitute(values_dict)
                    
                elif config_getter.DataConverterHelper.isOptStr(model_struct_name):
                    # Case 2: it is an opt string keyword
                    res += proto_data_converters_template.proto_to_model_optional_string_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(field_submember_datatype, ipc_mapping):
                    # Case 3: it is an opt enum keyword
                    res += proto_data_converters_template.proto_to_model_optional_enum_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(field_submember_datatype, ipc_mapping) :
                    # Case 4: it is an opt message keyword
                    res += proto_data_converters_template.proto_to_model_optional_message_template.substitute(values_dict)
                
                else:
                    # Case 4: It is an optional primitive (apart from bytes,string, enum)
                    # Assumption is that the cases I have enumerated is exhaustive
                    values_dict["field"] = field_submember_name
                    res += proto_data_converters_template.proto_to_model_optional_numeric_template.substitute(values_dict)
            
            else:
                # Case 5: primitive data type
                # Assumption is that the cases I have enumerated is exhaustive
                res += proto_data_converters_template.proto_to_model_scalar_numeric_template.substitute(values_dict)

      
        return res

    def substitute(self):
        return (
            self.declaration_template.substitute(self.values_dict),
            self.definition_template.substitute(self.values_dict),
        )
    

class ModelToProtoGen:

    
    def __init__(self, message, package_name, model_name, ipc_mapping):
        self.declaration_template = proto_data_converters_template.model_to_proto_declaration_template
        self.definition_template = proto_data_converters_template.model_to_proto_definition_template
        self.values_dict = {}
        self.values_dict["proto_type"] = f"{package_name}::{message['message']}"
        self.values_dict["model_type"] = f"{message['model_struct_name']}"
        self.values_dict["conversion_statements"] = self.construct_conversion(message, package_name, model_name, ipc_mapping)

    def construct_conversion(self, message, package_name, model_name, ipc_mapping):
        res = ""
        
        # Each message corresponds to a model struct
        #
        # Each message that is passed on to this function is an object that contains the following
        # 
        # {
        #   "message":"Name of message in proto file",
        #   "model_arg_name": "There will be a single function that takes a struct of this type as the only argument??
        #                      The name of the argument used in the protoype",
        #   "model_struct_name": "type name of the struct which corresponds to the protobuf message",
        #   "members": one of the following
        #              1. An object if the model struct contains exactly one member
        #              2. An array if the model struct contains more that one member
        #              3. An empty array of the model struct does not contain any members??????????
        # }
        #
        # Assumptions:
        # 1. A function in Model that deals with IPC only has a single argument

        
        # members hold an array of struct members
        
        if isinstance(message["members"], dict):
          members = [message["members"]]
        else:
          members = message["members"]
        for member in members:
            # A message struct data member has to be one of the following:
            # 1. Another messsage struct
            # 2. An enum type
            # 3. An Array type, which would make it a member of custom_data_type entry in method.getIPCMappingFileName()
            # 4. None of the above and we will assume that in that case, a normal assignment will work in C++

            model_field = member["model_member_name"]
            proto_field = member["proto_member_name"]
            model_dtype = member["model_dtype"]


            values_dict = {}
            values_dict['proto_field_name'] = proto_field
            values_dict['model_field_name'] = model_field


            if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 1: Another message struct
                # Assumption is that there won't be a circular dependency
                # Assumption is that if the message is in an included proto file, it will be copied over to ipc_mapping_file

                res += proto_data_converters_template.model_to_proto_message_template.substitute(values_dict)
            
            elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 2: An enum type
                #
                # Not gonna use a static cast for now, need to see what will happen
                # should add static cast if necessary

                res += proto_data_converters_template.model_to_proto_enum_template.substitute(values_dict)



            elif config_getter.DataConverterHelper.isACustomTypeFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 3: A data type in CustomDataType section
                # 
                # There are the following possibilities based on language rules of proto files
                # 1. It is a repeated message
                # 2. It is a bytes keyword
                # 3. It is a string keyword
                # 4. It is a repeated bytes
                # 5. It is a repeated string
                # 6. It is a repeated enum
                # 7. It is a repeated primitive (apart from bytes,string, enum)
                #

                # First let us get the info about the custom type
                custom_type_info = config_getter.DataConverterHelper.findCustomTypeInfo(model_dtype,ipc_mapping)

                model_struct_name = custom_type_info["model_struct_name"]
                
                # Assumption: Every custom data type will have the following data
                length_submember_name = custom_type_info["length_attribute"]
                payload_submember_name = custom_type_info["data_attribute"]

                payload_submember_datatype = None
                for submember in custom_type_info["members"]:
                    if submember["model_member_name"]==payload_submember_name:
                        payload_submember_datatype = submember["model_dtype"]

                
                if config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(payload_submember_datatype, ipc_mapping) :
                    # Case 1: It is a repeated message

                    res += proto_data_converters_template.model_to_proto_repeated_message_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isByt(model_struct_name):
                    # Case 2: it is a bytes keyword
                    res += proto_data_converters_template.model_to_proto_scalar_bytes_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isStr(model_struct_name):
                    # Case 3: it is a string keyword
                    res += proto_data_converters_template.model_to_proto_scalar_string_template.substitute(values_dict)

                elif config_getter.DataConverterHelper.isRepStrByt(model_struct_name) and config_getter.DataConverterHelper.isByt(payload_submember_datatype):
                    # Case 4: it is a repeated bytes
                    res += proto_data_converters_template.model_to_proto_repeated_bytes_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isRepStrByt(model_struct_name) and config_getter.DataConverterHelper.isStr(payload_submember_datatype):
                    # Case 5: it is a repeated string
                    res += proto_data_converters_template.model_to_proto_repeated_string_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(payload_submember_datatype, ipc_mapping):
                    # Case 6: it is a repeated enum
                    res += proto_data_converters_template.model_to_proto_repeated_enum_template.substitute(values_dict)

                else:
                    # Case 7: It is a repeated primitive (apart from bytes,string, enum)
                    # Assumption is that the cases I have enumerated is exhaustive
                    res += proto_data_converters_template.model_to_proto_repeated_scalar_numeric_template.substitute(values_dict)
            
            elif config_getter.DataConverterHelper.isAOptionalTypeFromIPCMappingFile(model_dtype,ipc_mapping):
                # Case 4: A data type in OptionalType section
                # 
                # These are the following possibilities based on language rules of proto files
                # 1. It is an optional bytes
                # 2. It is an optional string
                # 3. It is an optional enum
                # 4. It is an optional message
                # 5. It is an optional primitive (apart from bytes,string, enum)
                #
                # print("it is an optional type data type")
                 # First let us get the info about the optional type
                optional_type_info = config_getter.DataConverterHelper.findOptionalTypeInfo(model_dtype,ipc_mapping)
                
                model_struct_name = optional_type_info["model_struct_name"]
                # # Assumption: Every optional data type will have the following data
                # has_field = optional_type_info["has_field"]
                field_submember_name = optional_type_info["field"]
                
                field_submember_datatype = None
                for submember in optional_type_info["members"]:
                    if submember["model_member_name"]==field_submember_name:
                        field_submember_datatype = submember["model_dtype"]
                        
                # print(f" opt {model_struct_name}")
                if config_getter.DataConverterHelper.isOptByt(model_struct_name):
                    # Case 1: it is an opt bytes keyword
                    res += proto_data_converters_template.model_to_proto_optional_bytes_template.substitute(values_dict)
                    
                elif config_getter.DataConverterHelper.isOptStr(model_struct_name):
                    # Case 2: it is an opt string keyword
                    res += proto_data_converters_template.model_to_proto_optional_string_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAnEnumFromIPCMappingFile(field_submember_datatype, ipc_mapping):
                    # Case 3: it is an opt enum keyword
                    res += proto_data_converters_template.model_to_proto_optional_enum_template.substitute(values_dict)
                
                elif config_getter.DataConverterHelper.isAMessageFromIPCMappingFile(field_submember_datatype, ipc_mapping) :
                    # Case 4: it is an opt message keyword
                    res += proto_data_converters_template.model_to_proto_optional_message_template.substitute(values_dict)
                
                else:
                    # Case 4: It is an optional primitive (apart from bytes,string, enum)
                    # Assumption is that the cases I have enumerated is exhaustive
                    values_dict["field"] = field_submember_name
                    res += proto_data_converters_template.model_to_proto_optional_numeric_template.substitute(values_dict)
            
            else:
                # Case 4: primitive data type
                # Assumption is that the cases I have enumerated is exhaustive
                res += proto_data_converters_template.model_to_proto_scalar_numeric_template.substitute(values_dict)

        return res

    def substitute(self):
        return (
            self.declaration_template.substitute(self.values_dict),
            self.definition_template.substitute(self.values_dict),
        )



class ProtoDataConvertersGen:

    template = proto_data_converters_template.proto_data_converter_template
    values_dict = {}

    def __init__(self, model_object):

        self.values_dict["model_name"] = model_object.getModelName()
        self.values_dict["conversion_declarations"], self.values_dict["conversion_definitions"] = self.construct_funs(model_object)
        self.values_dict["includes"] = self.construct_includes(model_object)

    def construct_funs(self, model_object:Model):

        definitions = ""
        declarations = ""

        # In Methods need ProtoToModel
        model_someip_ins= model_object.getAllModelSomeipIns()
        message_name_set = set()
        for someip_in in model_someip_ins:
            ipc_mapping_file_name = someip_in.getIPCMappingFileName()
            message_data_from_ipc_mapping_file={}
            
            for message in global_data.ipc_mapping_data[ipc_mapping_file_name]["messages"]:
                if message["message"] == someip_in.getMessage():
                    message_data_from_ipc_mapping_file = message
        
            package_name = message_data_from_ipc_mapping_file["package_name"]

            queue = deque()
            queue.append((message_data_from_ipc_mapping_file,package_name,model_object.getModelName(),ipc_mapping_file_name))

            while queue:
                item = queue.popleft()
                message = item[0]
                
                if message["message"] in message_name_set:
                    continue
                
                message_name_set.add(message["message"])

                if isinstance(message["members"], dict):
                    members = [message["members"]]
                else:
                    members = message["members"]
                
                if len(members) > 0:
                    declaration, definition = ProtoToModelGen(*item).substitute()

                    definitions += definition
                    declarations += declaration

                    for member in members:
                        message = config_getter.DataConverterHelper.GetDependentMessageFromIPCMappingFile(member["model_dtype"], ipc_mapping_file_name)
                        if message:
                            queue.append((message,message["package_name"],model_object.getModelName(),ipc_mapping_file_name))

        # Out Methods need ModelToProto
        model_someip_outs= model_object.getAllModelSomeipOuts()
        message_name_set = set()
        for someip_out in model_someip_outs:
            ipc_mapping_file_name = someip_out.getIPCMappingFileName()
            message_data_from_ipc_mapping_file={}
            
            for message in global_data.ipc_mapping_data[ipc_mapping_file_name]["messages"]:
                if message["message"] == someip_out.getMessage():
                    message_data_from_ipc_mapping_file = message
        
            package_name = message_data_from_ipc_mapping_file["package_name"]

            queue = deque()
            queue.append((message_data_from_ipc_mapping_file,package_name,model_object.getModelName(),ipc_mapping_file_name))

            while queue:
                item = queue.popleft()
                message = item[0]
                
                if message["message"] in message_name_set:
                    continue
                
                message_name_set.add(message["message"])


                if isinstance(message["members"], dict):
                    members = [message["members"]]
                else:
                    members = message["members"]
                
                if len(members) > 0 :
                    declaration, definition = ModelToProtoGen(*item).substitute()

                    declarations += declaration
                    definitions += definition

                    for member in members:
                        message = config_getter.DataConverterHelper.GetDependentMessageFromIPCMappingFile(member["model_dtype"], ipc_mapping_file_name)
                        if message:
                            queue.append((message,message["package_name"],model_object.getModelName(),ipc_mapping_file_name))

            
        return (declarations, definitions)
    
    def construct_includes(self, model_object):
        res = ""
        proto_includes = model_object.getAllProtoIncludesForModel()

        model_name = model_object.getModelName()
        res += f"#include <{model_name}.h>\n"

        for include in proto_includes:
            res += f"#include <{include}>\n"

        return res
    
    def substitute(self):
        return self.template.substitute(self.values_dict)
