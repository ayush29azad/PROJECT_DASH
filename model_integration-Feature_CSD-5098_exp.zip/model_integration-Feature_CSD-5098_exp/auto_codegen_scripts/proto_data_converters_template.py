from string import Template


##################
# Proto To Model
##################

proto_to_model_scalar_numeric_template = Template(
'''
{
  ProtoToModelDataConverterScalarNumeric(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_enum_template = Template(
'''
{
  ProtoToModelDataConverterEnum(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_scalar_string_template = Template(
'''
{
  ProtoToModelDataConverterScalarString(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_scalar_bytes_template = Template(
'''
{
  ProtoToModelDataConverterScalarBytes(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_repeated_scalar_numeric_template = Template(
'''
{
  ProtoToModelDataConverterRepeatedScalarNumeric(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_repeated_enum_template = Template(
'''
{
  ProtoToModelDataConverterRepeatedEnum(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_repeated_string_template = Template(
'''
{
  ProtoToModelDataConverterRepeatedString(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_repeated_bytes_template = Template(
'''
{
  ProtoToModelDataConverterRepeatedBytes(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_message_template = Template(
'''
{
  proto_to_model_dataconverter_message(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_repeated_message_template = Template(
'''
{
  ProtoToModelDataConverterRepeatedMessage(proto_message.${proto_field_name}(), model_message.${model_field_name});
}
'''
)

proto_to_model_optional_enum_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});
    ProtoToModelDataConverterOptionalEnum<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
    );
}
'''
)

proto_to_model_optional_bytes_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});
    ProtoToModelDataConverterOptionalBytes<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
    );
}
'''
)

proto_to_model_optional_string_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});
    ProtoToModelDataConverterOptionalString<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
      );

}
'''
)

proto_to_model_optional_numeric_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});
    ProtoToModelDataConverterOptionalNumeric<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
      );

}
'''
)

proto_to_model_optional_message_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});
    ProtoToModelDataConverterOptionalMessage<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
      );

}
'''
)

proto_to_model_declaration_template = Template(
'''
template<>
void proto_to_model_dataconverter_message<${proto_type},${model_type}>(const ${proto_type}& proto_message, ${model_type}& model_message);
'''
)

proto_to_model_definition_template = Template(
'''
template<>
void proto_to_model_dataconverter_message<${proto_type},${model_type}>(const ${proto_type}& proto_message, ${model_type}& model_message)
{

${conversion_statements}

}
'''
)


##################
# Model To Proto
##################

model_to_proto_scalar_numeric_template = Template(
'''
{
    auto setter = [pm = &proto_message](const auto value)-> void {
        pm->set_${proto_field_name}(value);
    };

    ModelToProtoDataConverterScalarNumeric(model_message.${model_field_name}, setter);
}
'''
)

model_to_proto_enum_template = Template(
'''
{
    using proto_enum_type = decltype(proto_message.${proto_field_name}());
    auto setter = [pm = &proto_message](const proto_enum_type value) -> void{
        pm->set_${proto_field_name}(value);
    };

    ModelToProtoDataConverterEnum<proto_enum_type>(model_message.${model_field_name}, setter);
}
'''
)

model_to_proto_scalar_string_template = Template(
'''
{
    auto* const protoStringPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterScalarString(model_message.${model_field_name}, *protoStringPtr); 
}
'''
)

model_to_proto_scalar_bytes_template = Template(
'''
{
    auto* const protoBytesPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterScalarBytes(model_message.${model_field_name}, *protoBytesPtr); 
}
'''
)

model_to_proto_repeated_scalar_numeric_template = Template(
'''
{
    auto* const protoRepPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterRepeatedScalarNumeric(model_message.${model_field_name}, *protoRepPtr); 
}
'''
)

model_to_proto_repeated_enum_template = Template(
'''
{
    auto* const protoRepPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterRepeatedEnum(model_message.${model_field_name}, *protoRepPtr); 
}
'''
)

model_to_proto_repeated_string_template = Template(
'''
{
    auto* const protoRepPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterRepeatedString(model_message.${model_field_name}, *protoRepPtr); 
}
'''
)

model_to_proto_repeated_bytes_template = Template(
'''
{
    auto* const protoRepPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterRepeatedBytes(model_message.${model_field_name}, *protoRepPtr); 
}
'''
)


model_to_proto_optional_bytes_template = Template(
'''
{
    auto mutableRetriever = [pm = &proto_message]() {
        return pm->mutable_${proto_field_name}();
    };

    auto clearer = [pm = &proto_message]() {
        pm->clear_${proto_field_name}();
    };

    ModelToProtoDataConverterOptionalBytes(
        model_message.${model_field_name},
        mutableRetriever,
        clearer
    );
}
'''
)

model_to_proto_optional_numeric_template = Template(
'''
{
    using scalar_type = decltype(model_message.${model_field_name}.${field}); // opt
    
    auto setter = [pm = &proto_message](scalar_type value) {
      pm->set_${proto_field_name}(value);
    };
    
    auto clearer = [pm = &proto_message]() {
      pm->clear_${proto_field_name}();
    };
    
    ModelToProtoDataConverterOptionalNumeric(model_message.${model_field_name}, setter, clearer);

}
'''
)

model_to_proto_optional_message_template = Template(
'''
{
    using opt_type = decltype(model_message.${model_field_name});

    ProtoToModelDataConverterOptionalMessage<opt_type>(
        proto_message.has_${proto_field_name}(),
        proto_message.${proto_field_name}(),
        model_message.${model_field_name}
      );
}
'''
)

model_to_proto_message_template = Template(
'''
{
    auto* const protoMsgPtr = proto_message.mutable_${proto_field_name}();
    model_to_proto_dataconverter_message(model_message.${model_field_name}, *protoMsgPtr); 
}
'''
)

model_to_proto_repeated_message_template = Template(
'''
{
    auto* const protoRepPtr = proto_message.mutable_${proto_field_name}();
    ModelToProtoDataConverterRepeatedMessage(model_message.${model_field_name}, *protoRepPtr); 
}
'''
)

model_to_proto_declaration_template = Template(
'''
template<>
void model_to_proto_dataconverter_message<${model_type},${proto_type}>(const ${model_type}& model_message, ${proto_type}& proto_message);
'''    
)

model_to_proto_definition_template = Template(
'''
template<>
void model_to_proto_dataconverter_message<${model_type},${proto_type}>(const ${model_type}& model_message, ${proto_type}& proto_message)
{

${conversion_statements}

}
'''
)

proto_data_converter_template = Template(
'''
#include "ProtoDataConverterMessage.hpp"
#include "ProtoDataConverterScalarNumeric.hpp"
#include "ProtoDataConverterEnum.hpp"
#include "ProtoDataConverterScalarString.hpp"
#include "ProtoDataConverterScalarBytes.hpp"
#include "ProtoDataConverterRepeatedScalarNumeric.hpp"
#include "ProtoDataConverterRepeatedEnum.hpp"
#include "ProtoDataConverterRepeatedString.hpp"
#include "ProtoDataConverterRepeatedBytes.hpp"
#include "ProtoDataConverterRepeatedMessage.hpp"

${includes}

namespace jlr::cccm::di{

${conversion_declarations}

${conversion_definitions}

}// namespace jlr::cccm::di

'''
)
