from string import Template

hpp_file = Template(
'''
#ifndef JLRCCCM_${MODEL_NAME}_GLOBAL_VARS_HEADER
#define JLRCCCM_${MODEL_NAME}_GLOBAL_VARS_HEADER

#include "ModelControllerInterface.hpp"
#include "ModelExports.hpp"
#include <memory>

namespace jlr{
namespace cccm{
namespace di{

extern SYMBOL_HIDDEN std::weak_ptr<IModelController> gModelControllerInternal;

SYMBOL_HIDDEN void set_model_controller(const std::weak_ptr<IModelController>& controller);

SYMBOL_HIDDEN std::weak_ptr<IModelController> get_model_controller();

} // namespace di
} // namespace cccm
} // namespace jlr

#endif //JLRCCCM_${MODEL_NAME}_GLOBAL_VARS_HEADER
'''
)


cpp_file = Template(
'''
#include <memory>
#include "${model_name}_global_vars.hpp"
#include "ModelExports.hpp"

namespace jlr{
namespace cccm{
namespace di{

SYMBOL_HIDDEN std::weak_ptr<IModelController> gModelControllerInternal;

SYMBOL_HIDDEN void set_model_controller(const std::weak_ptr<IModelController>& controller)
{
    gModelControllerInternal = controller;
}
SYMBOL_HIDDEN std::weak_ptr<IModelController> get_model_controller()
{
	return gModelControllerInternal;
}

} // namespace di
} // namespace cccm
} // namespace jlr
''')
