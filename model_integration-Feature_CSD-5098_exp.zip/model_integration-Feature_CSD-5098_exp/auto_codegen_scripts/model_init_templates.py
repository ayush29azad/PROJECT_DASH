from string import Template

model_init_cpp_template = Template('''
#include <memory>
#include <fstream>
#include <json/json.h>
#include <cstdint>
#include "ModelController.hpp"
#include <$model_name.h>
#include "Wrapper$model_name.h"
#include "${model_name}_global_vars.hpp"
#include "creator.h"


extern "C" std::shared_ptr<cccm::di::ModelLibInterface> creator()
{
  // @brief alias of ModelController template for $model_class
  // using ModelControllerType 
  //  = jlr::cccm::di::ModelController<$model_class>;
                                    
  return std::make_shared<cccm::di::models::Wrapper${model_name}<${model_class}>>(
    std::make_shared<${model_class}>()                      
  );
}


''') 
