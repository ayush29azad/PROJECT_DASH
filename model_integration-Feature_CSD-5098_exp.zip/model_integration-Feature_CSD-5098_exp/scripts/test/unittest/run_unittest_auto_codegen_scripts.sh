#!/bin/bash
set -e

echo "------------------ Unit-Test for auto_code_gen ---------------------"

echo "------------- Runing Unit-Test  ----------------"
cd $ROOTPATH/auto_codegen_scripts/unittests
coverage run --omit '*/usr/lib/python3/dist-packages/*,*/site-packages/*' -m unittest discover

echo "------------- Generate Unit-Test Reports ----------------"
coverage html
gtest_reports_repo=Unittest_reports/auto-code-gen/
mkdir -p $ROOTPATH/$gtest_reports_repo
cp -r htmlcov/ $ROOTPATH/$gtest_reports_repo

set +e
