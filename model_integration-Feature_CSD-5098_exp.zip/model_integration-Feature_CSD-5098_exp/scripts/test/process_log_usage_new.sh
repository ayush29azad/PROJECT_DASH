
num_iters=500
delay=60

mkdir -p /userdata/top_logs
rm /userdata/top_logs/*log

pidin ar | grep "model_launcher" > /userdata/top_logs/model_pid_mapping.txt
top -bd -i $num_iters -D $delay > /userdata/top_logs/top_output.log &
hogs -l 50 -i $num_iters -s $delay | grep "(model_launcher|hmi_app)" -E > /userdata/top_logs/hogs_di_output.log &
hogs -l 50 -i $num_iters -s $delay > /userdata/top_logs/hogs_full_output.log &
