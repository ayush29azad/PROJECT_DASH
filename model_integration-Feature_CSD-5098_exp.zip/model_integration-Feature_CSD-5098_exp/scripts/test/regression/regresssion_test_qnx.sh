#!/bin/sh
export VSOMEIP_CONFIGURATION=/platform/etc/vlan10.json
echo "Enter Release Version"
read release
slmctl "stop uxsafehmi_app"

for script in *.py; do 
    # Stop HMI and model components
    slmctl "stop HMI-Main"
    slmctl "stop DI-Model-GRP1"
    slmctl "stop DI-Model-GRP2"
    slmctl "stop DI-Model-GRP3"
    slmctl "stop DI-Model-GRP4"
    sleep 3
    # Clear cache
    rm /tmp/fastrtps*
    # Restart HMI and model components
    slmctl "start HMI-Main"
    sleep 3
    slmctl "start DI-Model-GRP1"
    slmctl "start DI-Model-GRP2"
    slmctl "start DI-Model-GRP3"
    slmctl "start DI-Model-GRP4"
    echo "Starting $script in a separate process..."
    feature_folder_name="${script%.py}"
    SS_LOC="/logging/$release/outputs/$feature_folder_name/"
    mkdir -p "$SS_LOC"
    echo "$SS_LOC"

    attempt=1
    max_attempts=3
    success=false

    while [ $attempt -le $max_attempts ]; do
        echo "Attempt $attempt for $script..."
        if python3 "$script" -ss_loc "$SS_LOC"; then
            echo "$script executed successfully."
            success=true
            break
        else
            echo "Error occurred while executing $script. Retrying..." >&2
            attempt=$((attempt + 1))
            sleep 2
        fi
    done

    if [ "$success" = false ]; then
        echo "Failed to execute $script after $max_attempts attempts." >&2
    fi
done
echo "All Python scripts have been launched."
 
