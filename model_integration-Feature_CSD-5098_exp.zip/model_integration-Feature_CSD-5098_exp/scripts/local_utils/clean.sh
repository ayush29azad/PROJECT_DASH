#!/bin/bash
# check if $ROOTPATH env variable is set

ROOTPATH="$(pwd)"
export ROOTPATH
if [[ -z "${ROOTPATH}" ]]; then
    echo "\$ROOTPATH not set :("
    exit
else
    echo "\$ROOTPATH = ${ROOTPATH}"
fi

MODEL_ROOTPATH=$ROOTPATH/model_ipc/models
echo "\$MODEL_ROOTPATH = ${MODEL_ROOTPATH}"

rm -rf "$ROOTPATH"/out
echo "Cleared $ROOTPATH/out"

rm -rf "$ROOTPATH"/build
echo "Cleared $ROOTPATH/build"

rm -rf "$MODEL_ROOTPATH"/*ert_rtw
rm -rf "$MODEL_ROOTPATH"/{modelConfig,slprj}

rm -rf "$ROOTPATH"/run*

rm -rf "$ROOTPATH"/dds_topic_idls/*idl
rm -rf "$ROOTPATH"/dds_topic_idls/gen/*

rm -rf "$ROOTPATH"/model_ipc/proto_files/*proto
rm -rf "$ROOTPATH"/model_ipc/proto_files/*json
rm -rf "$ROOTPATH"/model_ipc/proto_files/gen/*

echo "Done cleaning targets"
