#!/bin/sh
./hmi_app -config=application.cfg > /dev/null &

# models
./model_launcher --models vehicleLifecycle displayOdometerTripComputer messageCentre batteryStateOfChargeDisp chargingInfo --dlt_id MD01 --vid 10 > /dev/null &
./model_launcher --models clockDisplay gaugeSpeedometer doorStatus steeringWheelSwitch indFlashing outsideTempFrostInd --dlt_id MD02 --vid 10 > /dev/null &
./model_launcher --models gauges displayZoneFeature indExtLights telltaleService telltaleService1 --dlt_id MD03 --vid 10 14 > /dev/null &
./model_launcher --models statusTPMS staticDisplayConfig transientInfo messageCentreData miscTelltales --dlt_id MD04 --vid 10 > /dev/null &

# val_someip_servers
./energymanagement_service_server > /dev/null &  
./featureconfig_userapps_service_server > /dev/null &  
./lifecycle_userapps_vlca_service_server > /dev/null &  
./lighting_service_server > /dev/null &  
./odometer_service_server > /dev/null &  
./rollingcount_service_server > /dev/null &  
./propulsion_service_server > /dev/null &  
./steering_service_server > /dev/null &  
./vehiclespeed_service_server > /dev/null &  
./suspension_service_server > /dev/null &
# ./apertures_service_server > /dev/null &

# new generic mockvals
./mockval occupant_safety_service_mockval.json occupant_safety_service_test.json > /dev/null &
./mockval charging_service_mockval.json charging_service_test.json > /dev/null &
./mockval motion_service_mockval.json motion_service_test.json > /dev/null &
./mockval vehiclemessaging_service_mockval.json vehiclemessaging_service_test_SW2403c.json > /dev/null &
./mockval apertures_service_mockval.json apertures_service_test.json >/dev/null &
# ./mockval energymanagement_service_mockval.json energymanagement_service_test.json > /dev/null &
./mockval navigation_service_mockval.json navigation_service_test.json >/dev/null &
./mockval telltale_service_mockval.json telltale_service_test_SW2403c.json >/dev/null &
./mockval steering_wheel_switch_service_mockval.json steering_wheel_switch_service_SW2402d.json >/dev/null &
./mockval ivi_messaging_service_mockval.json ivi_messaging_service_test.json >/dev/null &
./mockval cockpit_settings_service_mockval.json cockpit_settings_service_test_SW2403b.json >/dev/null &
./mockval gauges_mockval.json gauges_test_SW2403b.json >/dev/null &
