#!/bin/bash
echo "Please run the command: export ROOTPATH=\`pwd\` on model_integation local path if the script does not run"
source "$ROOTPATH"/scripts/common/global_var.sh
# Function to download kanzi_app artifacts from jfrog
dl_kanzi_app_release_artifacts() {
	echo "function: dl_kanzi_app_release_artifacts -----------------"
	artifact_name=$(jq --raw-output '.kanzi_app.name' $simulink_models_artifact_config_file)
	artifact_version=$(jq --raw-output '.kanzi_app.version' $simulink_models_artifact_config_file)
	artifact_location=$(jq --raw-output '.kanzi_app.location' $simulink_models_artifact_config_file)

	artifact_dl_path=${artifact_location}/${artifact_name}:${artifact_version}.tar.gz

	echo "Downloading kanzi_app artifacts version - ${artifact_version} release -----------------"

	jfrog rt dl --flat --props version=$artifact_version $artifact_dl_path $ROOTPATH/out/artifacts.tar.gz
	mkdir -p "$ROOTPATH"/out/kanzi_app_artifacts_$artifact_version
	tar -xzf "$ROOTPATH"/out/artifacts.tar.gz --directory "$ROOTPATH"/out/kanzi_app_artifacts_$artifact_version
	rm -rf "$ROOTPATH"/out/artifacts.tar.gz

	rm -rf "$ROOTPATH"/out/kanzi_app_artifacts_$artifact_version/application/bin/platform/{qnx,win}

}

dl_kanzi_app_release_artifacts

echo "-----copy kanzi_app_artifacts_$artifact_version to out/kazi_app ---------"
cd "$ROOTPATH"/out
mkdir -p kanzi_app/bin
mkdir -p kanzi_app/lib

# Copy all the kzb, cfg, xml files , Fonts from kanzi_app/bin/
cp kanzi_app_artifacts_$artifact_version/application/bin/* kanzi_app/bin/  || echo "Warning: Not copying with -r so only f will get copied to /app/bin"
cp -r kanzi_app_artifacts_$artifact_version/application/bin/Fonts/ kanzi_app/bin/  

# Copy the application_*.cfg files
cp kanzi_app_artifacts_$artifact_version/application/bin/platform/linux/* kanzi_app/bin/  || echo "Warning: Not copying with -r so only files will get copied to /app/bin"

# Copy the hmi_app binary
cp kanzi_app_artifacts_$artifact_version/application/bin/platform/linux/release/* kanzi_app/bin/  || echo "Warning: Not copying with -r so only files will get copied to /app/bin"
# Copy all the libraries (lib*.so)
cp kanzi_app_artifacts_$artifact_version/application/bin/platform/linux/release/lib/* kanzi_app/lib/  || echo "Warning: Not copying with -r so only files will get copied to /app/lib"
# Remove the jlrdds libraries from kanzi artifacts
rm kanzi_app/lib/libjlrdds*
cp -r kanzi_app/bin/* execution/
cp -r kanzi_app/lib/* execution/
# rm -rf kanzi_app_artifacts_$artifact_version_$artifact_version
cd "$ROOTPATH"
echo ""

echo "Kanzi Artifacts_$artifact_version libs and bins has been successfully copied to execution folder !!!!!!!!!!!!!"
echo ""

echo ' _    _ ______ _      _____ _____ _______   ____  _   _  ___  '
echo '| |  | |  ____| |    |_   _/ ____|__   __| |  _ \| \ | |/ _ \ '
echo '| |__| | |__  | |      | || |       | |    | |_) |  \| | | | |'
echo '|  __  |  __| | |      | || |       | |    |  _ <| . ` | | | |'
echo '| |  | | |____| |____ _| || |____   | |    | |_) | |\  | |_| |'
echo '|_|  |_|______|______|_____\_____|  |_|    |____/|_| \_|\___/ '
