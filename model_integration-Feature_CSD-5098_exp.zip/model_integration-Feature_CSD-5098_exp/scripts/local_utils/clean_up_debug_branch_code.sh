#!/bin/bash
rm dds_topic_idls/*.idl
rm dds_topic_idls/CMake*
rm dds_topic_idls/gen/*

rm model_ipc/proto_files/*json
rm model_ipc/proto_files/*proto
rm model_ipc/proto_files/CMake*

rm include/dds_topics/*
rm include/proto/*

rm -r test/model_vsomeip_clients/*
