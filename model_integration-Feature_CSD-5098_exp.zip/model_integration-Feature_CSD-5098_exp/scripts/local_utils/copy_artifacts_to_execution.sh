#!/bin/bash
mkdir -p execution
cp bin/val_vsomeip_servers/* execution/
cp bin/mockvals/* execution/
cp bin/DDSFuzzer/* execution/
cp bin/* execution/
cp -r lib/dds_topics/* execution/
cp -r lib/jlrdds/* execution/
cp -r lib/models/* execution/
cp -r lib/proto_libs/* execution/
cp -r lib/workexecutorthread/* execution/

# copy the logging-api & dlt libs
cp lib/logging-api/*.so execution/
cp -rPf lib/dlt/* execution/
cp -rPf bin/dlt/* execution/
