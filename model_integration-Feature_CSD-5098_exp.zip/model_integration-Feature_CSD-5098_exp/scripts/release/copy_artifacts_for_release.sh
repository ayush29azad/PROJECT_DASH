#!/bin/bash
cd "${ROOTPATH}"/out

path="release/platform/usr"

# Copy all the bin/* --> platform/usr/bin
if [[ -d bin ]]; then
	mkdir -p ${path}/bin

	# Find out/bin files except val_vsomeip_servers
	find bin -type f -not -path "bin/val_vsomeip_servers/*" -not -path "bin/mockvals/*" -not -path "bin/slm_scripts/*" -exec cp {} ${path}/bin/ \;

	# Copy kanzi bins and Fonts
	cp -r kanzi_app/bin/* ${path}/bin/ || echo "Warning: copy_artifacts_for_release: failed to copy kanzi_app/bin"
    
	#Temporary Hack to copy contenets of application jea_lhd contents to jea_ema_lhd for IP11 release
    cp ${path}/bin/application_jea_lhd.cfg ${path}/bin/application_jea_ema_lhd.cfg

	chmod u+x ${path}/bin/*
fi

# Copy all the ilb/* --> platform/usr/lib
if [[ -d lib ]]; then
	mkdir -p ${path}/lib

	# Remove protobuf & vsomeip libs as we already have them on the target hardware platform
	if [[ "$CI" == true ]]; then
		rm -rf lib/{protobuf,vsomeip} || echo "Warning: copy_artifacts_for_release: failed to remove protobuf & vsomep libs"
		rm -rf kanzi_app/lib/libjlrdds.*
	fi

	# Copy all the kanzi_app libs
	cp kanzi_app/lib/* ${path}/lib/

	# Copy all the out/lib/*
	find lib -type f,l -exec cp {} ${path}/lib/ \;	

	# Preserve simlinks for some libs
	cp -rPf lib/{jsoncpp,fastdds,jlrdds}/* ${path}/lib/ || echo "Warning: copy_artifacts_for_release: failed to copy jsoncpp & fastdds"
fi

cp -rPf kanzi_app/Fonts ${path}/
# # Copy slm_scripts
# mkdir -p release/etc/slm
# mv bin/slm_scripts/jlr_di.xml release/etc/slm/

# remove util files not needed for release
if [[ "$CI" == true ]] ; then
	rm $path/bin/someip_id_mapping.json || echo "Warning: copy_artifacts_for_release: failed to remove someip_id_mapping.json"
	rm $path/bin/launch_artifacts.sh || echo "Warning: copy_artifacts_for_release: failed to remove launch_artifacts.sh"
fi

rm $path/bin/conan* || echo "Warning: copy_artifacts_for_release: failed to remove conan*"
rm $path/{bin,lib}/.gitkeep || echo "Warning: copy_artifacts_for_release: failed to remove .gitkeep"
rm $path/lib/libgolden* || echo "Warning: copy_artifacts_for_release: failed to remove libgolden*"

# Copy mock_vals into release/test for testing purpose
if [[ "$CI_COMMIT_REF_NAME" =~ "Test" || "$CI_COMMIT_REF_NAME" == "development" || "$CI_COMMIT_REF_NAME" =~ "Feature" ]]; then
	mkdir -p "release/test"
	cp bin/val_vsomeip_servers/* bin/mockvals/* bin/slm_scripts/jlr_di.xml "bin/someip_id_mapping.json" "bin/launch_artifacts.sh" "release/test"
fi
