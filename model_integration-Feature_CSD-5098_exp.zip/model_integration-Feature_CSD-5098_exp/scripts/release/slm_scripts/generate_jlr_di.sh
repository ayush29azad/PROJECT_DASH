cd $ROOTPATH/model_grouping_strategy

find . -type f -name "*.json" -exec basename {} \; > $ROOTPATH/scripts/release/slm_scripts/config.txt

cd $ROOTPATH/scripts/release/slm_scripts
rm -f slm_gen.xml

config_file="config.txt"
output_file="jlr_di.xml"


# dynamic model component
while IFS= read -r variable_name || [ -n "$variable_name" ]; do

    echo "<SLM:component name=\"Model-$variable_name\">" >> "$output_file"
    echo "      <SLM:envvar>VSOMEIP_CONFIGURATION=/platform/etc/vsomeip.json</SLM:envvar>" >> "$output_file"
    echo "      <SLM:command>model_launcher</SLM:command>" >> "$output_file"
    echo "      <SLM:args>$variable_name</SLM:args>" >> "$output_file"
    echo "      <SLM:stdout>/dev/null</SLM:stdout>" >> "$output_file"
    echo "      <SLM:cd>/platform/usr/bin</SLM:cd>" >> "$output_file"
    echo "      <SLM:depend>Ethernet-dwc0</SLM:depend>" >> "$output_file"
    echo "      <SLM:depend>Infra-mount</SLM:depend>" >> "$output_file"
    echo "</SLM:component>" >> "$output_file"
    echo >> "$output_file"
    

done < "$config_file"

# static component 
echo "<SLM:component name=\"HMI-Screen\">" >> "$output_file"
echo "    <SLM:command launch=\"builtin\">no_op</SLM:command>" >> "$output_file"
echo "    <SLM:waitfor wait=\"pathname\">/dev/screen</SLM:waitfor>" >> "$output_file"
echo "</SLM:component>" >> "$output_file"
echo >> "$output_file"

echo "<SLM:component name=\"HMI-Main\">" >> "$output_file"
echo "    <SLM:command>hmi_app</SLM:command>" >> "$output_file"
echo "    <SLM:cd>/platform/usr/bin</SLM:cd>" >> "$output_file"
echo "    <SLM:args>-config=/platform/usr/bin/application_ema.cfg</SLM:args>" >> "$output_file"
echo "    <SLM:stdout>/dev/null</SLM:stdout>" >> "$output_file"
echo "    <SLM:stderr>/dev/null</SLM:stderr>" >> "$output_file"
echo "    <SLM:depend>HMI-Screen</SLM:depend>" >> "$output_file"
echo "    <SLM:depend>Infra-mount</SLM:depend>" >> "$output_file"
echo "</SLM:component>" >> "$output_file"
echo >> "$output_file"

echo "<SLM:component name=\"Model-ccf\">" >> "$output_file"
echo "    <SLM:envvar>VSOMEIP_CONFIGURATION=/platform/etc/vsomeip.json</SLM:envvar>" >> "$output_file"
echo "    <SLM:envvar>VSOMEIP_APPLICATION_NAME=/platform/usr/bin/ccf/ccf_client_app</SLM:envvar>" >> "$output_file"
echo "    <SLM:envvar>VSOMEIP_CCFC_DIR=/platform/usr/bin/ccf</SLM:envvar>" >> "$output_file"
echo "    <SLM:command>/platform/usr/bin/ccf/ccf_client_app</SLM:command>" >> "$output_file"
echo "    <SLM:stdout>/tmp/ccf.log</SLM:stdout>" >> "$output_file"
echo "    <SLM:cd>/platform/usr/bin/ccf</SLM:cd>" >> "$output_file"
echo "    <SLM:depend>Infra-mount</SLM:depend>" >> "$output_file"
echo "    <SLM:depend>Ethernet-vlan-10-5</SLM:depend>" >> "$output_file"
echo "    <SLM:depend>routinmanagerd</SLM:depend>" >> "$output_file"
echo "</SLM:component>" >> "$output_file"
echo >> "$output_file"

echo "<SLM:component name=\"Model-sum\">" >> "$output_file"
echo "    <SLM:envvar>VSOMEIP_CONFIGURATION=/platform/etc/vsomeip.json</SLM:envvar>" >> "$output_file"
echo "    <SLM:command>/platform/usr/bin/ccf/cccm-sum</SLM:command>" >> "$output_file"
echo "    <SLM:stdout>/dev/null</SLM:stdout>" >> "$output_file"
echo "    <SLM:cd>/platform/usr/bin/ccf</SLM:cd>" >> "$output_file"
echo "    <SLM:depend>Infra-mount</SLM:depend>" >> "$output_file"
echo "    <SLM:depend>routinmanagerd</SLM:depend>" >> "$output_file"
echo "</SLM:component>" >> "$output_file"
