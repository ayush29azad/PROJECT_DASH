#!/bin/bash
echo "Running through script"
cd /platform/usr/bin


log_dir=/var/logs
mkdir -p $log_dir

echo "Starting HMI"
./hmi_app > $log_dir/hmi_app.txt &

echo "Starting Models"
./model_BattRange.sh > $log_dir/model_BattRange.txt &
./model_gPower.sh > $log_dir/model_gPower.txt &
./model_VehSpeed.sh > $log_dir/model_VehSpeed.txt &
./model_VehMsg.sh > $log_dir/model_VehMsg.txt &
./model_OutTmpFrstInd.sh > $log_dir/model_OutTmpFrstInd.txt &
./model_VehLight.sh > $log_dir/model_VehLight.txt &
./model_miscTelltales.sh > $log_dir/model_miscTelltales.txt &
./model_VehOdo.sh > $log_dir/model_VehOdo.txt &

echo "Starting Servers"
./energymanagement_service_server > $log_dir/energymanagement_service_server &
./featureconfig_userapps_service_server > $log_dir/featureconfig_userapps_service_server &
./vehiclespeed_service_server > $log_dir/vehiclespeed_service_server &
./vehiclemessaging_server > $log_dir/vehiclemessaging_server &
./hvac_service_server > $log_dir/hvac_service_server &
./lifecycle_userapps_vlca_service_server > $log_dir/lifecycle_userapps_vlca_service_server &
./lighting_service_server > $log_dir/lighting_service_server &
./motion_service_server > $log_dir/motion_service_server &
./odometer_service_server > $log_dir/odometer_service_server &
./odometerrollingcount_service_server > $log_dir/odometerrollingcount_service_server &
./propulsion_service_server > $log_dir/propulsion_service_server &
./steering_service_server > $log_dir/steering_service_server &
./suspension_service_server > $log_dir/suspension_service_server &
