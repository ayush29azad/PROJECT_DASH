#!/bin/bash
source "$ROOTPATH"/scripts/common/env_setup.sh
#----------------------Global Variables--------------------------
source "$ROOTPATH"/scripts/common/global_var.sh
#------------------------------------------------------------

#-------------- Declaring function to download from artifactory----------------------
function download_from_artifactory 
{
    echo "----------------Downloading $1------------------"

    if [[ -z ${GITLAB_CI} ]] ; then
        echo "download_from_artifactory: Running locally"
        jfrog rt dl --flat "$1" "$ROOTPATH"/artifacts.tar.gz
    else
        if [[ -z ${CI_JOB_TOKEN} ]]; then
            echo "download_from_artifactory: Running locally using gitlab-runner"
            echo "Please edit script if credentials for jfrog cmd has been added"
        else
            echo "download_from_artifactory: Running in the pipeline"
            rt_download --flat "$1" "$ROOTPATH"/artifacts.tar.gz
        fi
    fi
    tar -xzf "$ROOTPATH"/artifacts.tar.gz --directory "$artifacts_fetched_path"
    rm -rf artifacts.tar.gz
}

#-------------- Fetch the non_safety_models artifacts from jfrog (Simulink model code & model config files) -----------------------

get_models_release_version() {
    if [[ "$CI" == true ]]; then
        if [[ $MODIFY_NON_SAFETY_MODELS_VERSION != "" ]]; then
            echo "Getting non_safety_models version from the Triggered pipeline : MODIFY_NON_SAFETY_MODELS_VERSION"
            models_release_version=$MODIFY_NON_SAFETY_MODELS_VERSION
        fi
    else
        models_release_version=$(jq --raw-output '.models_repo.release_version' "$simulink_models_artifact_config_file")
    fi
    echo "models_release_version --> $models_release_version"
    models_artifactory_path="${models_artifactory_path}/${models_repo_name}:${models_release_version}.tar.gz"
}

function fetch_non_safety_artifacts()
{
if [[ -z ${GITLAB_CI} ]]; then
    if [[ -f ".cache/key_file" && $(cat ".cache/key_file") == "$models_release_version" ]]; then
        echo "The cached key_file exists and has the expected value. Skipping jfrog_download of non_safety_model version $models_release_version and dds_artifacts and someip_artifacts ."
        cp -r  $ROOTPATH/.cache/* $ROOTPATH/artifacts_fetched/
    else
        download_from_artifactory "$models_artifactory_path"
        dds_artifacts_versioned="$(cat "$dependencies_manifest_file_path" | sed -n '2p').tar.gz"
        download_from_artifactory "$dds_artifacts_versioned"
        someip_artifacts_versioned="$(cat "$dependencies_manifest_file_path" | sed -n '1p').tar.gz"
        download_from_artifactory "$someip_artifacts_versioned"
        mkdir -p .cache
        cp -r $artifacts_fetched_path/* .cache
        echo "$models_release_version" > ".cache/key_file"
    fi
else
     download_from_artifactory "$models_artifactory_path"
     dds_artifacts_versioned="$(cat "$dependencies_manifest_file_path" | sed -n '2p').tar.gz"
     download_from_artifactory "$dds_artifacts_versioned"
     someip_artifacts_versioned="$(cat "$dependencies_manifest_file_path" | sed -n '1p').tar.gz"
     download_from_artifactory "$someip_artifacts_versioned"

fi
}

get_models_release_version
fetch_non_safety_artifacts
