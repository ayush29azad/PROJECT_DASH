set -e
source ${ROOTPATH}/scripts/common/env_setup.sh
#----------------------Global Variables--------------------------
source "$ROOTPATH"/scripts/common/global_var.sh
#------------------------------Fetch Service ID for all Services ------------------------------------

version_someip=`echo $CONAN_SOMEIP_INTERFACE_ROOT | grep -oE "v[0-9]+\.[0-9]+\.[0-9]+"`

pip3 install -q jsonschema

echo "$version_someip"
REPO_URL="https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/function/someip_interface"
FILE_PATH="ServiceVersions.manifest"
VERSION_TAG="$version_someip"
if [[ -z ${GITLAB_CI} ]]; then
    if [[ -f "$HOME/.di_cache/someip_key_file" && $(cat "$HOME/.di_cache/someip_key_file") == "$VERSION_TAG" ]]; then
        echo "The cached key_file exists locally and has the expected value. Skipping Cloning of someip_interface $VERSION_TAG ."
        cp -r $HOME/.di_cache/someip_interface $ROOTPATH/
    else
        git clone --recursive "https://${auth_slug}@git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/function/someip_interface.git" -b $VERSION_TAG --depth=2
        cd someip_interface/eth-soa-rel
        git checkout tags/9.5.0
        cd ../../
        mkdir -p "$HOME/.di_cache/someip_interface"
        cp -r $ROOTPATH/someip_interface/* "$HOME/.di_cache/someip_interface"
        echo "$VERSION_TAG" > "$HOME/.di_cache/someip_key_file"
    fi
else
    git clone --recursive "https://${auth_slug}@git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/function/someip_interface.git" -b $VERSION_TAG --depth=2
    cd someip_interface/eth-soa-rel
    git checkout tags/9.5.0
    cd ../../

fi
# Read the JSON data from a file
json_data_file="someip_interface/eth-soa-rel/registry/ecus.json"
json_data=$(cat "$json_data_file")

# Declare an associative array for mapping names to IDs
declare -A all_service_id_mapping

# Loop through the JSON data and extract names and IDs
for entry in $(echo "$json_data" | jq -r '.[] | .Hosts[] | ."Host VLANs"[] | .Services[] | @base64' ); do
    _jq() {
        echo "${entry}" | base64 --decode | jq -r "${1}"
    } 
    name=$(_jq '.ServiceName')
    id=$(_jq '.ServiceID')

    # Add the name and ID to the associative array
    all_service_id_mapping["$name"]=$id
done

# Read servicemanifest.json file
manifest_file="someip_interface/ServiceVersions.manifest"
# Read the content from the ServiceVersions.manifest file
data=$(cat $manifest_file)

# Declare an array to store service names
service_names=()
proto_service_names=()

# Loop through each line in the data
while IFS= read -r line; do
  # Extract the service name with .json extension
  service_name=$(echo "$line" | grep -oP '[^|]+(?=\.json)')
  proto_service_name=$(echo "$line" | grep -oP '[^|]+(?=\.proto)')
  # Add the service name to the array
  service_names+=("$service_name")
  proto_service_names+=("$proto_service_name")
done <<< "$data"

output_file="model_ipc/config/model_someip_service_config.json"
# Generate the JSON output file
echo "{">"$output_file"
#----------------------------------------------------------------------------------------

proto_repo_path="$CONAN_SOMEIP_INTERFACE_ROOT/bin/protos/"

find_proto_file() {
    service_name="$1"
    find "$proto_repo_path" -type f -name "${service_name}.proto" -print -quit
}

get_import_files() {
    proto_file_path="$1"
    grep -o 'import "[^"]*\.proto"' "$proto_file_path" | awk -F '"' '{ print $2 }' || echo "404"
}
service_proto_map=""

for service_name in "${proto_service_names[@]}"; do
    proto_file_path=$(find_proto_file "$service_name")

    # if [ -n "$proto_file_path" ]; then
        import_files=("$service_name.proto" "${import_files[@]}")  # Add service_name.proto at the beginning
        proto_header=($(get_import_files "$proto_file_path"))
        if [ "$proto_header" != "404" ]; then
          import_files+=("${proto_header[@]}")
        fi
        # import_files_str=$(IFS=,; printf '"%s",' "${import_files[@]}")
        import_files_str=$(printf '"%s",' "${import_files[@]}")
        import_files_str=${import_files_str%,}  # Remove trailing comma
        import_files_str="[${import_files_str}]"  # Wrap the import_files_str in square brackets
        service_proto_map+=$(printf '    "%s": %s,\n' "$service_name" "$import_files_str")
        service_proto_map+="\n"
        unset import_files
        unset proto_header
    # else
    # fi

done

# Remove trailing comma and newline
service_proto_map=${service_proto_map%,*}

# Output to JSON file
echo "  \"service_protoDependency\": {" >> "$output_file"
echo -e "$service_proto_map" >> "$output_file"
echo "}," >> "$output_file"


output="    \"someip_json_mapping\" : {\n"
for ((i=0; i<${#proto_service_names[@]}; i++)); do
    lhs_item="${proto_service_names[$i]}_mapping.json"
    rhs_item="${service_names[$i]}.json"
    output+="        \"$lhs_item\" : \"$rhs_item\",\n"
done
output+="    }\n"

# Remove trailing comma and newline
output="${output%,*}"
# Output to JSON file
echo -e "$output" >> "$output_file"
echo "}}" >> "$output_file"

rm -rf someip_interface

set +e
