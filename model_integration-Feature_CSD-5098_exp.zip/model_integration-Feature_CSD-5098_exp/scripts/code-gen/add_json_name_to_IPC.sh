#!/bin/bash
# Someip Artifacts provide a .json file which has the message IDs and other vsomeip configurations
# It also provides a .proto file which it uses for serialisation
# 
# Usually the names match of the .json file and the .proto file match
# But when they don't we need a way to figure out what the right .json file we have to use is.
# 
# The Python Autogen scripts expect a json_name entry in the IPC Mapping files provided to figure out 
# what the right json to use is
#
# It is the Integration team's responsibility to figure out the right file to use.
#
# We will use a file 
#  
# We will modify the IPC mapping file to add json_name entries


function add_json_name_to_IPC_mapping {
    # Usage:
    # First argument is path to directory which contains the IPC mapping files
    # Second argument is path to simulink models artifact config file.

    if [[ -d $1 && -f $2 ]]
    then
        local file_names
        file_names=$(jq --raw-output '.someip_json_mapping | keys | .[]' "$2")
        while IFS= read -r file_name
        do
            local file_path
            file_path="$1/$file_name"
            if [[ -f $file_path ]]
            then
                local json_name
                json_name=$(jq ".someip_json_mapping.\"$file_name\"" "$2")
                local jq_filter
                jq_filter=". += {\"json_name\" : $json_name}"
                local temp_output_file
                temp_output_file="${file_path}.tmp"
                jq "$jq_filter" "$file_path" > "$temp_output_file" && mv "$temp_output_file" "$file_path"
            else
                >&2 echo "ERROR: A regular file could not be found at $file_path"
                >&2 echo "ERROR: Aborting because this file is required"
                >&2 echo "ERROR: Please check the contents of $2"
                >&2 echo "ERROR: Please check if the directory $1 contains the files"
                exit 4
            fi
        done <<< "$file_names"
    fi

}
