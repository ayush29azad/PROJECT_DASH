#!/bin/bash

set -e

# Build functions
run_build() {
    # init conan build
    rm -rf "$ROOTPATH"/build
    mkdir -p "$ROOTPATH"/build
    cd "$ROOTPATH"/build
    "${PROJECT_DIR}"/scripts/init-linux-x86-64

    # conan build
    conan build "${PROJECT_DIR}"
    cd "$ROOTPATH"
}

build_model_launcher() {
    # build model_launcher
    export BUILD_TYPE="MODEL_LAUNCHER"
    echo "Building model_launcher ---------------------------------------"
    run_build
}

build_common() {
    # build common dds idls and proto files
    export BUILD_TYPE="COMMON"
    echo "Building idl & proto ---------------------------------------"
    run_build
}

build_models() {
    models=$(jq --raw-output '.models[]' "$simulink_models_artifact_config_file")

    if [[ -z $models ]]; then
        echo "models are empty in simulink_models_artifact_config_file - Exiting" && exit 1
    fi

    # Building all models
    echo "------------- Building all model libraries -----------------------------------------"
    export BUILD_TYPE="MODEL"
    run_build
}

build_vsomeip_mock_vals() {
    echo "------------- Building Mock VAL's ------------------------------------------------"
    export BUILD_TYPE="VSOMEIP_MOCK_VAL"
    run_build
}

build_generic_mock_vals()
{
    echo "------------- Building New Mock VAL's ------------------------------------------------"
    export BUILD_TYPE="GENERIC_MOCK_VAL"
    run_build
}

build_dds_comms_tester()
{
    echo "------------- Building DDS Comms Tester ------------------------------------------------"
    export BUILD_TYPE="DDS_COMMS_TESTER"
    run_build
}


# ####################################### Main code starts here #########################################

PROJECT_DIR=$(cd "$(dirname "$0")/../.."; pwd)

source "$ROOTPATH"/scripts/common/env_setup.sh

cp ${PROJECT_DIR}/common-infrastructure/scripts/init* ${PROJECT_DIR}/scripts/

release_type="${BUILD_TYPE:-Release}"

# Align input binaries to output folder
out_bin_path=$ROOTPATH/out/bin
out_lib_path=$ROOTPATH/out/lib
rm -rf "$ROOTPATH"/out
mkdir -p "$out_bin_path"
mkdir -p "$out_lib_path"

#----------------------Global Variables--------------------------
source "$ROOTPATH"/scripts/common/global_var.sh
#------------------ model specific code build --------
# Create output directories
mkdir -p "$out_bin_path"/"$val_vsomeip_servers_repo" # out/lib & out/bin are hardcodes
mkdir -p "$out_bin_path"/"mockvals" # out/lib & out/bin are hardcodes

# ############################################## Build Everything ########################################
build_model_launcher
build_common
build_models
build_vsomeip_mock_vals
build_generic_mock_vals
build_dds_comms_tester

m_g_s_json_list=($(ls model_grouping_strategy/))
echo "Generate model_launcher scripts with model_grouping_strategy ---------------"
for item in ${m_g_s_json_list[@]};
do
    if [[ $item =~ "json" ]]; then
        # echo $item
        run_model_launcher_script="#!/bin/sh \n/platform/usr/bin/model_launcher ${item}"
        run_model_launcher_script_file="model"_${item//".json"}.sh
        echo -e "$run_model_launcher_script" > "$ROOTPATH"/bin/"$run_model_launcher_script_file"
        chmod u+x "$ROOTPATH"/bin/"$run_model_launcher_script_file"
        cp "$ROOTPATH"/bin/"$run_model_launcher_script_file" "$out_bin_path"
    fi
done

chmod u+x "$ROOTPATH"/scripts/local_utils/copy_artifacts_to_execution.sh
cp "$ROOTPATH"/scripts/local_utils/copy_artifacts_to_execution.sh "$ROOTPATH"/out/

chmod u+x "$ROOTPATH"/scripts/local_utils/get_kanzi_app_release_artifacts_linux.sh
cp "$ROOTPATH"/scripts/local_utils/get_kanzi_app_release_artifacts_linux.sh "$ROOTPATH"/out/
#Copying genric Mockval's Artifacts to out bin file inside mockval folder 
cp $ROOTPATH/test/mockval/input/* $out_bin_path/mockvals/
rm -rf $out_bin_path/mockvals/responseGen.py
cp $ROOTPATH/utils/someip_id_mapping.json $out_bin_path
cp $ROOTPATH/scripts/local_utils/launch_artifacts.sh $out_bin_path

model_val_vsomeip_config_json=$(jq --raw-output '.model_val_vsomeip_config_json' "$generic_model_config_file")
cp "$ROOTPATH"/utils/"$model_val_vsomeip_config_json" "$out_bin_path"


# Copy the fetched subcomponent artifacts to out
cp -r "$ROOTPATH"/bin/* "$out_bin_path"
cp -r "$ROOTPATH"/lib/* "$out_lib_path"
