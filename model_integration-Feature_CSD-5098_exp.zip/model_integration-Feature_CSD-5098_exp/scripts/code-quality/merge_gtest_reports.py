import os
import json
import argparse

def merge_gtest_json_reports_from_directory(input_dir, output_dir):
    merged_report = {
        "tests": 0,
        "failures": 0,
        "disabled": 0,
        "errors": 0,
        "timestamp": "",
        "time": "0s",
        "name": "AllTests",
        "testsuites": []
    }

    if not os.path.isdir(input_dir):
        raise FileNotFoundError(f"The input directory '{input_dir}' does not exist.")

    if not os.path.isdir(output_dir):
        raise FileNotFoundError(f"The output directory '{output_dir}' does not exist.")

    json_files = [f for f in os.listdir(input_dir) if f.endswith('.json')]
    if not json_files:
        raise FileNotFoundError("No JSON files found in the input directory.")

    for filename in json_files:
        file_path = os.path.join(input_dir, filename)
        try:
            #deepcode ignore PT:<This is used to merge the gtest reports>
            with open(file_path, 'r') as f:
                #deepcode ignore PT:<This is used to merge the gtest reports>
                report = json.load(f)

            if not isinstance(report, dict) or "testsuites" not in report:
                print(f"Skipping file '{filename}': Invalid GTest JSON structure.")
                continue

            merged_report["tests"] += report.get("tests", 0)
            merged_report["failures"] += report.get("failures", 0)
            merged_report["disabled"] += report.get("disabled", 0)
            merged_report["errors"] += report.get("errors", 0)
            merged_report["testsuites"].extend(report.get("testsuites", []))

        except json.JSONDecodeError:
            print(f"Skipping file '{filename}': Invalid JSON format.")
        except Exception as e:
            print(f"Error processing file '{filename}': {e}")

    output_file = os.path.join(output_dir, "test_report.json")
    #deepcode ignore PT:<This is used to merge the gtest reports>
    with open(output_file, "w") as f:
        #deepcode ignore PT:<This is used to merge the gtest reports> 
        json.dump(merged_report, f, indent=2)

    print(f"Merged report saved to {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Merge GTest JSON reports from a directory.")
    parser.add_argument("input_dir", help="Path to the input directory containing JSON files.")
    parser.add_argument("output_dir", help="Path to the output directory to save the merged report.")
    args = parser.parse_args()

    merge_gtest_json_reports_from_directory(args.input_dir, args.output_dir)
