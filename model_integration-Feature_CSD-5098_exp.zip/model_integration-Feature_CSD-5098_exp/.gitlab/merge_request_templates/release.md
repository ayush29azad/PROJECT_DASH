## 1. Overview
### Description
Description of the release.

<!-- Mention all the features that are deployed in this release -->
#### Features Deployed:
* Speedometer
* Battery SOC
* Message centre

<!-- Mention all the models deployed using simulink_models_artifact_config.json -->
#### Models Deployed:
[ "gaugeSpeedometer", "batteryStateOfChargeDisp", "messageCentre"]

#### JIRA Issues & MRs involved:
* [DIN-0000](https://jira.devops.jlr-apps.com/browse/DIN-16326)  Add features for xx release (MR - !90)
* [DIN-9999](https://jira.devops.jlr-apps.com/browse/DIN-16326) Fix xx & yy (MR - !90)

#### Release Notes:
<-- Upload pdf here -->
<!-- [CCCM_DI_Release_SW2303b.pdf](/uploads/fd0ea207c49b067a9d364cdd7fee78ff/CCCM_DI_Release_SW2303b.pdf) -->

#### HMI-Model-Mock_val Mapping Diagram
<-- Upload image here -->
<!-- ![di_release_sw2303b_chart](/uploads/2d8a58aca59850bf9a35e780fe185c1b/di_release_sw2303b_chart.png)
-->

## 2. Developer Checklist
MR Author: Complete these before seeking approval

### MR Guidelines
<!-- Refer the latest git tag -->
- [ ] _kanzi_app_ version is up-to-date in _simulink_models_artifact_config.json_ as per release
- [ ] Ensure model_grouping_strategy and slm is updated as per the changes in models or releaase
- [ ] Ensure that merge strategy is set to fast-forward merge and commits to main are not squashed
- [ ] Ensure that release artifacts folder contains all the necessary files (release/{etc,platform})
 
### Integration - Smoke Testing
- [ ] Tested the QNX build on Target platform with GUI (B Sample Hardware)
  * Mock VALs used: [mock_vals_code](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/-/tree/v2.5.0/test/val_vsomeip_servers)

  * GUI - [gui_artifacts](https://artifactory-gdd.sdo.jlrmotor.com/artifactory/cccm-di-mvn-dev-local/end-artifacts/kanzi_app/releases/kanzi_app:1.8.1.tar.gz)

  * GUI demo on A-Sample hardware:
    * <--Upload the Demo Video here-->

- Notes:
  <!-- Comment on testing/runtime issues here -->
  <!-- Comment on working of GUI  -->

### Unit Test Coverage (GTest)
- [ ] Unit tests created for all code in src folder of repo
- [ ] GTest Report: Unit test coverage above 90%
<!-- Update the GTest reports  -->
- [GTest Reports](https://artifactory-gdd.sdo.jlrmotor.com/ui/native/cccm-di-mvn-dev-local/end-artifacts/model_integration/SW2303b_Reports/Gtest/)

### Code Quality
#### Static Analysis (Klocworks)
- [ ] Reports generated properly

#### Vulnerability Scanning (snyk tool)
- [ ] No software vulnerabilities found

#### Code Commenting (Doxygen tool)
- [ ] Doxygen reports generated successfully

#### Linters Validation (pre-commit)
- [ ] Executed the pre-commit linter validation before pushing the code to remote branch or make sure the linter stage is passing in the feature branch pipeline before raising merge request.


### Subcomponents Release Checks
#### model_integration
- [ ] dds_manager 
    - release version - v1.0.0/prd <!--update version number here using conan_dependencies_artifact_config.json -->
    - release [MR](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/common/dds_manager/-/merge_requests/66) (All the Release criterion can be viewed in MR)

- [ ] work_executor_thread 
    - release version - v1.0.0/prd <!--update version number here using conan_dependencies_artifact_config.json -->
    - release [MR](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/work_executor_thread/-/merge_requests/15) (All the Release criterion can be viewed in MR)


#### Simulink Models
 - [ ] non_safety_models
     - Release - [v1.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/function/non_safety_models/-/releases/v1.1.0)
     <!--update version number here using simulink_models_artifact_config.json -->

- [ ] safety_models
     - Release - [v1.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/function/safety_models/-/releases/v1.0.0)
     <!-- Check with modelling squad for this version -->

#### HMI components
- [ ] kanzi_datasource
    - Release - [v1.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/common/kanzi_datasource/-/tags/v1.0.0)
    <!-- - release [MR](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/gui/kanzi_app/-/merge_requests/185) -->

- [ ] kanzi_app  
    - Release - [v1.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/gui/kanzi_app/-/releases/v1.0.0)
    <!--update version number here using simulink_models_artifact_config.json -->
    <!-- - release [MR](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/gui/kanzi_app/-/merge_requests/185) -->

#### Sanity Feature test from Squad4 Integration Testing:
- [ ] ODO feature(Please Check 0 is getting wriiten from model)
- [ ] Dark/Light Theme 
- [ ] Charging Screen should work
- [ ] Display Modes(Default/Navigation/DSA) should be working
- [ ] Speedo value must be incremeing with KMPH/MPH and overspeeding
- [ ] EV range Feature should work.
- [ ] Graceful shutdown
- [ ] CI parameter to instance iD

## 3. Approver Checklist
- [ ] Relevant MR Title
- [ ] Relevant MR Description
- [ ] MR pipeline completed (100%) after pipeline check
- [ ] Code review comments are closed and documented.
- [ ] Ensure the whole Developer checklist is satisfied
