module.exports = {
    branches: ["+([0-9])?(.{+([0-9]),x}).x", "main", {name: 'development', prerelease: "dev"}],
    repositoryUrl: "git@git-gdd.sdo.jlrmotor.com:CORS/Driver_Information/cccm/integration/model_integration.git",
    tagFormat: "v${version}",
    plugins: [
      [
        "@semantic-release/commit-analyzer",
        {
          preset: "conventionalcommits",
        },
      ],
      [
		"@semantic-release/release-notes-generator",
		{
			preset: "conventionalcommits",
		},
      ],
      [
        "@semantic-release/exec",
        {
          publishCmd: "echo  NEXT_VERSION=v${nextRelease.version} > .version",
        },
      ],
      [
        "@semantic-release/gitlab",
        {
          
        },
      ],
    ],
  };
