## [10.4.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.3.0...v10.4.0) (2024-11-12)

### Features

* DIN-52049 add condition to check dict/arrays types for enum & custom_types ([ec640bb](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ec640bb526a0ede5d83abb1859a5d9d81b5c2943))
* DIN-52049 add InputCombination folder in unittest ([4b1846b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/4b1846bf0b55ea070aaf5d24b4519f21e69c956a))
* DIN-52049 add intern refactored gtest file ([0e1cf4f](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0e1cf4f10af0a7fe7cbdc18ad0a133efc4514256))
* DIN-52049 add README of unittest ([dc7ec55](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/dc7ec55b57551db602cb220f3a1875088ba9dc20))
* DIN-52049 add unittest cases for classes in class_definition file ([5825a8d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5825a8dcbec0a0aff09d796598807251cc9e5124))
* DIN-52049 add unittest cases for config_getter file ([8dd503d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8dd503dce0e26d9b89f13b6361743d3ff754479e))
* DIN-52049 add unittest cases for ipc mapping json schema validator ([84730bd](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/84730bd1c34a47403ec2b89b76fe3ac4fca5495d))
* DIN-52049 add unittest cases for json_parser ([99b30e5](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/99b30e550dd2cf8cb7483174882fa7ff18bc84b3))
* DIN-52049 add unittest cases for JsonLinking apis ([590b80c](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/590b80c076e20038366485095d8495d7e79310ef))
* DIN-52049 add unittest cases for model config json schema validator ([13206ff](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/13206ff90ac645b35eaaf1d45238774552b75ab4))
* DIN-52049 add unittest cases for service json schema validator ([c3919e4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c3919e4e8b8d4b03fb06b17421bee63e3c37a0df))
* DIN-52049 add unittest cases for someip_json_mapping ([0d295b8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0d295b8bb618e299fc5573c5ec1e9741e0b0191a))
* DIN-52049 add unittest cases for topic ipc mapping json schema validator ([c4fb6be](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c4fb6be7abf2645942a604cd95e6bf652dcfacf5))
* DIN-52049 add unittest cases for utils.py file ([6e9c550](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/6e9c550a861046831bc91bf8f2ebc2bd3ec6dff6))
* DIN-52049 add unittest job in pipeline ([61fa1a0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/61fa1a0e38bf520b67395120bfb21e35697f582f))
* DIN-52049 change the structure of model_someip_service_config file to adapt the service_protoDependency field ([2f8a82f](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2f8a82f2f06a1e7921d87a1d3da8e4e02429f0d6))
* DIN-52049 Create wrapperHeader file ([c7d3ad9](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c7d3ad93a6213d00046127c099a4bdf5af3bb3fe))
* DIN-52049 delete josnReader python script ([6522972](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/6522972ff2468b9e0af7876472b8b3bbd4830199))
* DIN-52049 keep one log for one model - clean logs ([9707dc7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/9707dc74ba7c312880889f19089ac56e45fb3357))
* DIN-52049 removed unnecessary logs ([f26de35](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f26de35e060cac5d8aee6339aed150372cedbcb4))
* DIN-52049 update common_dds_proto_build_cmake path ([a2943e3](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a2943e368da1d5f510481c58e38bb415903c203f))
* DIN-52049 update file.input_path ([5240204](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/524020406603d354dc40e0de1ddcd1b3ae13feff))
* DIN-52049 updated python scripts in auto_code_gen folder with intern files ([e6d976d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/e6d976d04f7179b5fcccd3add05d55ebf38376c7))
* DIN-52049 use input_path variable to specify model_ipc path ([5f3edfa](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5f3edfa8e4e9b9dd726da258a8d186abf261eb4e))
* DIN-54095 Add di_display_context_service in someip_id_mapping.json - squashed ([047ef57](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/047ef57f84e9351d3633636773b2327d378ff021))
* DIN-54739 add support for getting package name in model someip methods ([efe5ab6](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/efe5ab6e9c3b356ab5be02cff8daaf23360738aa))
* DIN-54739 add transient info model ([0ece53b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0ece53bbc983860dd824ae19384592a994123803))
* DIN-54739 model update for SW2403d ([539377e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/539377ef5ed3ba2b8b03d8fbce419cd703ebe17c))
* DIN-54739 update kanzi app version to 3.8.0 ([6121a6b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/6121a6b3871e4834c9e4e4453ac0724185edefcf))
* DIN-54905 add getProtoFilename method ([08813e3](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/08813e3dd6843713fb29e53a11c3dcd11f40dbf5))
* DIN-54905 add getProtoHeaderFilename method ([2ade7fd](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2ade7fda8f1e10a5b8b8ed112de000e29158bf54))
* DIN-54916 ability to run unit tests ([0db1884](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0db1884837012293165f43695e9c03ecbf9f1693))
* DIN-54916 add package_name to jsonschema ([43db04d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/43db04d551bda2581d71c5b96cca0acabee0fe5f))

### Bug Fixes

* DIN-52048 Fix for klockwork Error issues ([04015cc](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/04015cc64aade8f8867fc8ffd84f64e7e9d82ee6))
* DIN-52049 add extra condition for model_name in modelConfig file ([eb04ccd](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/eb04ccdc2369c2f2b9ac0031480f0389fc1881f0))
* DIN-54739 proto package namespace declaration ([42be9ff](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/42be9ff34cdcb31830e1521fa52dec2b0d6a86dd))
* DIN-54739 use mesage specific package name for data converter gen ([731c475](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/731c4751019c28b9c2ba607984aa3fa74be40273))
* DIN-54801 eth-soa-rel version fix ([0e141ea](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0e141ea3e56eb2a6e800e5fd08105111335540c5))
* DIN-54801 use protos from artifacts ([8caad3e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8caad3e1842ca0828a235824c3178f001b59a943))
* DIN-54888 Fix "reverse GUI tests" ([78ef336](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/78ef336681105e955402a677a00c20e93fcb7d05))
* DIN-54905 Add SomeipServiceProvider gtest ([fe8a50d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/fe8a50d91c99468678ae50097eef6e7d70982e74))
* DIN-54915 Common gtest files now run ([c9d89d5](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c9d89d57f014bd0925572e8555a07f25ca9f81b1))
* DIN-54916 update test files ([d608937](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/d6089376784d6e6401a9d4bf85d33b4d237fcb3f))

## [10.3.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.2.0...v10.3.0) (2024-10-25)

### Features

* DIN-54276 Model feature updates SW2403c - squashed ([a83e14d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a83e14d3cd45d40d4b5f3d7e5426326d61a9abbb))

### Bug Fixes

* DIN-52044 Updated logging api interface ([91ff9c8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/91ff9c8ae6b8e02d76064fe1c92cf8d2461ca17f))
* DIN-52051 change major version to 1 ([04dae92](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/04dae926291f4a3f6fc598bbe4c531db960ded9a))

## [10.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.1.0...v10.2.0) (2024-10-07)

### Features

* DIN-52051 add terminate functions in the model_ipc ([966bfb0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/966bfb059aaf0eb95a1634cb928e051a11b4217d))
* DIN-52051 modify dl_open() infra and add shutdown logic ([af3c0b7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/af3c0b798757be3bf3ca502a100e698b8e326c97))
* DIN-52601 DI end-to-end builds (from di_e2e to cccm-image) - squashed ([2b7a84a](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2b7a84a3ea699f3e67895fedaca7dea085d40097))
* DIN-53626 Model feature updates SW2403b-IP9 (telltales,mssgCentre,gaugeSpeedometer, VLC,gauges) - squashed ([2b16d1e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2b16d1eb4b32be1be7046f823c20124cec2ad005))

### Bug Fixes

* DIN-52051 Fix breaking unit tests ([1b62687](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1b626878e671059c0f88d2a55f99c97863c67563))

## [10.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.0.2...v10.1.0) (2024-09-13)

### Features

* DIN-52603 Model feature updates SW2403a - squashed ([f060fc4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f060fc438688e3d32027ce855a664584775f6b54))

### Bug Fixes

* DIN-52574 correct --pipeline argument to unitTestJiraAutomation.py ([f2976d7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f2976d77e945a04095b4e47f87595c0b4eaacb00))

## [10.0.2](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.0.1...v10.0.2) (2024-08-31)

### Bug Fixes

* DIN-53221 Hotfix for Major Version 1 ([7364705](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/7364705b8a3985f39e5fb433c4a984cdee9e93a5))

## [10.0.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v10.0.0...v10.0.1) (2024-08-20)

### Bug Fixes

* DIN-52599 Upload mock vals in test folder for main branch ([ee234ee](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ee234ee1adadc7df8b373d79fa30d6aabbd77973))

## [10.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v9.2.0...v10.0.0) (2024-08-19)

### ⚠ BREAKING CHANGES

* DIN-52733 Change Major Version to 1
* DIN-52732 Enable length header

### Features

* DIN-52603 Model feature updates SW2402d - squashed ([b2e5ae8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b2e5ae8a4a3faa034c4b9a0ce1af6d55b0fc6aaa))
* DIN-52732 Enable length header ([1ef95f7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1ef95f74e532d8c5c27930c39d52b78f465e38a9))
* DIN-52733 Change Major Version to 1 ([8191d1b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8191d1b4baeb742a81b890fa6a974a0fb34a0214))

## [9.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v9.1.0...v9.2.0) (2024-08-09)

### Features

* DIN-51589 Model feature updates SW2402c - squashed ([a71e7b1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a71e7b1de1eb879ce0cc484a384b28d1ae54ca33))

## [9.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v9.0.0...v9.1.0) (2024-07-30)

### Features

* DIN-51927 Client records MajorVersion ([b5f3f10](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b5f3f104cf2062e969c41d878318031302fcdb68))
* DIN-52273 Set Major Ver for service ([42b36d2](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/42b36d22899c7fe1d309a7d9030ba35c2a83ec55))

### Bug Fixes

* DIN-19885 remove parallel initialization of model libs - squashed ([b13a34f](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b13a34f9851466e7da5d8311a15fb70d50876be6))
* DIN-21405 Integration of Klocworks and bug fixes (foss & mockval) - squashed ([8a4c8d9](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8a4c8d99cf10b7e4395a18373b2d7a886ce5cefc))
* DIN-23815 fix sws lighting service namespace issues - squashed ([f7339d7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f7339d74611c35c6ea515a659b18ef58c246a5bc))

## [9.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.12.0...v9.0.0) (2024-07-04)

### ⚠ BREAKING CHANGES

* DIN-50847 Update gtest job: SOA Payload
* DIN-50847 Update mocks for SOA Payload
* DIN-50847 Use SOA Payload API in IPC
* DIN-50847 Add SOA Payload API

### Features

* DIN-50847 Add SOA Payload API ([deb7b9c](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/deb7b9cd92464f28f779695cf9ddc0c5023605e8))
* DIN-50847 Update gtest job: SOA Payload ([88a0860](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/88a0860d589212e5fb7f25daa32f011574fd99a2))
* DIN-50847 Update mocks for SOA Payload ([ffb99f0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ffb99f0d2368d7679879126669376c8adbfeb991))
* DIN-50847 Use SOA Payload API in IPC ([c13001e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c13001e3ba996de1cd129fe4e52fd5907d432946))

## [8.12.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.11.0...v8.12.0) (2024-06-24)

### Features

* DIN-49669 Automate fetching someip dependecies & remove model short names - squashed ([a2a5e16](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a2a5e16348d0ba50786342f433facfbf684f6586))
* DIN-50787 model feature updates SW2402a - squashed ([0c8773e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0c8773eb1b5bb85d9375d76b684b3f2977d6e4af))

### Bug Fixes

* DIN-50667 GTest Code Coverage Improvement - squashed ([9612832](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/9612832e35f9aa85ee92b6ab021319a18955ecab))
* DIN-50677 Lock mutex before model onAvailable ([ccfe258](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ccfe2580ea390b524b9212f1caaa025cb06de946))
* DIN-50845 Added new testcase to improve branch coverage - squashed ([90dc399](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/90dc3991cd1a7175c68996f6355020adc1c6f661))

## [8.11.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.10.0...v8.11.0) (2024-06-06)

### Features

* DIN-23101 First iteration for ModelJson gen ([8fcbd37](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8fcbd378389faa9af19248f8c8f2a27b5d54390d))
* DIN-49009 Add DDS input support ([06e56db](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/06e56dbec7c1d41eca19b6f826201aad1d8eaded))
* DIN-49025 CI/CD Improvements - squashed ([679c7ea](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/679c7eaefa39e10ae1be27701bfa21a2d846a361))
* DIN-50328 model feature updates - SW2401d - squashed ([3637b3a](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/3637b3a8033afd1d7350094bed601e18b2057cd6))
* DIN-50328 update kanzi app_ema and app_jea cfg & slm scripts & remove goldenModel libs for release - squashed ([33671b9](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/33671b972e7fa3ce04839de8d8eb761e66a0319d))

## [8.10.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.9.1...v8.10.0) (2024-05-09)


### Features

* DIN-49670 Update dds_manager to v1.6.1 (Increase DataWriter history) and linux logging-api to 0.0.22/stable ([e09b541](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/e09b541504a13b58f3d5041532e3a94a1b2d4c32))
* DIN-49723 IP7 model feature updates - squashed ([860e08b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/860e08b53cf99266b843bbb2db4cad1d3dfa2176))

## [8.9.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.9.0...v8.9.1) (2024-04-22)


### Bug Fixes

* DIN-49024 copy slm_scripts jlr_di.xml to release/etc/slm properly - squashed ([1c58ed1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1c58ed17378b3f1d30011d7bb14d94dcfbb607bc))

## [8.9.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.8.1...v8.9.0) (2024-04-19)


### Features

* DIN-19622 Versioning Release artefacts - squashed ([1e00246](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1e002463b04ebd97e29f36b7052a735819180002))
* DIN-49022 Use shared mem for dds transport - squashed ([d01bdb1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/d01bdb144c06c58c855288482a0e0742d8236473))
* DIN-49024 Update model features for SW2401b - squashed ([274b1c5](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/274b1c5706a774290c291496227040c1b0935d1f))

## [8.8.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.8.0...v8.8.1) (2024-03-26)


### Bug Fixes

* DIN-20651 hotfix - remove patchelf rpath for IP6 artifacts ([03615a5](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/03615a5d41b90e08369f63c7671b93b9c0838df8))

## [8.8.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.7.0...v8.8.0) (2024-03-21)


### Features

* DIN-23634 telltale updates sw2401a - squashed ([d85bd29](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/d85bd29e1729ae36290836b5198c8c750d81c937))

## [8.7.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.6.0...v8.7.0) (2024-03-21)


### Features

* DIN-23635 message centre updates sw2401a - squashed ([0c5b311](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0c5b3114d7be7d6d247677cab1b21c6df606f730))

## [8.6.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.5.0...v8.6.0) (2024-03-21)


### Features

* DIN-23629 SW2401a_steeringWheelSwitch implementation - squashed ([fb3f438](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/fb3f43802db30536e566354d2987a0c21d254a1e))

## [8.5.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.4.0...v8.5.0) (2024-03-20)


### Features

* DIN-23627 Implement cockpit persistency using proto files for SW2401a - squashed ([99a92cd](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/99a92cd0741c5d26b7dee3c2309a9435bcf60368))

## [8.4.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.3.0...v8.4.0) (2024-03-18)


### Features

* DIN-20855 update model features for SW2304d-IP6.0 - squashed ([1900d7c](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1900d7cb8db62cec328d76e8097cd9c8e2fca182))

## [8.3.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.2.0...v8.3.0) (2024-03-04)


### Features

* DIN-21340 Setup common infrastructure - merge commit ([f69f100](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f69f10051f186ae0695c8d66b933eb347c8f6dab))
* DIN-21340 Setup common infrastructure - squashed ([512596e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/512596ee57bc96442a6f587f4795f7f9add01c45))

## [8.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.1.1...v8.2.0) (2024-02-28)


### Features

* DIN-19882 merge model launcher, model_grp_strategy & slm_scripts - merge commit ([2ec989d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2ec989ddff14fe5225259023177a08213d72f715))
* DIN-19882 merge model launcher, model_grp_strategy & slm_scripts - squashed ([0087ad4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0087ad4152106bbece51793568cad646a89db578))

## [8.1.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.1.0...v8.1.1) (2024-02-22)


### Bug Fixes

* DIN-20921 fix the copying of application.cfg & hmi_app for release artefacts (1320de3bd) - merge commit ([260bc56](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/260bc566f637d94b00cf3b2f436bdea765e0ec92))
* DIN-20921 fix the copying of application.cfg & hmi_app for release artefacts (1320de3bd) - squashed ([8d53847](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8d53847e80fe69ece2986717a6e1bbbd46d3871e))

## [8.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v8.0.0...v8.1.0) (2024-02-21)


### Features

* DIN-20927 Add support for multi-dim arrays ([f7e8ad7](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f7e8ad7e5745754c6ae141ebd5bf83f0c9030e20))
* DIN-21406 Update Models for SW2304c - merge commit ([8b99db0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/8b99db0853fc56755d6da724afe3d1e402896ef3))
* DIN-21406 Update non_safety_models and kanzi app versions ([74811fe](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/74811fefc6f06a66f741879eef82608cedacb686))
* DIN-21407 add autocodegen functionality for generating DDSRx methods for models with ddsRx configured ([5882ead](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5882eadc78ca8311e0f00b22841f0842181b2c2e))
* DIN-21407 add work executor to dds onDataAvailable callbacks ([ecf4a8e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ecf4a8e96c475b872891b5e1b0bf9cb64f94c847))


### Bug Fixes

* DIN-20921 Update qnx release scripts ([1320de3](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/1320de3bdfcc0c85fdc5af507c8f4c68d6aefa4d))
* DIN-20921 Update release version which has odo bug fix ([7e35c7f](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/7e35c7f0dd1367491d041689ae09bb15eb120b8a))
* DIN-21407 Changes to build scripts to add ddsrx ([9ad845a](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/9ad845af96e3c16bce063fea83c6172ebd543447))
* DIN-21407 fix odometer persistency ([a3b35c5](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a3b35c5e2269d016040dc34a686c38aae71f6894))
* DIN-21407 quick dirty fixes for issues with SW2304c models ([0126be9](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/0126be9fe61d06e2cb36e91f369477715ef271db))

## [8.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v7.2.0...v8.0.0) (2024-02-16)


### ⚠ BREAKING CHANGES

* DIN-21389 FC build migration - merge commit
* DIN-21389 FC build migration - squashed

### Features

* DIN-21389 FC build migration - merge commit ([e8b27ee](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/e8b27eedc4202cd55aa5ca94d6ee4cf9be0302df))
* DIN-21389 FC build migration - squashed ([f031aa0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f031aa01faed906317093a0c05c84ae25e4c2514))

## [7.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v7.1.0...v7.2.0) (2024-02-15)


### Features

* DIN-20616 Add DLT multi context support & add ENABLE_DLT_LOGGING flag - merge commit ([9948e3c](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/9948e3c73fba73c951e300a874799f308c65a8c8))
* DIN-20616 Add DLT multi context support & add ENABLE_DLT_LOGGING flag - squashed ([aef4ed2](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/aef4ed24ea65acca3fc23b50e7176b72f1b698c8))


### Bug Fixes

* DIN-20930  Fix for snyk-code issues - merge commit ([b22e92e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b22e92e1b5d275c9d85860301955ec91961ab573))
* DIN-20930  Fix for snyk-code issues - squashed ([ae05f90](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/ae05f9058b82175c364989fe1a5053b4bfa58e8b))

## [7.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v7.0.1...v7.1.0) (2024-01-19)


### Features

* DIN-20929 Dynamically Assigning Instance ID - merge commit ([afa9116](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/afa91168430b4df3e19272310b3def8ed599e44b))
* DIN-20929 Dynamically Assigning Instance ID - squashed ([6b8a8d4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/6b8a8d4d3e03312a3eded3cc2d22b09d15312164))


### Bug Fixes

* DIN-21335 packaging persistency libs and semantic release commit - merge commit ([965a345](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/965a345ccff8e26e78c0688e1ab5e310968f9da2))
* DIN-21335 packaging persistency libs and semantic release commit - squashed ([9a11956](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/9a11956f653ffceb3f0fcf09284cf93ca7c284cb))

## [7.0.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v7.0.0...v7.0.1) (2024-01-11)


### Bug Fixes

* DIN-20663 Update mockVAL to send PowerSupplyStatus ([dfc477e](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/dfc477eac0da1ebc55ae86f8f7f82b8d927a2950))

## [7.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v6.1.0...v7.0.0) (2024-01-05)


### ⚠ BREAKING CHANGES

* [DIN-20913] Update Models for SW2304a

### Features

* [DIN-20913] Update Models for SW2304a ([580b241](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/580b24197f4888ca56ea48663b3b07d88404a381))

## [6.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v6.0.0...v6.1.0) (2023-12-08)


### Features

* DIN-19647 Update packages for SW2303d Release ([51ac4be](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/51ac4be9b155fb4a44a70fe03c59c940419eb274))

## [6.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v5.1.0...v6.0.0) (2023-12-08)


### ⚠ BREAKING CHANGES

* [DIN-19644] Update Models for SW2303d

### Features

* [DIN-19644] Update Models for SW2303d ([c2673b2](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/c2673b23075d32f3fe67fd26fc7df99b555675eb))

## [5.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v5.0.0...v5.1.0) (2023-12-07)


### Features

* [DIN-18938] Gtest for CPP migrated source code ([28b5939](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/28b5939d73d40e6d38c3ab39fbd09ddb07fcc28d))

## [5.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v4.2.1...v5.0.0) (2023-12-04)


### ⚠ BREAKING CHANGES

* [DIN-18446] Added persistencyClient.

### Features

* [DIN-18446] Added persistencyClient. ([5c9c6b1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5c9c6b1d0231232bb4887c6914ca1e0e4212c79d))
* DIN_18446 use persistency launcher v3.0.0 ([e1cd738](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/e1cd738f0b59b3ecdfed68870aa950d131625c91))

## [4.2.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v4.2.0...v4.2.1) (2023-11-24)


### Bug Fixes

* DIN-18950 IP5.0 Release fixes ([da2e302](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/da2e302e9f9387cebcab63b69e7876feb9ff4123))

## [4.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v4.1.0...v4.2.0) (2023-11-24)


### Features

* DIN-18950 Update SLM scripts for IP5.0 Release ([5aad1d8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5aad1d81d1a11d2b235d21710d5e2e21fe6f8dca))

## [4.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v4.0.0...v4.1.0) (2023-11-24)


### Features

* DIN-19660 Add DLT Infra for Models and Mock VAL's ([3469479](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/3469479132f6c99a68126287ece46aeebff5daa6))

## [4.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v3.1.0...v4.0.0) (2023-11-23)


### ⚠ BREAKING CHANGES

* [DIN-19229] Update Models for SW2303c-IP5.0

### Features

* [DIN-19229] Update Models for SW2303c-IP5.0 ([6455448](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/6455448c64cee678c3f9e8e680cb4d05849ec8ae))

## [3.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v3.0.1...v3.1.0) (2023-11-22)


### Features

* DIN-18941 Add release metadata to DI libraries ([13d2801](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/13d2801891b414ba4a62ca7a14c071ca889b353b))

## [3.0.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v3.0.0...v3.0.1) (2023-11-10)


### Bug Fixes

* DIN_17639 build infra optimisation & fix work_executor_thread artifacts ([bf1824f](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/bf1824f125369d4adf23a178f76ee49bda09d8e7))

## [3.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.5.0...v3.0.0) (2023-11-06)


### ⚠ BREAKING CHANGES

* DIN_19015 CPP Migration

### Features

* DIN_19015 CPP Migration ([32202df](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/32202dfde07ac1369c338677af1106aac35d1b87))

## [2.5.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.4.0...v2.5.0) (2023-10-20)


### Features

* DIN-18533 Add features for SW2303b release ([5fee906](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/5fee906d9749b42bc14982c997a2f4c08fc9f70a))

## [2.4.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.3.1...v2.4.0) (2023-10-09)


### Features

* [DIN_17734] Update Models and MockVALs for SW2303a ([bae98a4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/bae98a43313b751fa00d4c6126aeffde2210405f))

## [2.3.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.3.0...v2.3.1) (2023-10-06)


### Bug Fixes

* DIN_17641 Added debug logs and error handling ([4db3d11](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/4db3d11d649e5655f525cb8cc9d24a6b6395cdb0))
* DIN_17641 error handling with debug logs and cleanup of build pipeline ([2ac0a99](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/2ac0a99681bb36e92657794cff222590c6e83202))

## [2.3.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.2.0...v2.3.0) (2023-10-06)


### Features

* DIN_17646 Enable debug branch ([4a09e0d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/4a09e0de9881badf27ef367d3217dd0141994498))
* DIN_17646 enable debug branch to store gen code ([f6c0fa4](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f6c0fa4456f89693cdeb4aa7dd22d7bd5d827de4))

## [2.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.1.0...v2.2.0) (2023-09-27)


### Features

* [DIN-17915] Update Mock VAL to IP4.0 ([39b6986](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/39b69867f9fb7132fb6d522fd00fddcd1127fc44))

## [2.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v2.0.0...v2.1.0) (2023-09-18)


### Features

* Update dds_manager to v1.1.0 ([b635eac](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b635eac25a5e8c3ca1c4e478dadb1ef0c0cf740a))

## [2.0.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v1.2.1...v2.0.0) (2023-09-17)


### ⚠ BREAKING CHANGES

* [DIN-16281] Update Models for SW2302d-IP4.0

### Features

* [DIN-16281] Update Models for SW2302d-IP4.0 ([74fa92d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/74fa92d86375537de38d7e9009dc321068e6164e))

## [1.2.1](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v1.2.0...v1.2.1) (2023-09-14)


### Bug Fixes

* DIN_16293 refactor & run snyk on generated code ([851915b](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/851915b0db40262622558d426a1147a6f75e9a72))
* DIN_16293 run sync jobs on generate cpp code (rm gitignore) ([74044a8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/74044a8ed9b356f04daec993ac39af0b0e3ed684))

## [1.2.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v1.1.0...v1.2.0) (2023-09-13)


### Features

* DIN_10264 someip sandbox integration ([d5e16c8](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/d5e16c8e93c482bb55dee1ff6d9a4ebf97d40862))


### Bug Fixes

* [DIN-16298] Fix unit test failure after updating fastdds to 2.8.1 ([51ca9b9](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/51ca9b9dacb07dd585fb2ed1456e7d5cc515c09b))

## [1.1.0](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/compare/v1.0.0...v1.1.0) (2023-08-25)


### Features

* DIN-15879 : SW2302c model deployment ([a309c6d](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/a309c6da653038b0a431629965ddcfe89f5adfbb))

## 1.0.0 (2023-08-25)


### ⚠ BREAKING CHANGES

* DIN-13362 Add semantic versioning with conan integration

### Features

* DIN-13362 Add semantic versioning with conan integration ([f1dab50](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/f1dab500106ce4cd7e23c80e114809be6a089c5f))


### Bug Fixes

* DIN_15617 Add length comparison check in VAL to Model api ([b2c5748](https://git-gdd.sdo.jlrmotor.com/CORS/Driver_Information/cccm/integration/model_integration/commit/b2c57485c178ad7da529597a9e4497ca2cd762a1))
