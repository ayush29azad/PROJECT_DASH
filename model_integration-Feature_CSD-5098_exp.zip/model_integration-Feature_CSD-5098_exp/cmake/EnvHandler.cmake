# exports variables of conan packages in cmake cache for further use

include(${CMAKE_BINARY_DIR}/conan_paths.cmake)
get_cmake_property(variables VARIABLES)

foreach(var ${variables})
  if(var MATCHES "^CONAN.*_ROOT")
    set(${var}
        "${${var}}"
        CACHE STRING "Caching ${var} for further use")
  endif()
endforeach()
