# Function to generate code for model
function(modelgen_target model_name)

  set(target_name ${model_name}Gen)

  set(MODEL_CONFIG_PATH
      ${CMAKE_SOURCE_DIR}/input/modelConfig/${model_name}.json)
  set(SOMEIP_CONFIG_JSON
      ${CMAKE_SOURCE_DIR}/model_ipc/config/model_someip_service_config.json)
  set(SOMEIP_SERVICE_DEF_DIR ${CMAKE_SOURCE_DIR}/input/protos)
  set(IPC_MAPPING_DIR ${CMAKE_SOURCE_DIR}/input/IPCMapping)
  set(MODEL_CODEGEN_DIR ${CMAKE_SOURCE_DIR}/output/codegen/${model_name})

  set(MODEL_GEN_FILES
      ${MODEL_CODEGEN_DIR}/${model_name}_init.cpp
      ${MODEL_CODEGEN_DIR}/${model_name}_out.cpp
      ${MODEL_CODEGEN_DIR}/${model_name}_global_vars.cpp
      ${MODEL_CODEGEN_DIR}/${model_name}_global_vars.hpp
      ${MODEL_CODEGEN_DIR}/Wrapper${model_name}.h
      # ${MODEL_CODEGEN_DIR}/DataConverter${model_name}.hpp
      ${MODEL_CODEGEN_DIR}/PlaybackDataConverter${model_name}.hpp
      ${MODEL_CODEGEN_DIR}/ProtoDataConverter${model_name}.cpp
      ${MODEL_CODEGEN_DIR}/ProtoIncludes${model_name}.hpp
      ${MODEL_CODEGEN_DIR}/dlt_logger.hpp)

  add_custom_command(
    OUTPUT ${MODEL_GEN_FILES}
    COMMAND
      python3 main.py --modelname ${model_name} --modelconfig
      ${MODEL_CONFIG_PATH} --servicemapping ${SOMEIP_CONFIG_JSON}
      --servicedefdir ${SOMEIP_SERVICE_DEF_DIR} --ipcmappingdir
      ${IPC_MAPPING_DIR} --codegendir ${MODEL_CODEGEN_DIR}
    WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}/auto_codegen_scripts
    COMMENT "Generating code for model : ${model_name}")

  add_custom_target(${target_name} ALL DEPENDS ${MODEL_GEN_FILES})

endfunction()

# Function to generate gtest code for model
function(modelgtestgen_target model_name)

  set(target_name ${model_name}GtestGen)

  set(MODEL_CONFIG_PATH
      ${CMAKE_SOURCE_DIR}/input/modelConfig/${model_name}.json)

  set(SOMEIP_SERVICE_FILE
      ${CMAKE_SOURCE_DIR}/model_ipc/config/model_someip_service_config.json)

  set(SOMEIP_SERVICE_DEF_DIR ${CMAKE_SOURCE_DIR}/input/protos)
  set(IPC_MAPPING_DIR ${CMAKE_SOURCE_DIR}/input/IPCMapping)
  set(MODEL_TESTGEN_DIR ${CMAKE_SOURCE_DIR}/output/testgen/${model_name})

  set(MODEL_GTEST_GEN_FILES
      ${MODEL_TESTGEN_DIR}/gtest${model_name}Init.cpp
      ${MODEL_TESTGEN_DIR}/gtest${model_name}InitNoMapping.cpp
      ${MODEL_TESTGEN_DIR}/gtest${model_name}InitTimer.cpp
      ${MODEL_TESTGEN_DIR}/gtest${model_name}Out.cpp
      ${MODEL_TESTGEN_DIR}/gtest${model_name}NotifyChannel.cpp
      ${MODEL_TESTGEN_DIR}/gtest${model_name}MessageChannel.cpp
      # ${MODEL_TESTGEN_DIR}/gtest${model_name}SomeipServiceProvider.cpp
  )

  add_custom_command(
    OUTPUT ${MODEL_GTEST_GEN_FILES}
    COMMAND
      python3 gtest_main.py --modelname ${model_name} --modelconfig
      ${MODEL_CONFIG_PATH} --servicemapping ${SOMEIP_SERVICE_FILE}
      --servicedefdir ${SOMEIP_SERVICE_DEF_DIR} --ipcmappingdir
      ${IPC_MAPPING_DIR} --codegendir ${MODEL_TESTGEN_DIR}
    WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}/auto_codegen_scripts/gtest
    COMMENT "Generating gtest code for model : ${model_name}")

  add_custom_target(${target_name} ALL DEPENDS ${MODEL_GTEST_GEN_FILES})

endfunction()
