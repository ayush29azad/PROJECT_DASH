#ifndef JLRCCCM_MODEL_LIB_INTERFACE_CREATOR_H
#define JLRCCCM_MODEL_LIB_INTERFACE_CREATOR_H
#include <memory>
extern "C" std::shared_ptr<cccm::di::ModelLibInterface> creator();
#endif  // JLRCCCM_MODEL_LIB_INTERFACE_CREATOR_H
