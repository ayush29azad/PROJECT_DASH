/// @file ModelLibInterface.h
/// @brief Contains common interface that all the model wrappers and launcher follow
///
/// @copyright "Copyright (C) 2023, Jaguar Land Rover
/// All rights reserved.
/// CONFIDENTIAL INFORMATION - DO NOT DISTRIBUTE"
///
/// @date June 2024

#ifndef JLRCCCM_MODEL_LIBRARY_INTERFACE_MODEL_INIALIZER_H
#define JLRCCCM_MODEL_LIBRARY_INTERFACE_MODEL_INIALIZER_H

#include <memory>
#include "types.h"

namespace cccm::di
{

  /// @brief Common interface that all the model wrappers and launcher follow
  class ModelLibInterface
  {

  public:
    /// @brief function for initializing comms, timers and other components like dlt
    /// @param context common objects passed from model launcher
    virtual void init(std::shared_ptr<cccm::di::launcher::LauncherContext> context) = 0;

    /// @brief function for releasing the comms, timers and other components like dlt
    virtual void terminate() = 0;

    /// @brief Dtor
    virtual ~ModelLibInterface() = default;
  };

};  // namespace cccm::di

#endif
