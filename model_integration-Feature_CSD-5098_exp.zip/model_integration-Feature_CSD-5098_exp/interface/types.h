#ifndef JLRCCCM_MODEL_LAUNCHER_TYPES_H
#define JLRCCCM_MODEL_LAUNCHER_TYPES_H

#include <string>
#include <memory>
#include <vsomeip/vsomeip.hpp>
#include <DDSEntityFactoryInterface.hpp>
#include <unordered_map>

namespace jlr::cccm::di::work_executor
{
  class WorkExecutor;
}
using namespace jlr::cccm::di::work_executor;
namespace cccm::di::launcher
{

  struct LauncherConfig
  {
    std::string modelName;
  };

  struct JsonLauncherConfig : public LauncherConfig
  {
    bool dltLogging = true;
    std::string loggingTag;
  };

  struct LauncherContext
  {
    std::pair<std::string, std::string> dltApplication;
    std::shared_ptr<WorkExecutor> workExecutor = nullptr;
    std::unordered_map<std::string, std::shared_ptr<vsomeip::application>> someipApp_map;
    std::shared_ptr<jlr::cccm::di::dds::DDSEntityFactoryInterface> ddsFactory = nullptr;
    std::string someipMappingFilename = "someip_id_mapping.json";
  };

};  // namespace cccm::di::launcher

#endif
